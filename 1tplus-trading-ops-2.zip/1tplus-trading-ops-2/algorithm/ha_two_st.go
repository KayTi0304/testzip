package algorithm

import (
	"math"
	"strconv"
	"time"

	"github.com/adshao/go-binance/v2/futures"
)

const (
	BUY  = "BUY"
	SELL = "SELL"
)

type SummaryMetrics struct {
	Wins         int
	Losses       int
	TotalTrades  int
	WinRate      float64
	TotalPNL     float64
	TotalTake    float64
	TotalLoss    float64
	FinalBalance float64
}

type TradeResult struct {
	OpenTime []string
	Action   []string
	Open     []float64
	High     []float64
	Low      []float64
	Close    []float64
	// HaOpen         []float64
	// HaHigh         []float64
	// HaLow          []float64
	// HaClose        []float64
	Entry          []float64
	Exit           []float64
	TakeProfit     []float64
	StopLoss       []float64
	WinLose        []float64
	PNL            []float64
	Balance        []float64
	ClosePosReason []string
}

func (tradeResult *TradeResult) ToMapSlice() []map[string]interface{} {
	// Get the length of the TradeResult slices
	n := len(tradeResult.OpenTime)

	// Initialize a slice of maps
	mapSlice := make([]map[string]interface{}, n)

	// Iterate through each index and populate the maps
	for i := 0; i < n; i++ {
		mapSlice[i] = map[string]interface{}{
			"OpenTime": tradeResult.OpenTime[i],
			"Action":   tradeResult.Action[i],
			"Open":     tradeResult.Open[i],
			"High":     tradeResult.High[i],
			"Low":      tradeResult.Low[i],
			"Close":    tradeResult.Close[i],
			// "HaOpen":         tradeResult.HaOpen[i],
			// "HaHigh":         tradeResult.HaHigh[i],
			// "HaLow":          tradeResult.HaLow[i],
			// "HaClose":        tradeResult.HaClose[i],
			"Entry":          tradeResult.Entry[i],
			"Exit":           tradeResult.Exit[i],
			"TakeProfit":     tradeResult.TakeProfit[i],
			"StopLoss":       tradeResult.StopLoss[i],
			"WinLose":        tradeResult.WinLose[i],
			"PNL":            tradeResult.PNL[i],
			"Balance":        tradeResult.Balance[i],
			"ClosePosReason": tradeResult.ClosePosReason[i],
		}
	}

	return mapSlice
}

type Candle struct {
	OpenTime  string
	Open      float64
	High      float64
	Low       float64
	Close     float64
	CloseTime string
}

type HeikenAshiCandle struct {
	Open, High, Low, Close float64
}

type SupertrendData struct {
	OpenTime         []string
	CloseTime        []string
	Open             []float64
	High             []float64
	Low              []float64
	Close            []float64
	HaOpen           []float64
	HaHigh           []float64
	HaLow            []float64
	HaClose          []float64
	Supertrend21     []bool
	FinalLowerBand21 []float64
	FinalUpperBand21 []float64
	Supertrend14     []bool
	FinalLowerBand14 []float64
	FinalUpperBand14 []float64
	Rsi21            []float64
	Rsi3             []float64
	AdxSignal        []float64
	BUY              []float64
	SELL             []float64
	StopLoss         []float64
}

func (data *SupertrendData) ToMapSlice() []map[string]interface{} {
	length := len(data.Supertrend21) // Assuming all slices are the same length
	results := make([]map[string]interface{}, length)

	for i := 0; i < length; i++ {
		row := map[string]interface{}{
			"OpenTime":         data.OpenTime[i],
			"CloseTime":        data.CloseTime[i],
			"Open":             data.Open[i],
			"High":             data.High[i],
			"Low":              data.Low[i],
			"Close":            data.Close[i],
			"HaOpen":           data.HaOpen[i],
			"HaHigh":           data.HaHigh[i],
			"HaLow":            data.HaLow[i],
			"HaClose":          data.HaClose[i],
			"Supertrend21":     data.Supertrend21[i],
			"FinalLowerBand21": data.FinalLowerBand21[i],
			"FinalUpperBand21": data.FinalUpperBand21[i],
			"Supertrend14":     data.Supertrend14[i],
			"FinalLowerBand14": data.FinalLowerBand14[i],
			"FinalUpperBand14": data.FinalUpperBand14[i],
			"BUY":              data.BUY[i],
			"SELL":             data.SELL[i],
			"StopLoss":         data.StopLoss[i],
		}
		results[i] = row
	}

	return results
}

func CalculateHeikenAshi(candles []Candle) []HeikenAshiCandle {
	var haCandles []HeikenAshiCandle

	for i, candle := range candles {
		var haCandle HeikenAshiCandle
		if i == 0 {
			haCandle.Open = (candle.Open + candle.Close) / 2
		} else {
			haCandle.Open = (haCandles[i-1].Open + haCandles[i-1].Close) / 2
		}
		haCandle.Close = (candle.Open + candle.High + candle.Low + candle.Close) / 4
		haCandle.High = max(candle.High, haCandle.Open, haCandle.Close)
		haCandle.Low = min(candle.Low, haCandle.Open, haCandle.Close)

		haCandles = append(haCandles, haCandle)
	}

	return haCandles
}

func max(values ...float64) float64 {
	maxValue := values[0]
	for _, value := range values {
		if value > maxValue {
			maxValue = value
		}
	}
	return maxValue
}

func min(values ...float64) float64 {
	minValue := values[0]
	for _, value := range values {
		if value < minValue {
			minValue = value
		}
	}
	return minValue
}

// CalculateTrueRange calculates the True Range.
func CalculateTrueRange(high, low, close []float64) []float64 {
	n := len(high)
	trueRange := make([]float64, n)

	for i := 1; i < n; i++ {
		diff1 := high[i] - low[i]
		diff2 := high[i] - close[i-1]
		diff3 := close[i-1] - low[i]

		maxDiff := math.Max(math.Abs(diff1), math.Abs(diff2))
		maxDiff = math.Max(maxDiff, math.Abs(diff3))

		trueRange[i] = maxDiff
	}

	return trueRange
}

func calculateEWMA(values []float64, alpha float64, minPeriods int) []float64 {
	n := len(values)
	ewma := make([]float64, n)

	// Initialize the first value
	var sum float64
	var count int
	for i := 0; i < n; i++ {
		sum += values[i]
		count++
		if count == minPeriods {
			ewma[i] = sum / float64(minPeriods)
			break
		}
	}

	// Calculate EWMA for the rest of the values
	for i := minPeriods; i < n; i++ {
		ewma[i] = alpha*values[i] + (1-alpha)*ewma[i-1]
	}

	return ewma
}

func CalculateATR(high, low, close []float64, period int) []float64 {
	trueRange := CalculateTrueRange(high, low, close)
	// atr := CalculateEMA(trueRange, period)
	alpha := 1.0 / float64(period)
	atr := calculateEWMA(trueRange, alpha, period)
	return atr
}

func isBuyTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
	return (supertrend21[curr] && !supertrend21[prev] && supertrend14[curr]) ||
		(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr])
}

func isSellTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
	return (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr])
}

// func ExtractCandles(df dataframe.DataFrame) []Candle {
// 	candles := make([]Candle, df.Nrow())
// 	for i := 0; i < df.Nrow(); i++ {
// 		openTime := time.UnixMilli(int64(df.Col("OpenTime").Elem(i).Float())).Format("2006-01-02 15:04:05")
// 		closeTime := time.UnixMilli(int64(df.Col("CloseTime").Elem(i).Float())).Format("2006-01-02 15:04:05")

//			candles[i] = Candle{
//				OpenTime:  openTime,
//				Open:      df.Col("Open").Elem(i).Float(),
//				High:      df.Col("High").Elem(i).Float(),
//				Low:       df.Col("Low").Elem(i).Float(),
//				Close:     df.Col("Close").Elem(i).Float(),
//				CloseTime: closeTime,
//			}
//		}
//		return candles
//	}
func parseStringToFloat(s string) float64 {
	val, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return 0.0
	}
	return val
}

func ExtractCandles(klines []*futures.Kline) []Candle {
	candles := make([]Candle, len(klines))
	for i, kline := range klines {
		openTime := time.UnixMilli(kline.OpenTime).UTC().Format("2006-01-02 15:04:05")
		closeTime := time.UnixMilli(kline.CloseTime).UTC().Format("2006-01-02 15:04:05")

		candles[i] = Candle{
			OpenTime:  openTime,
			Open:      parseStringToFloat(kline.Open),
			High:      parseStringToFloat(kline.High),
			Low:       parseStringToFloat(kline.Low),
			Close:     parseStringToFloat(kline.Close),
			CloseTime: closeTime,
		}
	}
	return candles
}

// ExtractCloses extracts the closing prices from a slice of HeikenAshiCandle.
func ExtractCloses(candles []HeikenAshiCandle) []float64 {
	closes := make([]float64, len(candles))
	for i, candle := range candles {
		closes[i] = candle.Close
	}
	return closes
}

// ExtractHighs extracts the high prices from a slice of HeikenAshiCandle.
func ExtractHighs(candles []HeikenAshiCandle) []float64 {
	highs := make([]float64, len(candles))
	for i, candle := range candles {
		highs[i] = candle.High
	}
	return highs
}

// ExtractLows extracts the low prices from a slice of HeikenAshiCandle.
func ExtractLows(candles []HeikenAshiCandle) []float64 {
	lows := make([]float64, len(candles))
	for i, candle := range candles {
		lows[i] = candle.Low
	}
	return lows
}

func HaTwoSupertrends(klines []*futures.Kline, multiplier21, multiplier14 float64, atrPeriod21, atrPeriod14 int) SupertrendData {
	candles := ExtractCandles(klines)
	haCandles := CalculateHeikenAshi(candles)
	length := len(haCandles)
	data := SupertrendData{
		OpenTime:         make([]string, length),
		CloseTime:        make([]string, length),
		Open:             make([]float64, length),
		High:             make([]float64, length),
		Low:              make([]float64, length),
		Close:            make([]float64, length),
		HaOpen:           make([]float64, length),
		HaHigh:           make([]float64, length),
		HaLow:            make([]float64, length),
		HaClose:          make([]float64, length),
		Supertrend21:     make([]bool, length),
		FinalLowerBand21: make([]float64, length),
		FinalUpperBand21: make([]float64, length),
		Supertrend14:     make([]bool, length),
		FinalLowerBand14: make([]float64, length),
		FinalUpperBand14: make([]float64, length),
		BUY:              make([]float64, length),
		SELL:             make([]float64, length),
		StopLoss:         make([]float64, length),
	}

	// Calculate ATR for both periods
	atr21 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21)
	atr14 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14)

	for i := 1; i < length; i++ {
		// Set OpenTime and CloseTime
		data.OpenTime[i] = candles[i].OpenTime
		data.CloseTime[i] = candles[i].CloseTime

		data.Open[i] = candles[i].Open
		data.High[i] = candles[i].High
		data.Low[i] = candles[i].Low
		data.Close[i] = candles[i].Close

		data.HaOpen[i] = haCandles[i].Open
		data.HaHigh[i] = haCandles[i].High
		data.HaLow[i] = haCandles[i].Low
		data.HaClose[i] = haCandles[i].Close

		hl2 := (haCandles[i].High + haCandles[i].Low) / 2
		data.FinalUpperBand21[i] = hl2 + multiplier21*atr21[i]
		data.FinalLowerBand21[i] = hl2 - multiplier21*atr21[i]

		data.FinalUpperBand14[i] = hl2 + multiplier14*atr14[i]
		data.FinalLowerBand14[i] = hl2 - multiplier14*atr14[i]

		// Calculate Supertrend logic for 21 period
		if haCandles[i].Close > data.FinalUpperBand21[i-1] {
			data.Supertrend21[i] = true
		} else if haCandles[i].Close < data.FinalLowerBand21[i-1] {
			data.Supertrend21[i] = false
		} else {
			data.Supertrend21[i] = data.Supertrend21[i-1]
			if data.Supertrend21[i] {
				if data.FinalLowerBand21[i] < data.FinalLowerBand21[i-1] {
					data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
				}
			} else {
				if data.FinalUpperBand21[i] > data.FinalUpperBand21[i-1] {
					data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
				}
			}
		}
		if data.Supertrend21[i] {
			data.FinalUpperBand21[i] = math.NaN()
		} else {
			data.FinalLowerBand21[i] = math.NaN()
		}

		// Calculate Supertrend logic for 14 period
		if haCandles[i].Close > data.FinalUpperBand14[i-1] {
			data.Supertrend14[i] = true
		} else if haCandles[i].Close < data.FinalLowerBand14[i-1] {
			data.Supertrend14[i] = false
		} else {
			data.Supertrend14[i] = data.Supertrend14[i-1]
			if data.Supertrend14[i] {
				if data.FinalLowerBand14[i] < data.FinalLowerBand14[i-1] {
					data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
				}
			} else {
				if data.FinalUpperBand14[i] > data.FinalUpperBand14[i-1] {
					data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
				}
			}
		}
		if data.Supertrend14[i] {
			data.FinalUpperBand14[i] = math.NaN()
		} else {
			data.FinalLowerBand14[i] = math.NaN()
		}

		if !math.IsNaN(data.FinalLowerBand14[i]) {
			data.StopLoss[i] = data.FinalLowerBand14[i]
		}

		if !math.IsNaN(data.FinalUpperBand14[i]) {
			data.StopLoss[i] = data.FinalUpperBand14[i]
		}

		// Check for buy or sell signals
		if isBuyTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
			data.BUY[i] = candles[i].Close
		}
		if isSellTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
			data.SELL[i] = candles[i].Close
		}
	}

	// dataFrameLike := data.ToMapSlice()
	// resultDf := dataframe.LoadMaps(dataFrameLike)

	return data
}

// BACKTEST

func calPNL(margin, entryPrice, exitPrice, usdtValue float64) float64 {
	if usdtValue < 5 {
		usdtValue = 5
	}
	if entryPrice == 0 {
		return 0.0
	}
	buyAmt := usdtValue * margin
	quantity := buyAmt / entryPrice
	pnl := (exitPrice - entryPrice) * quantity

	return pnl
}

//	func calLastPriceFrmROE(entry float64, leverage int, inBuy bool, roe float64) float64 {
//		positionMultiplier := 1.0
//		if !inBuy {
//			positionMultiplier = -1.0
//		}
//		return math.Round(((entry * roe) / (100 * float64(leverage)) * positionMultiplier) + entry)
//	}
func CalLastPriceFrmROE(entry, cost float64, leverage int, inBuy bool, roe float64) float64 {
	positionMultiplier := 1.0
	if !inBuy {
		positionMultiplier = -1.0
	}
	// Calculate the amount of profit/loss based on the ROE and cost
	roeProfitLoss := (roe / 100) * cost
	// log.Printf("rpl: %.1f", roeProfitLoss)
	// Calculate the last price based on the entry price and the calculated profit/loss
	lastPrice := entry + ((roeProfitLoss / (cost * float64(leverage)) * entry) * positionMultiplier)
	// return math.Round(lastPrice)
	return lastPrice
}

func Backtestv1(data SupertrendData, margin float64, tpPercent int, investAmt int, investPercent float64) (TradeResult, SummaryMetrics) {
	// Initialize series with the length of the data
	// results := make([]TradeResult, len(data.OpenTime))
	results := TradeResult{
		OpenTime: data.OpenTime,
		Action:   make([]string, len(data.OpenTime)),
		Open:     data.Open,
		High:     data.High,
		Low:      data.Low,
		Close:    data.Close,
		// HaOpen:         data.HaOpen,
		// HaHigh:         data.HaHigh,
		// HaLow:          data.HaLow,
		// HaClose:        data.HaClose,
		Entry:          make([]float64, len(data.OpenTime)),
		Exit:           make([]float64, len(data.OpenTime)),
		TakeProfit:     make([]float64, len(data.OpenTime)),
		StopLoss:       data.StopLoss,
		WinLose:        make([]float64, len(data.OpenTime)),
		PNL:            make([]float64, len(data.OpenTime)),
		Balance:        make([]float64, len(data.OpenTime)),
		ClosePosReason: make([]string, len(data.OpenTime)),
	}
	var totalPNL, wallet float64
	var wins, losses, totalTrades int

	var inBuySell bool
	var currentAction string
	var currentEntry, currentTakeProfit float64

	wallet = float64(investAmt)
	investValue := float64(investAmt) * investPercent

	for i := 30; i < len(data.OpenTime); i++ {
		if data.Close[i] <= 0 || wallet <= 0 {
			continue
		}

		if inBuySell {
			// takeProfit := calLastPriceFrmROE(currentEntry, int(margin), currentAction == "BUY", float64(tpPercent))

			takeProfitCondition := (currentAction == "BUY" && (data.Close[i] >= currentTakeProfit || data.High[i] >= currentTakeProfit)) ||
				(currentAction == "SELL" && (data.Close[i] <= currentTakeProfit || data.Low[i] <= currentTakeProfit))

			stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i] || data.Low[i] <= data.StopLoss[i])) ||
				(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i] || data.High[i] >= data.StopLoss[i]))

			if takeProfitCondition || stopLossCondition {
				exitPrice := currentTakeProfit
				closeReason := "hit TP"
				if stopLossCondition {
					exitPrice = data.StopLoss[i]
					closeReason = "hit SL"
				}
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason
				inBuySell = false
			} else if (currentAction == "BUY" && data.SELL[i] != 0) || (currentAction == "SELL" && data.BUY[i] != 0) {
				exitPrice := data.Close[i]
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = "change trend"

				// currentAction = "SELL"
				if currentAction == "BUY" {
					currentAction = "SELL"
				} else {
					currentAction = "BUY"
				}
				currentEntry = data.Close[i]
				currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", float64(tpPercent))
			} else {
				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				// results.Balance[i] = wallet

			}
		} else if data.BUY[i] != 0 || data.SELL[i] != 0 {
			if data.BUY[i] != 0 {
				currentAction = "BUY"
			} else {
				currentAction = "SELL"
			}
			currentEntry = data.Close[i]
			currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", float64(tpPercent))
			// currentStopLoss = data.StopLoss[i]
			inBuySell = true
			// results.Action[i] = currentAction
			// results.Entry[i] = currentEntry
		}

		results.Balance[i] = wallet
	}

	winRate := 0.0
	if totalTrades > 0 {
		winRate = float64(wins) / float64(totalTrades) * 100
	}

	// Create summary metrics struct
	summary := SummaryMetrics{
		Wins:         wins,
		Losses:       losses,
		TotalTrades:  totalTrades,
		WinRate:      winRate,
		TotalPNL:     totalPNL,
		FinalBalance: wallet,
	}

	return results, summary
}
