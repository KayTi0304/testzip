package algorithm

import (
	"fmt"
	"log"
	"math"
	"trading-ops/common"

	"github.com/adshao/go-binance/v2/futures"
)

type SupertrendData6 struct {
	OpenTime         []string
	CloseTime        []string
	Open             []float64
	High             []float64
	Low              []float64
	Close            []float64
	Supertrend21     []bool
	FinalLowerBand21 []float64
	FinalUpperBand21 []float64
	Supertrend14     []bool
	FinalLowerBand14 []float64
	FinalUpperBand14 []float64
	Supertrend10     []bool
	FinalLowerBand10 []float64
	FinalUpperBand10 []float64
	PlusDI21         []float64
	MinusDI21        []float64
	AdxSignal21      []float64
	PlusDI14         []float64
	MinusDI14        []float64
	AdxSignal14      []float64
	PlusDI10         []float64
	MinusDI10        []float64
	AdxSignal10      []float64
	Ema200           []float64
	Macd             []float64
	MacdSignal       []float64
	BUY              []float64
	SELL             []float64
	StopLoss         []float64
}

func (data *SupertrendData6) ToMapSlice() []map[string]interface{} {
	length := len(data.OpenTime) // Assuming all slices are the same length
	results := make([]map[string]interface{}, length)

	log.Println(length)
	log.Println(len(data.PlusDI21))
	log.Println(len(data.MinusDI21))
	log.Println(len(data.AdxSignal21))
	for i := 0; i < length; i++ {
		log.Println(data.CloseTime[i])
		row := map[string]interface{}{
			"OpenTime":         data.OpenTime[i],
			"CloseTime":        data.CloseTime[i],
			"Open":             data.Open[i],
			"High":             data.High[i],
			"Low":              data.Low[i],
			"Close":            data.Close[i],
			"Supertrend21":     data.Supertrend21[i],
			"FinalLowerBand21": data.FinalLowerBand21[i],
			"FinalUpperBand21": data.FinalUpperBand21[i],
			"Supertrend14":     data.Supertrend14[i],
			"FinalLowerBand14": data.FinalLowerBand14[i],
			"FinalUpperBand14": data.FinalUpperBand14[i],
			"Supertrend10":     data.Supertrend10[i],
			"FinalLowerBand10": data.FinalLowerBand10[i],
			"FinalUpperBand10": data.FinalUpperBand10[i],
			"PlusDI21":         data.PlusDI21[i],
			"MinusDI21":        data.MinusDI21[i],
			"AdxSignal21":      data.AdxSignal21[i],
			"PlusDI14":         data.PlusDI14[i],
			"MinusDI14":        data.MinusDI14[i],
			"AdxSignal14":      data.AdxSignal14[i],
			"PlusDI10":         data.PlusDI10[i],
			"MinusDI10":        data.MinusDI10[i],
			"AdxSignal10":      data.AdxSignal10[i],
			"Ema200":           data.Ema200[i],
			"Macd":             data.Macd[i],
			"MacdSignal":       data.MacdSignal[i],
			"BUY":              data.BUY[i],
			"SELL":             data.SELL[i],
			"StopLoss":         data.StopLoss[i],
		}
		results[i] = row
	}

	return results
}

/*
- remove heikin ashi adoption, directly map supertrend on the actual price candles
- add DI+and D- & ADX also
- buy signal = same 3ST and DI+ > DI- and ADX > 25, sell signal = same 3ST and DI+ < DI- and ADX > 25
*/

func ExtractCandlesCloses(candles []Candle) []float64 {
	closes := make([]float64, len(candles))
	for i, candle := range candles {
		closes[i] = candle.Close
	}
	return closes
}

func ExtractCandlesHighs(candles []Candle) []float64 {
	highs := make([]float64, len(candles))
	for i, candle := range candles {
		highs[i] = candle.High
	}
	return highs
}

func ExtractCandlesLows(candles []Candle) []float64 {
	lows := make([]float64, len(candles))
	for i, candle := range candles {
		lows[i] = candle.Low
	}
	return lows
}

func calculateDirectionalMovements(highs, lows []float64) ([]float64, []float64) {
	length := len(highs)
	plusDM := make([]float64, length)
	minusDM := make([]float64, length)

	for i := 1; i < length; i++ {
		upMove := highs[i] - highs[i-1]
		downMove := lows[i-1] - lows[i]

		if upMove > downMove && upMove > 0 {
			plusDM[i] = upMove
		}

		if downMove > upMove && downMove > 0 {
			minusDM[i] = downMove
		}
	}
	return plusDM, minusDM
}

// CalculateSmoothedDM calculates the smoothed DM+ and DM-
func calculateSmoothedDM(dm []float64, period int) []float64 {
	smoothedDM := make([]float64, len(dm))
	var sumDM float64

	// Initial sum of DM for the first 'period' days
	for i := 0; i < period; i++ {
		sumDM += dm[i]
	}
	smoothedDM[period-1] = sumDM

	// Calculate subsequent smoothed DM using exponential moving average formula
	for i := period; i < len(dm); i++ {
		smoothedDM[i] = smoothedDM[i-1] - (smoothedDM[i-1] / float64(period)) + dm[i]
	}

	return smoothedDM
}

// CalculateDirectionalIndicators calculates DI+, DI-, and ADX
func calculateDirectionalIndicators(plusDM, minusDM, atr []float64, period int) ([]float64, []float64, []float64) {
	length := len(plusDM)
	plusDI := make([]float64, length)
	minusDI := make([]float64, length)
	adx := make([]float64, length)

	// Calculate Smoothed DM+ and DM-
	smoothedPlusDM := calculateSmoothedDM(plusDM, period)
	smoothedMinusDM := calculateSmoothedDM(minusDM, period)

	for i := period; i < length; i++ {
		plusDI[i] = 100 * (smoothedPlusDM[i] / atr[i])
		minusDI[i] = 100 * (smoothedMinusDM[i] / atr[i])
		diDiff := math.Abs(plusDI[i] - minusDI[i])
		diSum := plusDI[i] + minusDI[i]
		if diSum == 0 {
			adx[i] = 0
		} else {
			adx[i] = (diDiff / diSum) * 100
		}
	}

	// Smooth ADX
	smoothedADX := 0.0
	for i := 0; i < period; i++ {
		smoothedADX += adx[i]
	}
	adx[period-1] = smoothedADX / float64(period)
	for i := period; i < length; i++ {
		smoothedADX = ((smoothedADX * float64(period-1)) + adx[i]) / float64(period)
		adx[i] = smoothedADX
	}

	return plusDI, minusDI, adx
}

// - buy signal = same 3ST and DI+ > DI- and ADX > 25, sell signal = same 3ST and DI+ < DI- and ADX > 25
func isBuyTrend6OnlyOne21(plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI21[curr] > minusDI21[curr] && adx21[curr] > 25) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6OnlyOne21(plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI21[curr] < minusDI21[curr] && adx21[curr] > 25) && (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr])
}

func isBuyTrend6OnlyOne14(plusDI14, minusDI14, adx14 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI14[curr] > minusDI14[curr] && adx14[curr] > 25) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6OnlyOne14(plusDI14, minusDI14, adx14 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI14[curr] < minusDI14[curr] && adx14[curr] > 25) && (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr])
}

func isBuyTrend6OnlyOne10(plusDI10, minusDI10, adx10 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI10[curr] > minusDI10[curr] && adx10[curr] > 25) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6OnlyOne10(plusDI10, minusDI10, adx10 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (plusDI10[curr] < minusDI10[curr] && adx10[curr] > 25) && (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr])
}

// - buy signal = same 3ST and DI+ > DI- and ADX > 25, sell signal = same 3ST and DI+ < DI- and ADX > 25
func isBuyTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ((plusDI10[curr] > minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] > minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] > minusDI21[curr] && adx21[curr] > 20)) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ((plusDI10[curr] < minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] < minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] < minusDI21[curr] && adx21[curr] > 20)) && (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr])
}

func isBuyTrend6v2(ema, close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (ema[curr] < close[curr]) && ((plusDI10[curr] > minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] > minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] > minusDI21[curr] && adx21[curr] > 20)) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6v2(ema, close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return (ema[curr] > close[curr]) && ((plusDI10[curr] < minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] < minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] < minusDI21[curr] && adx21[curr] > 20)) && ((!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr]))
}

func isBuyTrend6v25(supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
		(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
		(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
}

func isSellTrend6v25(supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ((!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr]))
}

func isBuyTrend6v3(macd, macdSignal, ema, close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ema[curr] < close[curr] && ((plusDI10[curr] > minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] > minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] > minusDI21[curr] && adx21[curr] > 20)) &&
		((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
			(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
			(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr])) &&
		(macd[curr] > macdSignal[curr] && macd[curr] > macd[prev])
}

func isSellTrend6v3(macd, macdSignal, ema, close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21 []float64, supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return ema[curr] > close[curr] && ((plusDI10[curr] < minusDI10[curr] && adx10[curr] > 20) ||
		(plusDI14[curr] < minusDI14[curr] && adx14[curr] > 20) ||
		(plusDI21[curr] < minusDI21[curr] && adx21[curr] > 20)) && (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
		(!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
		(!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr]) &&
			(macd[curr] < macdSignal[curr] && macd[curr] < macd[prev])
}

func SupertrendData6ToCsv(data SupertrendData6, fileName string) {
	var resultsBatch []map[string]interface{}

	for i := range data.OpenTime {
		resultsBatch = append(resultsBatch, map[string]interface{}{
			"OpenTime":         data.OpenTime[i],
			"CloseTime":        data.CloseTime[i],
			"Open":             data.Open[i],
			"High":             data.High[i],
			"Low":              data.Low[i],
			"Close":            data.Close[i],
			"Supertrend21":     data.Supertrend21[i],
			"FinalLowerBand21": data.FinalLowerBand21[i],
			"FinalUpperBand21": data.FinalUpperBand21[i],
			"Supertrend14":     data.Supertrend14[i],
			"FinalLowerBand14": data.FinalLowerBand14[i],
			"FinalUpperBand14": data.FinalUpperBand14[i],
			"Supertrend10":     data.Supertrend10[i],
			"FinalLowerBand10": data.FinalLowerBand10[i],
			"FinalUpperBand10": data.FinalUpperBand10[i],
			"PlusDI10":         data.PlusDI10[i],
			"MinusDI10":        data.MinusDI10[i],
			"AdxSignal10":      data.AdxSignal10[i],
			"PlusDI14":         data.PlusDI14[i],
			"MinusDI14":        data.MinusDI14[i],
			"AdxSignal14":      data.AdxSignal14[i],
			"PlusDI21":         data.PlusDI21[i],
			"MinusDI21":        data.MinusDI21[i],
			"AdxSignal21":      data.AdxSignal21[i],
			"BUY":              data.BUY[i],
			"SELL":             data.SELL[i],
			"StopLoss":         data.StopLoss[i],
		})
	}

	// Convert resultsBatch to CSV
	common.SaveCsv4(resultsBatch, fmt.Sprintf("%s", fileName))

}

// supertrend10, 14, 21, adx, di+, di- -> buy, sell, stoploss

func HaThreeSupertrendsV6(klines []*futures.Kline, multiplier21, multiplier14, multiplier10 float64, atrPeriod21, atrPeriod14, atrPeriod10, stoplossNoLine int) ResultData {
	candles := ExtractCandles(klines)
	length := len(candles)
	data := SupertrendData6{
		OpenTime:         make([]string, length),
		CloseTime:        make([]string, length),
		Open:             make([]float64, length),
		High:             make([]float64, length),
		Low:              make([]float64, length),
		Close:            make([]float64, length),
		Supertrend21:     make([]bool, length),
		FinalLowerBand21: make([]float64, length),
		FinalUpperBand21: make([]float64, length),
		Supertrend14:     make([]bool, length),
		FinalLowerBand14: make([]float64, length),
		FinalUpperBand14: make([]float64, length),
		Supertrend10:     make([]bool, length),
		FinalLowerBand10: make([]float64, length),
		FinalUpperBand10: make([]float64, length),
		PlusDI10:         make([]float64, length),
		MinusDI10:        make([]float64, length),
		AdxSignal10:      make([]float64, length),
		PlusDI14:         make([]float64, length),
		MinusDI14:        make([]float64, length),
		AdxSignal14:      make([]float64, length),
		PlusDI21:         make([]float64, length),
		MinusDI21:        make([]float64, length),
		AdxSignal21:      make([]float64, length),
		Ema200:           make([]float64, length),
		Macd:             make([]float64, length),
		MacdSignal:       make([]float64, length),
		BUY:              make([]float64, length),
		SELL:             make([]float64, length),
		StopLoss:         make([]float64, length),
	}

	// Calculate ATR for both periods
	candlesHigh := ExtractCandlesHighs(candles)
	candlesClose := ExtractCandlesCloses(candles)
	candlesLow := ExtractCandlesLows(candles)
	atr21 := CalculateATR(candlesHigh, candlesLow, candlesClose, atrPeriod21)
	atr14 := CalculateATR(candlesHigh, candlesLow, candlesClose, atrPeriod14)
	atr10 := CalculateATR(candlesHigh, candlesLow, candlesClose, atrPeriod10)

	// Calculate Directional Movements
	// calculateDirectionalMovement
	plusDM, minusDM := calculateDirectionalMovements(candlesHigh, candlesLow)
	plusDI10, minusDI10, adx10 := calculateDirectionalIndicators(plusDM, minusDM, atr10, atrPeriod10)
	plusDI14, minusDI14, adx14 := calculateDirectionalIndicators(plusDM, minusDM, atr14, atrPeriod14)
	plusDI21, minusDI21, adx21 := calculateDirectionalIndicators(plusDM, minusDM, atr21, atrPeriod21)

	ema := CalculateEMA200(candles)

	// closePrices := ExtractCloses(candles)
	macd, macdSignal, _ := CalculateMACD(candlesClose, 12, 26, 9)

	if len(ema) != len(candles) {
		log.Printf("EMA length (%d) does not match candles length (%d)", len(ema), len(candles))
	}

	buyCounter := 0
	sellCounter := 0
	for i := 1; i < length; i++ {
		// Set OpenTime and CloseTime
		data.OpenTime[i] = candles[i].OpenTime
		data.CloseTime[i] = candles[i].CloseTime

		data.Open[i] = candles[i].Open
		data.High[i] = candles[i].High
		data.Low[i] = candles[i].Low
		data.Close[i] = candles[i].Close

		hl2 := (candles[i].High + candles[i].Low) / 2
		data.FinalUpperBand21[i] = hl2 + multiplier21*atr21[i]
		data.FinalLowerBand21[i] = hl2 - multiplier21*atr21[i]

		data.FinalUpperBand14[i] = hl2 + multiplier14*atr14[i]
		data.FinalLowerBand14[i] = hl2 - multiplier14*atr14[i]

		data.FinalUpperBand10[i] = hl2 + multiplier10*atr10[i]
		data.FinalLowerBand10[i] = hl2 - multiplier10*atr10[i]

		data.PlusDI10[i] = plusDI10[i]
		data.MinusDI10[i] = minusDI10[i]
		data.AdxSignal10[i] = adx10[i]

		data.PlusDI14[i] = plusDI14[i]
		data.MinusDI14[i] = minusDI14[i]
		data.AdxSignal14[i] = adx14[i]

		data.PlusDI21[i] = plusDI21[i]
		data.MinusDI21[i] = minusDI21[i]
		data.AdxSignal21[i] = adx21[i]

		data.Ema200[i] = ema[i]
		data.Macd[i] = macd[i]
		data.MacdSignal[i] = macdSignal[i]

		// Calculate Supertrend logic for 21 period
		if candles[i].Close > data.FinalUpperBand21[i-1] {
			data.Supertrend21[i] = true
		} else if candles[i].Close < data.FinalLowerBand21[i-1] {
			data.Supertrend21[i] = false
		} else {
			data.Supertrend21[i] = data.Supertrend21[i-1]
			if data.Supertrend21[i] {
				if data.FinalLowerBand21[i] < data.FinalLowerBand21[i-1] {
					data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
				}
			} else {
				if data.FinalUpperBand21[i] > data.FinalUpperBand21[i-1] {
					data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
				}
			}
		}
		if data.Supertrend21[i] {
			data.FinalUpperBand21[i] = math.NaN()
		} else {
			data.FinalLowerBand21[i] = math.NaN()
		}

		if candles[i].Close > data.FinalUpperBand14[i-1] {
			data.Supertrend14[i] = true
		} else if candles[i].Close < data.FinalLowerBand14[i-1] {
			data.Supertrend14[i] = false
		} else {
			data.Supertrend14[i] = data.Supertrend14[i-1]
			if data.Supertrend14[i] {
				if data.FinalLowerBand14[i] < data.FinalLowerBand14[i-1] {
					data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
				}
			} else {
				if data.FinalUpperBand14[i] > data.FinalUpperBand14[i-1] {
					data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
				}
			}
		}
		if data.Supertrend14[i] {
			data.FinalUpperBand14[i] = math.NaN()
		} else {
			data.FinalLowerBand14[i] = math.NaN()
		}

		if candles[i].Close > data.FinalUpperBand10[i-1] {
			data.Supertrend10[i] = true
		} else if candles[i].Close < data.FinalLowerBand10[i-1] {
			data.Supertrend10[i] = false
		} else {
			data.Supertrend10[i] = data.Supertrend10[i-1]
			if data.Supertrend10[i] {
				if data.FinalLowerBand10[i] < data.FinalLowerBand10[i-1] {
					data.FinalLowerBand10[i] = data.FinalLowerBand10[i-1]
				}
			} else {
				if data.FinalUpperBand10[i] > data.FinalUpperBand10[i-1] {
					data.FinalUpperBand10[i] = data.FinalUpperBand10[i-1]
				}
			}
		}
		if data.Supertrend10[i] {
			data.FinalUpperBand10[i] = math.NaN()
		} else {
			data.FinalLowerBand10[i] = math.NaN()
		}

		// STOP LOSS
		if !math.IsNaN(data.FinalLowerBand14[i]) && stoplossNoLine == 2 {
			data.StopLoss[i] = data.FinalLowerBand14[i]
		}

		if !math.IsNaN(data.FinalUpperBand14[i]) && stoplossNoLine == 2 {
			data.StopLoss[i] = data.FinalUpperBand14[i]
		}

		if !math.IsNaN(data.FinalLowerBand10[i]) && stoplossNoLine == 3 {
			data.StopLoss[i] = data.FinalLowerBand10[i]
		}

		if !math.IsNaN(data.FinalUpperBand10[i]) && stoplossNoLine == 3 {
			data.StopLoss[i] = data.FinalUpperBand10[i]
		}
		// END

		// Check for buy or sell signals
		// if isBuyTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.BUY[i] = candles[i].Close
		// }
		// if isSellTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.SELL[i] = candles[i].Close
		// }

		// if isBuyTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.BUY[i] = candles[i].Close
		// }
		// if isSellTrend6(plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.SELL[i] = candles[i].Close
		// }

		// // if isBuyTrend6v3(macd, macdSignal, ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// if isBuyTrend6v2(ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.BUY[i] = candles[i].Close
		// }
		// // if isSellTrend6v3(macd, macdSignal, ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// if isSellTrend6v2(ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
		// 	data.SELL[i] = candles[i].Close
		// }

		if isBuyTrend6v25(data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
			buyCounter++    // Increment the BUY counter
			sellCounter = 0 // Reset the SELL counter on a new BUY signal
			// If buyCounter is less than 2, allow the BUY signal
			if buyCounter < 2 {
				// buyCounter++    // Increment the BUY counter
				// sellCounter = 0 // Reset the SELL counter on a new BUY signal
				if isBuyTrend6v2(ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
					data.BUY[i] = candles[i].Close
				}
			}
		}

		if isSellTrend6v25(data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
			sellCounter++  // Increment the SELL counter
			buyCounter = 0 // Reset the BUY counter on a new SELL signal
			// If sellCounter is less than 2, allow the SELL signal
			if sellCounter < 2 {
				// sellCounter++  // Increment the SELL counter
				// buyCounter = 0 // Reset the BUY counter on a new SELL signal
				if isSellTrend6v2(ema, data.Close, plusDI10, minusDI10, adx10, plusDI14, minusDI14, adx14, plusDI21, minusDI21, adx21, data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
					data.SELL[i] = candles[i].Close
				}
			}
		}
	}

	// common.SaveCsv4(data.ToMapSlice(), "detail")
	// SupertrendData6ToCsv(data, "detail")

	result := ConvertToResultData(data)
	return result
}
