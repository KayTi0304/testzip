package algorithm

import (
	"fmt"
	"math"
	"reflect"
	"time"
)

type ResultData struct {
	OpenTime  []string  // Time at which the candle opens
	CloseTime []string  // Time at which the candle closes
	Open      []float64 // Opening price of the candle
	High      []float64 // Highest price within the candle
	Low       []float64 // Lowest price within the candle
	Close     []float64 // Closing price of the candle
	BUY       []float64 // BUY signal strength or condition
	SELL      []float64 // SELL signal strength or condition
	StopLoss  []float64 // Stop-loss value
}

func (data *ResultData) ToMapSlice() []map[string]interface{} {
	length := len(data.OpenTime) // Assuming all slices are the same length
	results := make([]map[string]interface{}, length)

	for i := 0; i < length; i++ {
		row := map[string]interface{}{
			"OpenTime":  data.OpenTime[i],
			"CloseTime": data.CloseTime[i],
			"Open":      data.Open[i],
			"High":      data.High[i],
			"Low":       data.Low[i],
			"Close":     data.Close[i],
			"BUY":       data.BUY[i],
			"SELL":      data.SELL[i],
			"StopLoss":  data.StopLoss[i],
		}
		results[i] = row
	}

	return results
}

func ConvertToResultData(input interface{}) ResultData {
	result := ResultData{}
	inputVal := reflect.ValueOf(input)

	resultVal := reflect.ValueOf(&result).Elem()

	for i := 0; i < resultVal.NumField(); i++ {
		field := resultVal.Type().Field(i)
		inputField := inputVal.FieldByName(field.Name)
		if inputField.IsValid() && inputField.Type() == field.Type {
			resultVal.Field(i).Set(inputField)
		}
	}

	return result
}

func BacktestZetaVers(data ResultData, margin float64, tpPercent float64, investAmt int, investPercent float64, cutLossMultiplier float64) (TradeResult, SummaryMetrics) {
	results := TradeResult{
		OpenTime:       data.OpenTime,
		Action:         make([]string, len(data.OpenTime)),
		Open:           data.Open,
		High:           data.High,
		Low:            data.Low,
		Close:          data.Close,
		Entry:          make([]float64, len(data.OpenTime)),
		Exit:           make([]float64, len(data.OpenTime)),
		TakeProfit:     make([]float64, len(data.OpenTime)),
		StopLoss:       data.StopLoss,
		WinLose:        make([]float64, len(data.OpenTime)),
		PNL:            make([]float64, len(data.OpenTime)),
		Balance:        make([]float64, len(data.OpenTime)),
		ClosePosReason: make([]string, len(data.OpenTime)),
	}
	var totalPNL, wallet float64
	var wins, losses, totalTrades int

	var inBuySell bool
	var currentAction string
	var currentEntry, currentTakeProfit float64

	wallet = float64(investAmt)
	investValue := float64(investAmt) * investPercent

	for i := 30; i < len(data.OpenTime); i++ {
		if data.Close[i] <= 0 || wallet <= 0 {
			continue
		}

		if inBuySell {
			takeProfitCondition := (currentAction == "BUY" && (data.Close[i] >= currentTakeProfit || data.High[i] >= currentTakeProfit)) ||
				(currentAction == "SELL" && (data.Close[i] <= currentTakeProfit || data.Low[i] <= currentTakeProfit))

			stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i] || data.Low[i] <= data.StopLoss[i])) ||
				(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i] || data.High[i] >= data.StopLoss[i]))

			// currentCloseRoe := calPNL(margin, currentEntry, data.Close[i], investValue)
			// currentHgLwRoe := calPNL(margin, currentEntry, data.Low[i], investValue)
			// if currentAction == "SELL" {
			// 	currentCloseRoe = calPNL(margin, data.Close[i], currentEntry, investValue)
			// 	currentHgLwRoe = calPNL(margin, data.High[i], currentEntry, investValue)
			// }

			if takeProfitCondition || stopLossCondition {
				exitPrice := currentTakeProfit
				closeReason := "hit TP"
				if stopLossCondition {
					exitPrice = data.StopLoss[i]
					closeReason = "hit SL"
				}
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason
				inBuySell = false
			} else if (currentAction == "BUY" && data.SELL[i] != 0) || (currentAction == "SELL" && data.BUY[i] != 0) {
				exitPrice := data.Close[i]
				closeReason := "change trend"
				stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i-1] || data.Low[i] <= data.StopLoss[i-1])) ||
					(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i-1] || data.High[i] >= data.StopLoss[i-1]))
				if stopLossCondition {
					exitPrice = data.StopLoss[i-1]
					closeReason = "hit SL"
				}

				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason

				// currentAction = "SELL"
				if currentAction == "BUY" {
					currentAction = "SELL"
				} else {
					currentAction = "BUY"
				}
				currentEntry = data.Close[i]
				currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
				// } else if (cutLossMultiplier > 0.0 && currentCloseRoe < 0 && math.Abs(currentCloseRoe) > (cutLossMultiplier*investValue)) || (cutLossMultiplier > 0.0 && currentHgLwRoe < 0 && math.Abs(currentHgLwRoe) > (cutLossMultiplier*investValue)) {
				// 	// log.Printf(fmt.Sprintf("datetime: %s|currentCloseRoe: %.1f|currentHgLwRoe: %.1f|investValue: %.1f", data.OpenTime[i], currentCloseRoe, currentHgLwRoe, investValue))
				// 	exitPrice := CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", -100.0*cutLossMultiplier)
				// 	closeReason := "MANUAL"
				// 	pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				// 	if currentAction == "SELL" {
				// 		pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				// 	}
				// 	totalPNL += pnl
				// 	wallet += pnl
				// 	totalTrades++
				// 	if pnl > 0 {
				// 		wins++
				// 		results.WinLose[i] = 1
				// 	} else {
				// 		losses++
				// 		results.WinLose[i] = -1
				// 	}

				// 	results.Action[i] = currentAction
				// 	results.Entry[i] = currentEntry
				// 	results.Exit[i] = exitPrice
				// 	results.TakeProfit[i] = currentTakeProfit
				// 	results.StopLoss[i] = data.StopLoss[i]
				// 	results.PNL[i] = pnl
				// 	results.Balance[i] = wallet
				// 	results.ClosePosReason[i] = closeReason
				// 	inBuySell = false
				// } else if takeProfitCondition || stopLossCondition {
				// 	exitPrice := currentTakeProfit
				// 	closeReason := "hit TP"
				// 	if stopLossCondition {
				// 		exitPrice = data.StopLoss[i]
				// 		closeReason = "hit SL"
				// 	}
				// 	pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				// 	if currentAction == "SELL" {
				// 		pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				// 	}
				// 	totalPNL += pnl
				// 	wallet += pnl
				// 	totalTrades++
				// 	if pnl > 0 {
				// 		wins++
				// 		results.WinLose[i] = 1
				// 	} else {
				// 		losses++
				// 		results.WinLose[i] = -1
				// 	}

				// 	results.Action[i] = currentAction
				// 	results.Entry[i] = currentEntry
				// 	results.Exit[i] = exitPrice
				// 	results.TakeProfit[i] = currentTakeProfit
				// 	results.StopLoss[i] = data.StopLoss[i]
				// 	results.PNL[i] = pnl
				// 	results.Balance[i] = wallet
				// 	results.ClosePosReason[i] = closeReason
				// 	inBuySell = false
			} else {
				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				// results.Balance[i] = wallet

			}
		} else if data.BUY[i] != 0 || data.SELL[i] != 0 {
			if data.BUY[i] != 0 {
				currentAction = "BUY"
			} else {
				currentAction = "SELL"
			}
			currentEntry = data.Close[i]
			currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
			// currentStopLoss = data.StopLoss[i]
			inBuySell = true
			// results.Action[i] = currentAction
			// results.Entry[i] = currentEntry
		}

		results.Balance[i] = wallet
	}

	// common.SaveCsv4(results.ToMapSlice(), "detail")

	winRate := 0.0
	if totalTrades > 0 {
		winRate = float64(wins) / float64(totalTrades) * 100
	}

	// Create summary metrics struct
	summary := SummaryMetrics{
		Wins:         wins,
		Losses:       losses,
		TotalTrades:  totalTrades,
		WinRate:      winRate,
		TotalPNL:     totalPNL,
		FinalBalance: wallet,
	}

	return results, summary
}

// func BacktestZetaVers201(data ResultData, margin float64, tpPercent float64, investAmt int, investPercent float64, cutLossMultiplier float64) (TradeResult, SummaryMetrics) {
// 	results := TradeResult{
// 		OpenTime:       data.OpenTime,
// 		Action:         make([]string, len(data.OpenTime)),
// 		Open:           data.Open,
// 		High:           data.High,
// 		Low:            data.Low,
// 		Close:          data.Close,
// 		Entry:          make([]float64, len(data.OpenTime)),
// 		Exit:           make([]float64, len(data.OpenTime)),
// 		TakeProfit:     make([]float64, len(data.OpenTime)),
// 		StopLoss:       data.StopLoss,
// 		WinLose:        make([]float64, len(data.OpenTime)),
// 		PNL:            make([]float64, len(data.OpenTime)),
// 		Balance:        make([]float64, len(data.OpenTime)),
// 		ClosePosReason: make([]string, len(data.OpenTime)),
// 	}
// 	var totalPNL, wallet float64
// 	var wins, losses, totalTrades int

// 	var inBuySell bool
// 	var currentAction string
// 	var currentEntry, currentTakeProfit float64

// 	wallet = float64(investAmt)
// 	investValue := float64(investAmt) * investPercent

// 	for i := 30; i < len(data.OpenTime); i++ {
// 		if data.Close[i] <= 0 || wallet <= 0 {
// 			continue
// 		}

// 		if inBuySell {
// 			takeProfitCondition := (currentAction == "BUY" && (data.Close[i] >= currentTakeProfit || data.High[i] >= currentTakeProfit)) ||
// 				(currentAction == "SELL" && (data.Close[i] <= currentTakeProfit || data.Low[i] <= currentTakeProfit))

// 			stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i] || data.Low[i] <= data.StopLoss[i])) ||
// 				(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i] || data.High[i] >= data.StopLoss[i]))

// 			currentCloseRoe := calPNL(margin, currentEntry, data.Close[i], investValue)
// 			currentHgLwRoe := calPNL(margin, currentEntry, data.Low[i], investValue)
// 			if currentAction == "SELL" {
// 				currentCloseRoe = calPNL(margin, data.Close[i], currentEntry, investValue)
// 				currentHgLwRoe = calPNL(margin, data.High[i], currentEntry, investValue)
// 			}

// 			if takeProfitCondition || stopLossCondition {
// 				exitPrice := currentTakeProfit
// 				closeReason := "hit TP"
// 				if stopLossCondition {
// 					exitPrice = data.StopLoss[i]
// 					closeReason = "hit SL"
// 				}
// 				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
// 				if currentAction == "SELL" {
// 					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
// 				}
// 				totalPNL += pnl
// 				wallet += pnl
// 				totalTrades++
// 				if pnl > 0 {
// 					wins++
// 					results.WinLose[i] = 1
// 				} else {
// 					losses++
// 					results.WinLose[i] = -1
// 				}

// 				results.Action[i] = currentAction
// 				results.Entry[i] = currentEntry
// 				results.Exit[i] = exitPrice
// 				results.TakeProfit[i] = currentTakeProfit
// 				results.StopLoss[i] = data.StopLoss[i]
// 				results.PNL[i] = pnl
// 				results.Balance[i] = wallet
// 				results.ClosePosReason[i] = closeReason
// 				inBuySell = false

// 				if data.SELL[i] > 0 {
// 					currentAction = "SELL"
// 					currentEntry = data.Close[i]
// 					currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
// 					inBuySell = true
// 				}
// 				if data.BUY[i] > 0 {
// 					currentAction = "BUY"
// 					currentEntry = data.Close[i]
// 					currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
// 					inBuySell = true
// 				}
// 			} else if (cutLossMultiplier > 0.0 && currentCloseRoe < 0 && math.Abs(currentCloseRoe) > (cutLossMultiplier*investValue)) || (cutLossMultiplier > 0.0 && currentHgLwRoe < 0 && math.Abs(currentHgLwRoe) > (cutLossMultiplier*investValue)) {
// 				// log.Printf(fmt.Sprintf("datetime: %s|currentCloseRoe: %.1f|currentHgLwRoe: %.1f|investValue: %.1f", data.OpenTime[i], currentCloseRoe, currentHgLwRoe, investValue))
// 				exitPrice := CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", -100.0*cutLossMultiplier)
// 				closeReason := "MANUAL"
// 				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
// 				if currentAction == "SELL" {
// 					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
// 				}
// 				totalPNL += pnl
// 				wallet += pnl
// 				totalTrades++
// 				if pnl > 0 {
// 					wins++
// 					results.WinLose[i] = 1
// 				} else {
// 					losses++
// 					results.WinLose[i] = -1
// 				}

// 				results.Action[i] = currentAction
// 				results.Entry[i] = currentEntry
// 				results.Exit[i] = exitPrice
// 				results.TakeProfit[i] = currentTakeProfit
// 				results.StopLoss[i] = data.StopLoss[i]
// 				results.PNL[i] = pnl
// 				results.Balance[i] = wallet
// 				results.ClosePosReason[i] = closeReason
// 				inBuySell = false
// 			} else {
// 				results.Action[i] = currentAction
// 				results.Entry[i] = currentEntry
// 				results.TakeProfit[i] = currentTakeProfit
// 				results.StopLoss[i] = data.StopLoss[i]
// 			}
// 		} else if data.BUY[i] > 0 || data.SELL[i] > 0 {
// 			if data.BUY[i] != 0 {
// 				currentAction = "BUY"
// 			} else {
// 				currentAction = "SELL"
// 			}
// 			currentEntry = data.Close[i]
// 			currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
// 			inBuySell = true
// 		}

// 		results.Balance[i] = wallet
// 	}

// 	// common.SaveCsv4(results.ToMapSlice(), "detail")

// 	winRate := 0.0
// 	if totalTrades > 0 {
// 		winRate = float64(wins) / float64(totalTrades) * 100
// 	}

// 	// Create summary metrics struct
// 	summary := SummaryMetrics{
// 		Wins:         wins,
// 		Losses:       losses,
// 		TotalTrades:  totalTrades,
// 		WinRate:      winRate,
// 		TotalPNL:     totalPNL,
// 		FinalBalance: wallet,
// 	}

//		return results, summary
//	}

// Define a struct for the forbidden time window
type TimeWindow struct {
	Start time.Time
	End   time.Time
}

// Function to parse time strings to `time.Time` based on a given layout
func parseTimeString(timeStr string) time.Time {
	parsedTime, err := time.Parse("15:04", timeStr) // 24-hour time format
	if err != nil {
		fmt.Println("Error parsing time:", err)
	}
	return parsedTime
}

// Struct to manage multiple time windows
type ForbiddenTimeManager struct {
	Windows []TimeWindow
}

// Method to add a time window to the forbidden list
func (ftm *ForbiddenTimeManager) AddWindow(start string, end string) {
	ftm.Windows = append(ftm.Windows, TimeWindow{
		Start: parseTimeString(start),
		End:   parseTimeString(end),
	})
}

// Method to check if the current time falls within any forbidden time window
func (ftm *ForbiddenTimeManager) IsInForbiddenWindow(t time.Time) bool {
	for _, window := range ftm.Windows {
		if t.Hour() == window.Start.Hour() && t.Minute() >= window.Start.Minute() && t.Minute() <= window.End.Minute() {
			return true
		}
	}
	return false
}

func initFTM() ForbiddenTimeManager {
	ftm := ForbiddenTimeManager{}
	ftm.AddWindow("22:00", "00:00") // Sydney open
	ftm.AddWindow("00:00", "02:00") // Tokyo open
	ftm.AddWindow("08:00", "10:00") // London open
	ftm.AddWindow("13:00", "15:00") // New York open
	return ftm
}

func BacktestZetaVers201(data ResultData, margin float64, tpPercent float64, investAmt int, investPercent float64, cutLossMultiplier float64) (TradeResult, SummaryMetrics) {
	ftm := initFTM()

	results := TradeResult{
		OpenTime: data.OpenTime,
		Action:   make([]string, len(data.OpenTime)),
		Open:     data.Open,
		High:     data.High,
		Low:      data.Low,
		Close:    data.Close,
		// HaOpen:         data.HaOpen,
		// HaHigh:         data.HaHigh,
		// HaLow:          data.HaLow,
		// HaClose:        data.HaClose,
		Entry:          make([]float64, len(data.OpenTime)),
		Exit:           make([]float64, len(data.OpenTime)),
		TakeProfit:     make([]float64, len(data.OpenTime)),
		StopLoss:       data.StopLoss,
		WinLose:        make([]float64, len(data.OpenTime)),
		PNL:            make([]float64, len(data.OpenTime)),
		Balance:        make([]float64, len(data.OpenTime)),
		ClosePosReason: make([]string, len(data.OpenTime)),
	}
	var totalPNL, wallet float64
	var take, loss float64
	var wins, losses, totalTrades int

	var inBuySell bool
	var currentAction string
	var currentEntry, currentTakeProfit float64

	wallet = float64(investAmt)
	investValue := float64(investAmt) * investPercent

	for i := 30; i < len(data.OpenTime); i++ {
		if data.Close[i] <= 0 || wallet <= 0 {
			continue
		}

		// openTime, err := time.Parse("1/2/2006 3:04:05 PM", data.OpenTime[i])
		openTime, err := time.Parse("2006-01-02 15:04:05", data.OpenTime[i])
		if err != nil {
			fmt.Println("Error parsing time:", err)
			continue
		}

		// Skip trade if it falls in the forbidden window
		if ftm.IsInForbiddenWindow(openTime) {
			continue
		}

		if inBuySell {
			takeProfitCondition := (currentAction == "BUY" && (data.Close[i] >= currentTakeProfit || data.High[i] >= currentTakeProfit)) ||
				(currentAction == "SELL" && (data.Close[i] <= currentTakeProfit || data.Low[i] <= currentTakeProfit))

			stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i] || data.Low[i] <= data.StopLoss[i])) ||
				(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i] || data.High[i] >= data.StopLoss[i]))

			currentCloseRoe := calPNL(margin, currentEntry, data.Close[i], investValue)
			currentHgLwRoe := calPNL(margin, currentEntry, data.Low[i], investValue)
			if currentAction == "SELL" {
				currentCloseRoe = calPNL(margin, data.Close[i], currentEntry, investValue)
				currentHgLwRoe = calPNL(margin, data.High[i], currentEntry, investValue)
			}

			if takeProfitCondition || stopLossCondition {
				exitPrice := currentTakeProfit
				closeReason := "hit TP"
				if stopLossCondition {
					exitPrice = data.StopLoss[i]
					closeReason = "hit SL"
				}
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				if pnl > 0.0 {
					take += pnl
				} else {
					loss += pnl
				}
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason
				inBuySell = false

				if data.SELL[i] > 0 {
					currentAction = "SELL"
					currentEntry = data.Close[i]
					currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
					inBuySell = true
				}
				if data.BUY[i] > 0 {
					currentAction = "BUY"
					currentEntry = data.Close[i]
					currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
					inBuySell = true
				}
			} else if (cutLossMultiplier > 0.0 && currentCloseRoe < 0 && math.Abs(currentCloseRoe) > (cutLossMultiplier*investValue)) || (cutLossMultiplier > 0.0 && currentHgLwRoe < 0 && math.Abs(currentHgLwRoe) > (cutLossMultiplier*investValue)) {
				// log.Printf(fmt.Sprintf("datetime: %s|currentCloseRoe: %.1f|currentHgLwRoe: %.1f|investValue: %.1f", data.OpenTime[i], currentCloseRoe, currentHgLwRoe, investValue))
				exitPrice := CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", -100.0*cutLossMultiplier)
				closeReason := "MANUAL"
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				if pnl > 0.0 {
					take += pnl
				} else {
					loss += pnl
				}
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason
				inBuySell = false
			} else {
				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
			}
		} else if data.BUY[i] > 0 || data.SELL[i] > 0 {
			if data.BUY[i] != 0 {
				currentAction = "BUY"
			} else {
				currentAction = "SELL"
			}
			currentEntry = data.Close[i]
			currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
			inBuySell = true
		}

		results.Balance[i] = wallet
	}

	// common.SaveCsv4(results.ToMapSlice(), "detail")

	winRate := 0.0
	if totalTrades > 0 {
		winRate = float64(wins) / float64(totalTrades) * 100
	}

	// Create summary metrics struct
	summary := SummaryMetrics{
		Wins:         wins,
		Losses:       losses,
		TotalTrades:  totalTrades,
		WinRate:      winRate,
		TotalPNL:     totalPNL,
		TotalTake:    take,
		TotalLoss:    loss,
		FinalBalance: wallet,
	}

	return results, summary
}
