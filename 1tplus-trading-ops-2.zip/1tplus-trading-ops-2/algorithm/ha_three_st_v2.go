package algorithm

import (
	"math"

	"github.com/adshao/go-binance/v2/futures"
)

func isBuyTrend3(supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]
}

func isSellTrend3(supertrend21, supertrend14, supertrend10 []bool, curr, prev int) bool {
	return !supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr]
}

func HaThreeSupertrendsV2(klines []*futures.Kline, multiplier21, multiplier14, multiplier10 float64, atrPeriod21, atrPeriod14, atrPeriod10, stoplossNoLine int) ResultData {
	candles := ExtractCandles(klines)
	haCandles := CalculateHeikenAshi(candles)
	length := len(haCandles)
	data := SupertrendData2{
		OpenTime:         make([]string, length),
		CloseTime:        make([]string, length),
		Open:             make([]float64, length),
		High:             make([]float64, length),
		Low:              make([]float64, length),
		Close:            make([]float64, length),
		HaOpen:           make([]float64, length),
		HaHigh:           make([]float64, length),
		HaLow:            make([]float64, length),
		HaClose:          make([]float64, length),
		Supertrend21:     make([]bool, length),
		FinalLowerBand21: make([]float64, length),
		FinalUpperBand21: make([]float64, length),
		Supertrend14:     make([]bool, length),
		FinalLowerBand14: make([]float64, length),
		FinalUpperBand14: make([]float64, length),
		Supertrend10:     make([]bool, length),
		FinalLowerBand10: make([]float64, length),
		FinalUpperBand10: make([]float64, length),
		BUY:              make([]float64, length),
		SELL:             make([]float64, length),
		StopLoss:         make([]float64, length),
	}

	// Calculate ATR for both periods
	atr21 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21)
	atr14 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14)
	atr10 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod10)

	for i := 1; i < length; i++ {
		// Set OpenTime and CloseTime
		data.OpenTime[i] = candles[i].OpenTime
		data.CloseTime[i] = candles[i].CloseTime

		data.Open[i] = candles[i].Open
		data.High[i] = candles[i].High
		data.Low[i] = candles[i].Low
		data.Close[i] = candles[i].Close

		data.HaOpen[i] = haCandles[i].Open
		data.HaHigh[i] = haCandles[i].High
		data.HaLow[i] = haCandles[i].Low
		data.HaClose[i] = haCandles[i].Close

		hl2 := (haCandles[i].High + haCandles[i].Low) / 2
		data.FinalUpperBand21[i] = hl2 + multiplier21*atr21[i]
		data.FinalLowerBand21[i] = hl2 - multiplier21*atr21[i]

		data.FinalUpperBand14[i] = hl2 + multiplier14*atr14[i]
		data.FinalLowerBand14[i] = hl2 - multiplier14*atr14[i]

		data.FinalUpperBand10[i] = hl2 + multiplier10*atr10[i]
		data.FinalLowerBand10[i] = hl2 - multiplier10*atr10[i]

		// Calculate Supertrend logic for 21 period
		if haCandles[i].Close > data.FinalUpperBand21[i-1] {
			data.Supertrend21[i] = true
		} else if haCandles[i].Close < data.FinalLowerBand21[i-1] {
			data.Supertrend21[i] = false
		} else {
			data.Supertrend21[i] = data.Supertrend21[i-1]
			if data.Supertrend21[i] {
				if data.FinalLowerBand21[i] < data.FinalLowerBand21[i-1] {
					data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
				}
			} else {
				if data.FinalUpperBand21[i] > data.FinalUpperBand21[i-1] {
					data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
				}
			}
		}
		if data.Supertrend21[i] {
			data.FinalUpperBand21[i] = math.NaN()
		} else {
			data.FinalLowerBand21[i] = math.NaN()
		}

		if haCandles[i].Close > data.FinalUpperBand14[i-1] {
			data.Supertrend14[i] = true
		} else if haCandles[i].Close < data.FinalLowerBand14[i-1] {
			data.Supertrend14[i] = false
		} else {
			data.Supertrend14[i] = data.Supertrend14[i-1]
			if data.Supertrend14[i] {
				if data.FinalLowerBand14[i] < data.FinalLowerBand14[i-1] {
					data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
				}
			} else {
				if data.FinalUpperBand14[i] > data.FinalUpperBand14[i-1] {
					data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
				}
			}
		}
		if data.Supertrend14[i] {
			data.FinalUpperBand14[i] = math.NaN()
		} else {
			data.FinalLowerBand14[i] = math.NaN()
		}

		if haCandles[i].Close > data.FinalUpperBand10[i-1] {
			data.Supertrend10[i] = true
		} else if haCandles[i].Close < data.FinalLowerBand10[i-1] {
			data.Supertrend10[i] = false
		} else {
			data.Supertrend10[i] = data.Supertrend10[i-1]
			if data.Supertrend10[i] {
				if data.FinalLowerBand10[i] < data.FinalLowerBand10[i-1] {
					data.FinalLowerBand10[i] = data.FinalLowerBand10[i-1]
				}
			} else {
				if data.FinalUpperBand10[i] > data.FinalUpperBand10[i-1] {
					data.FinalUpperBand10[i] = data.FinalUpperBand10[i-1]
				}
			}
		}
		if data.Supertrend10[i] {
			data.FinalUpperBand10[i] = math.NaN()
		} else {
			data.FinalLowerBand10[i] = math.NaN()
		}

		// STOP LOSS
		if !math.IsNaN(data.FinalLowerBand14[i]) && stoplossNoLine == 2 {
			data.StopLoss[i] = data.FinalLowerBand14[i]
		}

		if !math.IsNaN(data.FinalUpperBand14[i]) && stoplossNoLine == 2 {
			data.StopLoss[i] = data.FinalUpperBand14[i]
		}

		if !math.IsNaN(data.FinalLowerBand10[i]) && stoplossNoLine == 3 {
			data.StopLoss[i] = data.FinalLowerBand10[i]
		}

		if !math.IsNaN(data.FinalUpperBand10[i]) && stoplossNoLine == 3 {
			data.StopLoss[i] = data.FinalUpperBand10[i]
		}

		// Check for buy or sell signals
		if isBuyTrend3(data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
			data.BUY[i] = candles[i].Close
		}
		if isSellTrend3(data.Supertrend21, data.Supertrend14, data.Supertrend10, i, i-1) {
			data.SELL[i] = candles[i].Close
		}
	}

	result := ConvertToResultData(data)
	return result
}

func Backtestv3(data SupertrendData2, margin float64, tpPercent float64, investAmt int, investPercent float64) (TradeResult, SummaryMetrics) {
	// Initialize series with the length of the data
	// results := make([]TradeResult, len(data.OpenTime))
	results := TradeResult{
		OpenTime: data.OpenTime,
		Action:   make([]string, len(data.OpenTime)),
		Open:     data.Open,
		High:     data.High,
		Low:      data.Low,
		Close:    data.Close,
		// HaOpen:         data.HaOpen,
		// HaHigh:         data.HaHigh,
		// HaLow:          data.HaLow,
		// HaClose:        data.HaClose,
		Entry:          make([]float64, len(data.OpenTime)),
		Exit:           make([]float64, len(data.OpenTime)),
		TakeProfit:     make([]float64, len(data.OpenTime)),
		StopLoss:       data.StopLoss,
		WinLose:        make([]float64, len(data.OpenTime)),
		PNL:            make([]float64, len(data.OpenTime)),
		Balance:        make([]float64, len(data.OpenTime)),
		ClosePosReason: make([]string, len(data.OpenTime)),
	}
	var totalPNL, wallet float64
	var wins, losses, totalTrades int

	var inBuySell bool
	var currentAction string
	var currentEntry, currentTakeProfit float64

	wallet = float64(investAmt)
	investValue := float64(investAmt) * investPercent

	for i := 30; i < len(data.OpenTime); i++ {
		if data.Close[i] <= 0 || wallet <= 0 {
			continue
		}

		if inBuySell {
			// takeProfit := calLastPriceFrmROE(currentEntry, int(margin), currentAction == "BUY", float64(tpPercent))

			takeProfitCondition := (currentAction == "BUY" && (data.Close[i] >= currentTakeProfit || data.High[i] >= currentTakeProfit)) ||
				(currentAction == "SELL" && (data.Close[i] <= currentTakeProfit || data.Low[i] <= currentTakeProfit))

			stopLossCondition := (currentAction == "BUY" && (data.Close[i] <= data.StopLoss[i] || data.Low[i] <= data.StopLoss[i])) ||
				(currentAction == "SELL" && (data.Close[i] >= data.StopLoss[i] || data.High[i] >= data.StopLoss[i]))

			if takeProfitCondition || stopLossCondition {
				exitPrice := currentTakeProfit
				closeReason := "hit TP"
				if stopLossCondition {
					exitPrice = data.StopLoss[i]
					closeReason = "hit SL"
				}
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = closeReason
				inBuySell = false
			} else if (currentAction == "BUY" && data.SELL[i] != 0) || (currentAction == "SELL" && data.BUY[i] != 0) {
				exitPrice := data.Close[i]
				pnl := calPNL(margin, currentEntry, exitPrice, investValue)
				if currentAction == "SELL" {
					pnl = calPNL(margin, exitPrice, currentEntry, investValue)
				}
				totalPNL += pnl
				wallet += pnl
				totalTrades++
				if pnl > 0 {
					wins++
					results.WinLose[i] = 1
				} else {
					losses++
					results.WinLose[i] = -1
				}

				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.Exit[i] = exitPrice
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				results.PNL[i] = pnl
				results.Balance[i] = wallet
				results.ClosePosReason[i] = "change trend"

				// currentAction = "SELL"
				if currentAction == "BUY" {
					currentAction = "SELL"
				} else {
					currentAction = "BUY"
				}
				currentEntry = data.Close[i]
				currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
			} else {
				results.Action[i] = currentAction
				results.Entry[i] = currentEntry
				results.TakeProfit[i] = currentTakeProfit
				results.StopLoss[i] = data.StopLoss[i]
				// results.Balance[i] = wallet

			}
		} else if data.BUY[i] != 0 || data.SELL[i] != 0 {
			if data.BUY[i] != 0 {
				currentAction = "BUY"
			} else {
				currentAction = "SELL"
			}
			currentEntry = data.Close[i]
			currentTakeProfit = CalLastPriceFrmROE(currentEntry, investValue, int(margin), currentAction == "BUY", tpPercent)
			// currentStopLoss = data.StopLoss[i]
			inBuySell = true
			// results.Action[i] = currentAction
			// results.Entry[i] = currentEntry
		}

		results.Balance[i] = wallet
	}

	// common.SaveCsv4(results.ToMapSlice(), "detail")

	winRate := 0.0
	if totalTrades > 0 {
		winRate = float64(wins) / float64(totalTrades) * 100
	}

	// Create summary metrics struct
	summary := SummaryMetrics{
		Wins:         wins,
		Losses:       losses,
		TotalTrades:  totalTrades,
		WinRate:      winRate,
		TotalPNL:     totalPNL,
		FinalBalance: wallet,
	}

	return results, summary
}
