from aws_cdk import aws_stepfunctions_tasks as tasks, aws_stepfunctions as sfn

MAIN: str = "main"


class HttpMethod:
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    OPTIONS = "OPTIONS"


class ExchangeName:
    BINANCE = "binance"
    HUOBI = "huobi"


class ExchangeCode:
    BINANCE = "BNB"
    HUOBI = "HTX"


class TradeTypeName:
    FUTURES = "futures"
    ALL = "all"


class TradeTypeCode:
    FUTURES = "FUT"
    ALL = "ALL"


class RuntimeLang:
    PYTHON = "py"
    GOLANG = "go"


class LambdaFunctionConfig:
    def __init__(
        self,
        handler,
        runtime,
        service_name,
        exchange_code,
        exchange_name,
        trade_type_code,
        trade_type_name,
        child_name,
        trigger_interval=None,
        cron_schedule=None,
        memory_size=128,
        concurrent_exec=0,
        additional_config={},
    ):
        self.handler = handler
        self.runtime = runtime
        self.service_name = service_name
        self.exchange_code = exchange_code
        self.exchange_name = exchange_name
        self.trade_type_code = trade_type_code
        self.trade_type_name = trade_type_name
        self.child_name = child_name
        self.additional_config = additional_config
        self.trigger_interval = trigger_interval
        self.cron_schedule = cron_schedule
        self.memory_size = memory_size
        self.concurrent_exec = concurrent_exec

    def to_dict(self):
        return {
            "handler": self.handler,
            "runtime": self.runtime,
            "service_name": self.service_name,
            "exchange_code": self.exchange_code,
            "exchange_name": self.exchange_name,
            "trade_type_code": self.trade_type_code,
            "trade_type_name": self.trade_type_name,
            "child_name": self.child_name,
            "additional_config": self.additional_config,
            "trigger_interval": self.trigger_interval,
            "cron_schedule": self.cron_schedule,
            "memory_size": self.memory_size,
            "concurrent_exec": self.concurrent_exec,
        }


binance_futures_service_config = [
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_pair_admission",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=128,
        concurrent_exec=1,
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_user_admission",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=128,
        concurrent_exec=1,
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_signal_explorer",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=128,
        concurrent_exec=1,
        additional_config={},
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_initiator",
        trigger_interval=None,
        cron_schedule=None,
        # cron_schedule={
        #     "minute": "*/5",
        #     "hour": "*",
        #     "day": "*",
        #     "month": "*",
        #     "year": "*",
        # },
        memory_size=512,
        concurrent_exec=1,
        additional_config={
            "state_machine_task_name": "futures_initiator",
            "next_state_machine_task_name": "futures_signal_processor",
            "is_map_state": False,
            "items_path": "",
            "invoc_type": tasks.LambdaInvocationType.REQUEST_RESPONSE,
            "condition": None,
        },
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_signal_processor",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=2048,
        concurrent_exec=5,
        additional_config={
            "state_machine_task_name": "futures_signal_processor",
            "next_state_machine_task_name": "futures_user_processor",
            "is_map_state": True,  # This should be True to indicate a Map state
            "items_path": "$.Payload.data",
            "invoc_type": tasks.LambdaInvocationType.REQUEST_RESPONSE,
        },
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_order_cleaner",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=512,
        concurrent_exec=1,
        additional_config={
            "http": HttpMethod.POST,
        },
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_user_processor",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=1024,
        concurrent_exec=10,
        additional_config={
            "state_machine_task_name": "futures_user_processor",
            "next_state_machine_task_name": None,
            "is_map_state": True,
            "items_path": "$",
            "invoc_type": tasks.LambdaInvocationType.REQUEST_RESPONSE,
        },
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_user_trader",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=512,
        concurrent_exec=10,
        additional_config={
            "state_machine_task_name": "futures_user_trader",
            "next_state_machine_task_name": None,
            "is_map_state": True,
            "items_path": "$.Payload.data",
            "invoc_type": tasks.LambdaInvocationType.REQUEST_RESPONSE,
            "db_stream": "userOrderTradeSignal",
        },
    ),
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.BINANCE}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.BINANCE,
        exchange_name=ExchangeName.BINANCE,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_spike_tracker",
        trigger_interval=None,
        cron_schedule={
            "minute": "*/1",
            "hour": "*",
            "day": "*",
            "month": "*",
            "year": "*",
        },
        memory_size=256,
        concurrent_exec=1,
        additional_config={},
    ),
]

huobi_futures_service_config = [
    LambdaFunctionConfig(
        handler=MAIN,
        runtime=RuntimeLang.GOLANG,
        service_name=f"{ExchangeName.HUOBI}_{TradeTypeName.FUTURES}_service",
        exchange_code=ExchangeCode.HUOBI,
        exchange_name=ExchangeName.HUOBI,
        trade_type_code=TradeTypeCode.FUTURES,
        trade_type_name=TradeTypeName.FUTURES,
        child_name="futures_tester",
        trigger_interval=None,
        cron_schedule=None,
        memory_size=128,
        concurrent_exec=1,
        additional_config={},
    ),
]

lambda_functions_configs = [
    binance_futures_service_config,
    # huobi_futures_service_config,
]
