#!/usr/bin/env python3
import aws_cdk as cdk

from common_tools import capitalize_join
from trading_ops.lambda_func_service_stack import LambdaFuncServiceStack
from trading_ops.to_api_gateway_integration_stack import ToApiGatewayIntegrationStack
from trading_ops.trading_ops_stack import TradingOpsStack
from lambda_functions_configs import lambda_functions_configs

app = cdk.App()
env_name = app.node.try_get_context("env") or ""
head_title = app.node.try_get_context("head") or ""
acc_id = app.node.try_get_context("acc_id") or ""
region = app.node.try_get_context("region") or ""

missing_contexts = [
    name
    for name, value in {
        "env": env_name,
        "head": head_title,
        "acc_id": acc_id,
        "region": region,
    }.items()
    if not value
]

if missing_contexts:
    raise ValueError(f"Missing required context(s): {', '.join(missing_contexts)}")
else:
    final_function_configurations = []
    for service_config in lambda_functions_configs:
        if len(service_config) == 0:
            continue

        service_name: str = service_config[0].service_name
        exch_code: str = service_config[0].exchange_code
        exch_name: str = service_config[0].exchange_name
        tt_code: str = service_config[0].trade_type_code
        tt_name: str = service_config[0].trade_type_name
        if not service_name or not exch_code:
            continue

        lfs_stack_name = f"{head_title}TOLambdaFuncServiceStack-{capitalize_join(service_name, "_")}-{env_name.upper()}"
        lambda_func_stack = LambdaFuncServiceStack(
            app,
            f"{head_title}TOLambdaFuncServiceStack-{capitalize_join(service_name, "_")}-{env_name.upper()}",
            region,
            env_name,
            service_name,
            exch_code,
            exch_name,
            tt_code,
            tt_name,
            service_config,
            stack_name=lfs_stack_name,
            env=cdk.Environment(account=acc_id, region=region),
        )
        final_function_configurations = final_function_configurations + lambda_func_stack.function_configurations
    
    trading_ops_stack = TradingOpsStack(
        app,
        f"{head_title}TradingOpsStack-{env_name.upper()}",
        stack_name=f"{head_title}TradingOpsStack-{env_name.upper()}",
        env_name=env_name,
        function_configurations=final_function_configurations,
        env=cdk.Environment(account=acc_id, region=region),
    )

    api_gateway_stack = ToApiGatewayIntegrationStack(
        app,
        f"{head_title}ToApiGatewayIntegrationStack-{env_name.upper()}",
        stack_name=f"{head_title}ToApiGatewayIntegrationStack-{env_name.upper()}",
        env_name=env_name,
        function_configurations=final_function_configurations,
        env=cdk.Environment(account=acc_id, region=region),
    )

app.synth()
