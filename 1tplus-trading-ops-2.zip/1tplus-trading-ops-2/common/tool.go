package common

import (
	"bytes"
	"encoding/base64"
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/adshao/go-binance/v2/futures"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/aws/aws-sdk-go/service/kms"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/go-gota/gota/dataframe"
	"github.com/olekukonko/tablewriter"
	"github.com/xuri/excelize/v2"
)

type Progress struct {
	TotalBytes int64
	Uploaded   int64
}

// ProgressWriter struct to write and track progress
type ProgressWriter struct {
	writer   io.Writer
	progress *Progress
}

func (pw *ProgressWriter) Write(p []byte) (int, error) {
	n, err := pw.writer.Write(p)
	if err == nil {
		pw.progress.Uploaded += int64(n)
		fmt.Printf("Uploaded %d/%d bytes (%.2f%%)\n", pw.progress.Uploaded, pw.progress.TotalBytes, float64(pw.progress.Uploaded)*100/float64(pw.progress.TotalBytes))
	}
	return n, err
}

// Function to upload data to S3
func UploadToS3(bucket, key string, data []byte) error {
	sess := session.Must(session.NewSession())
	uploader := s3manager.NewUploader(sess)

	progress := &Progress{TotalBytes: int64(len(data))}
	var buf bytes.Buffer
	progressWriter := &ProgressWriter{
		writer:   &buf,
		progress: progress,
	}

	reader := io.TeeReader(bytes.NewReader(data), progressWriter)

	_, err := uploader.Upload(&s3manager.UploadInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(key),
		Body:   reader,
	})

	return err
}

// Function to convert DataFrame to Excel and upload to S3 with progress tracking
func ConvertAndUploadToS3(df dataframe.DataFrame, bucket, title string) error {
	excelData, err := DataFrameToExcelBytes(df)
	if err != nil {
		return fmt.Errorf("failed to convert DataFrame to Excel: %w", err)
	}

	currentTime := time.Now()
	formattedTime := currentTime.Format("2006-01-02-15-04-05")

	// Create the filename with the formatted date and time
	key := fmt.Sprintf("%s-%s.xlsx", title, formattedTime)

	if err := UploadToS3(bucket, key, excelData); err != nil {
		return fmt.Errorf("failed to upload Excel data to S3: %w", err)
	}

	fmt.Println("Successfully uploaded the DataFrame to S3")
	return nil
}

func GenerateSequence(start, end, step float64) []float64 {
	// Verify that step is positive and non-zero to avoid infinite loops
	if step <= 0 {
		fmt.Println("Step must be a positive number")
		return nil
	}

	// Check if the range is valid
	if start > end {
		fmt.Println("Start value must be less than end value")
		return nil
	}

	// Calculate the number of steps needed (safely handling floating point precision)
	var sequence []float64
	for value := start; value <= end; value += step {
		sequence = append(sequence, value)
	}

	return sequence
}

func CheckForMissingIntervals(df dataframe.DataFrame) ([]time.Time, error) {
	// Extract the OpenTime column as []string
	openTimeSeries := df.Col("OpenTime").Records()

	// Convert from []string to []time.Time
	var times []time.Time
	for _, ot := range openTimeSeries {
		millis, err := strconv.ParseInt(ot, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("error parsing open time: %v", err)
		}
		t := time.UnixMilli(millis)
		times = append(times, t)
	}

	// Sort times just in case they aren't in order
	sort.Slice(times, func(i, j int) bool {
		return times[i].Before(times[j])
	})

	// Check for gaps in the times
	var missing []time.Time
	for i := 1; i < len(times); i++ {
		expected := times[i-1].Add(5 * time.Minute)
		if !times[i].Equal(expected) {
			// Collect the start of the missing interval
			missing = append(missing, expected)
		}
	}

	return missing, nil
}

func PrintDataFrameWithTableWriter(df dataframe.DataFrame) {
	table := tablewriter.NewWriter(os.Stdout)
	headers := df.Names()
	table.SetHeader(headers) // Set the headers from the DataFrame

	timestampCols := make(map[int]bool)
	for i, name := range headers {
		if strings.Contains(name, "Time") {
			timestampCols[i] = true
		}
	}

	nRows := df.Nrow()
	firstRows := 10
	lastRows := 10

	for i := 0; i < nRows; i++ {
		// Render only the first 10 and last 10 rows
		if i < firstRows || i >= nRows-lastRows {
			row := make([]string, df.Ncol())
			for j := 0; j < df.Ncol(); j++ {
				val := df.Elem(i, j).Val()
				if timestampCols[j] { // Check if the column is a timestamp
					switch v := val.(type) {
					case float64:
						t := time.UnixMilli(int64(v))
						row[j] = t.Format("2006-01-02 15:04:05")
					case int64:
						t := time.UnixMilli(v)
						row[j] = t.Format("2006-01-02 15:04:05")
					case int:
						t := time.UnixMilli(int64(v))
						row[j] = t.Format("2006-01-02 15:04:05")
					case string:
						millis, err := strconv.ParseInt(v, 10, 64)
						if err != nil {
							row[j] = "Invalid time"
						} else {
							t := time.UnixMilli(millis)
							row[j] = t.Format("2006-01-02 15:04:05")
						}
					default:
						row[j] = "Invalid time"
					}
				} else {
					// Handle non-time columns
					switch v := val.(type) {
					case float64:
						row[j] = strconv.FormatFloat(v, 'f', -1, 64)
					case int, int64:
						row[j] = fmt.Sprintf("%d", v)
					case string:
						row[j] = v
					default:
						row[j] = "NA"
					}
				}
			}
			table.Append(row)
		}
	}

	table.Render() // Send output
}

func DataFrameToExcelBytes(df dataframe.DataFrame) ([]byte, error) {
	f := excelize.NewFile()
	sheetName := "Sheet1"
	f.SetSheetName(f.GetSheetName(1), sheetName)

	// Write headers
	headers := df.Names()
	for i, header := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1) // Excel cells start at 1, not 0
		f.SetCellValue(sheetName, cell, header)
	}
	for i := 0; i < df.Nrow(); i++ {
		for j := range headers {
			value := df.Elem(i, j).Val()
			cell, _ := excelize.CoordinatesToCellName(j+1, i+2) // Adjust row index for Excel
			f.SetCellValue(sheetName, cell, value)
		}
	}
	// Save to a byte slice
	var buf bytes.Buffer
	if err := f.Write(&buf); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

func IntToInterfaceSlice(ints []int) []interface{} {
	result := make([]interface{}, len(ints))
	for i, v := range ints {
		result[i] = v
	}
	return result
}

func FloatToInterfaceSlice(floats []float64) []interface{} {
	result := make([]interface{}, len(floats))
	for i, v := range floats {
		result[i] = v
	}
	return result
}

func Product(raws [][]interface{}) [][]interface{} {
	if len(raws) == 0 {
		return nil
	}
	if len(raws) == 1 {
		result := make([][]interface{}, len(raws[0]))
		for i, v := range raws[0] {
			result[i] = []interface{}{v}
		}
		return result
	}
	prev := Product(raws[:len(raws)-1])
	result := make([][]interface{}, 0)
	for _, x := range prev {
		for _, y := range raws[len(raws)-1] {
			comb := append([]interface{}{}, x...)
			comb = append(comb, y)
			result = append(result, comb)
		}
	}
	return result
}

func KlineToCsv(klines []*futures.Kline) {
	var resultsBatch []map[string]interface{}
	for _, kline := range klines {
		// log.Println(kline.TradeNum)
		resultsBatch = append(resultsBatch, map[string]interface{}{
			"OpenTime":                 time.Unix(0, kline.OpenTime*int64(time.Millisecond)).Format(time.RFC3339),
			"Open":                     kline.Open,
			"High":                     kline.High,
			"Low":                      kline.Low,
			"Close":                    kline.Close,
			"Volume":                   kline.Volume,
			"CloseTime":                time.Unix(0, kline.CloseTime*int64(time.Millisecond)).Format(time.RFC3339),
			"QuoteAssetVolume":         kline.QuoteAssetVolume,
			"TradeNum":                 strconv.FormatInt(kline.TradeNum, 10),
			"TakerBuyBaseAssetVolume":  kline.TakerBuyBaseAssetVolume,
			"TakerBuyQuoteAssetVolume": kline.TakerBuyQuoteAssetVolume,
		})
	}
	SaveCsv4(resultsBatch, "klines")
}

func SaveCsv4(res []map[string]interface{}, fileName string) {
	// Create a new CSV file
	currentTime := time.Now()
	formattedTime := currentTime.Format("2006-01-02-15-04-05")

	// Create the filename with the formatted date and time
	path := fmt.Sprintf("C:/1tplus/%s-%s.csv", fileName, formattedTime)
	log.Println(path)
	file, err := os.Create(path)
	if err != nil {
		log.Fatalln("Failed to create file", err)
	}
	defer file.Close()

	// Create a CSV writer
	writer := csv.NewWriter(file)
	defer writer.Flush()

	if len(res) > 0 {
		// Write the header
		var header []string
		for key := range res[0] {
			header = append(header, key)
		}
		if err := writer.Write(header); err != nil {
			log.Fatalln("Error writing header to CSV", err)
		}

		// Write the records
		for _, record := range res {
			var row []string
			for _, key := range header {
				switch v := record[key].(type) {
				case string:
					row = append(row, v)
				case int:
					row = append(row, strconv.Itoa(v))
				case float64:
					row = append(row, strconv.FormatFloat(v, 'f', -1, 64))
				default:
					row = append(row, "")
				}
			}
			if err := writer.Write(row); err != nil {
				log.Fatalln("Error writing record to CSV", err)
			}
		}
	}

	log.Println("CSV file created successfully at:", path)
}

func ConvertStringToFloat64(value string) (float64, error) {
	floatValue, err := strconv.ParseFloat(value, 64)
	if err != nil {
		return 0, fmt.Errorf("error converting %s to float64: %v", value, err)
	}
	return floatValue, nil
}

func FetchActiveTradePairs(exchangeCode, tradeTypeCode string, desiredIntervals []string) ([]TradePair, error) {
	sess := session.Must(session.NewSession())
	svc := dynamodb.New(sess)

	input := &dynamodb.QueryInput{
		TableName:              aws.String(TradePairTableName),  // Replace with your table name
		IndexName:              aws.String("ActiveConfigIndex"), // Using the GSI
		KeyConditionExpression: aws.String("IsActive = :isActive AND Exch_TradeType = :exchTradeType"),
		ExpressionAttributeValues: map[string]*dynamodb.AttributeValue{
			":isActive": {
				S: aws.String("true"),
			},
			":exchTradeType": {
				S: aws.String(exchangeCode + "_" + tradeTypeCode),
			},
		},
	}

	// Execute the scan operation
	result, err := svc.Query(input)
	if err != nil {
		return nil, fmt.Errorf("failed to query active configurations: %w", err)
	}

	// Unmarshal the result into a slice of TradePair structs
	var tradePairs []TradePair
	err = dynamodbattribute.UnmarshalListOfMaps(result.Items, &tradePairs)
	if err != nil {
		return nil, err
	}

	// Convert desiredIntervals slice to a map for quick lookup
	intervalMap := make(map[string]bool)
	for _, interval := range desiredIntervals {
		intervalMap[interval] = true
	}

	// Filter trade pairs by checking if their Interval is in the intervalMap
	filteredTradePairs := []TradePair{}
	for _, tradePair := range tradePairs {
		if _, exists := intervalMap[tradePair.Interval]; exists {
			filteredTradePairs = append(filteredTradePairs, tradePair)
		}
	}

	return filteredTradePairs, nil
}

func DecryptSecretKey(kmsClient *kms.KMS, encryptedData string) (string, error) {
	data, err := base64.StdEncoding.DecodeString(encryptedData)
	if err != nil {
		return "", fmt.Errorf("base64 decode error: %v", err)
	}

	input := &kms.DecryptInput{
		KeyId:          aws.String(ApiKeyKmsArn),
		CiphertextBlob: data,
	}

	result, err := kmsClient.Decrypt(input)
	if err != nil {
		return "", fmt.Errorf("decrypt error: %v", err)
	}

	return string(result.Plaintext), nil
}

func GetAndDecryptAPIKeys(dbClient *dynamodb.DynamoDB, kmsClient *kms.KMS, userID string) (string, string, error) {
	result, err := dbClient.Query(&dynamodb.QueryInput{
		TableName:              aws.String(ApiKeyTableName),
		KeyConditionExpression: aws.String("UserID = :userID AND Exchange = :exchangeCode"),
		ExpressionAttributeValues: map[string]*dynamodb.AttributeValue{
			":userID": {
				S: aws.String(userID),
			},
			":exchangeCode": {
				S: aws.String(ExchCode),
			},
		},
	})
	if err != nil {
		return "", "", fmt.Errorf("error retrieving API keys from DynamoDB: %w", err)
	}
	var apiKeys []ApiKeyDynamoDBItem
	err = dynamodbattribute.UnmarshalListOfMaps(result.Items, &apiKeys)
	if err != nil {
		return "", "", fmt.Errorf("failed to unmarshal DynamoDB response: %w", err)
	}

	apiKey := ""
	decryptedSecretKey := ""
	if len(apiKeys) > 0 {
		apiKey = apiKeys[0].APIKey
		decryptedSecretKey, err = DecryptSecretKey(kmsClient, apiKeys[0].EncryptedSecretKey)
		if err != nil {
			return "", "", fmt.Errorf("failed to decrypt secret key: %w", err)
		}
	}

	return apiKey, decryptedSecretKey, nil
}

var divisors = map[int]string{
	60: "1h",
	30: "30m",
	15: "15m",
	10: "10m",
	5:  "5m",
}

func GetDivisibleIntervals() []string {
	now := time.Now()
	minute := now.Minute()

	var intervals []string

	for divisor, label := range divisors {
		if minute%divisor == 0 {
			intervals = append(intervals, label)
		}
	}

	return intervals
}

func GetAllIntervals() []string {
	var intervals []string
	for _, label := range divisors {
		intervals = append(intervals, label)
	}
	return intervals
}

func IsValidInterval(interval string) bool {
	now := time.Now()
	minute := now.Minute()

	// Reverse the map to find the corresponding minute value for the interval string
	for divisor, label := range divisors {
		if label == interval {
			return minute%divisor == 0
		}
	}

	// Interval not found in the map
	return false
}

func GetThresholdMinutes(timeLimitMinutes int) int64 {
	currentTime := time.Now().UTC()
	thresholdTime := currentTime.Add(-time.Duration(timeLimitMinutes) * time.Minute).UnixMilli()

	return thresholdTime
}

func ContainsStr(list []string, str string) bool {
	set := make(map[string]struct{})
	for _, v := range list {
		set[v] = struct{}{}
	}
	_, exists := set[str]
	return exists
}

func CheckAnySubstringExistence(input string, substrings []string) bool {
	for _, substring := range substrings {
		pattern := "_" + substring + "_"
		if strings.Contains(input, pattern) {
			return true
		}
	}
	return false
}

type UserExchTradeTypeCapRisk struct {
	UserID                        string  `json:"UserID"`
	ExchTradeTypeCapRiskTradePair string  `json:"Exch_TradeType_CapRisk_TradePair"`
	ExchTradeType                 string  `json:"Exch_TradeType"`
	CapRiskTradePair              string  `json:"CapRisk_TradePair"`
	TradePair                     string  `json:"TradePair"`
	AllocVolume                   float64 `json:"Alloc_Volume"`
	IsActive                      string  `json:"IsActive"`
	CreationDate                  string  `json:"CreationDate"`
}

func GetUserActiveCapRiskByTradePair(db *dynamodb.DynamoDB, tradePair string) ([]UserExchTradeTypeCapRisk, error) {
	input := &dynamodb.QueryInput{
		TableName: aws.String(UserCapRiskTableName),
		IndexName: aws.String("ActiveUserCapRiskPairIndex"),
		KeyConditions: map[string]*dynamodb.Condition{
			"IsActive": {
				AttributeValueList: []*dynamodb.AttributeValue{
					{S: aws.String("true")},
				},
				ComparisonOperator: aws.String("EQ"),
			},
			"Exch_TradeType_CapRisk_TradePair": {
				AttributeValueList: []*dynamodb.AttributeValue{
					{S: aws.String(tradePair)},
				},
				ComparisonOperator: aws.String("EQ"),
			},
		},
	}

	result, err := db.Query(input)
	if err != nil {
		return nil, err
	}

	var records []UserExchTradeTypeCapRisk
	err = dynamodbattribute.UnmarshalListOfMaps(result.Items, &records)
	if err != nil {
		return nil, err
	}

	return records, nil
}

func ToTitleCase(input string) string {
	words := strings.Fields(input)
	for i, word := range words {
		words[i] = strings.ToUpper(string(word[0])) + strings.ToLower(word[1:])
	}
	return strings.Join(words, " ")
}

func RenameCR4Display(input string) string {
	// Replace "FUT" with "FTRS"
	result := strings.ReplaceAll(input, "FUT", "FTRS")
	// Replace "BNB" with "BIN"
	result = strings.ReplaceAll(result, "BNB", "BIN")
	return result
}

func IsFloat(str string) bool {
	_, err := strconv.ParseFloat(str, 64)
	return err == nil
}
