package common

import (
	"encoding/json"
	"errors"
	"reflect"
)

type Response struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

type TradePair struct {
	ExchangeTradeTypeCapRiskTradePair string `json:"Exch_TradeType_CapRisk_TradePair"`
	ExchangeTradeType                 string `json:"Exch_TradeType"`
	ExchangeCode                      string `json:"Exch"`
	TradeTypeCode                     string `json:"TradeType"`
	CapitalRiskCode                   string `json:"CapRisk"`
	TradePair                         string `json:"TradePair"`
	Interval                          string `json:"Interval"`
	ReqCapVol                         string `json:"ReqCapVol"`
	Priority                          string `json:"Priority"`
	AlgorithmFunction                 string `json:"AlgorithmFunction"`
	FunctionArguments                 string `json:"FunctionArguments"`
	IsActive                          string `json:"IsActive"`
	IsPaused                          string `json:"IsPaused"`
	CreationDate                      string `json:"CreationDate"`
}

type BinanceFuturesOrder struct {
	UserID                            string `json:"userID"`
	ExchangeTradeTypeCapRiskTradePair string `json:"exchTradeTypeCapRiskTradePair"`
	Symbol                            string `json:"symbol"`
	Interval                          string `json:"Interval"`
	Side                              string `json:"side"`
	Leverage                          string `json:"leverage"`
	InvestVolPercent                  string `json:"investVolPercent"`
	InvestCapitalVol                  string `json:"investCapitalVol"`
	Quantity                          string `json:"quantity"`
	EntryPrice                        string `json:"entryPrice"`
	StopLossPrice                     string `json:"stopLossPrice"`
	TakeProfitPrice                   string `json:"takeProfitPrice"`
	QuantityPrecision                 string `json:"quantityPrecision"`
	PricePrecision                    string `json:"pricePrecision"`
	ActualLossLimit                   string `json:"actualLossLimit"`
}

type ApiKeyDynamoDBItem struct {
	UserID             string `dynamodbav:"UserID"`
	Exchange           string `dynamodbav:"Exchange"`
	APIKey             string `dynamodbav:"APIKey"`
	EncryptedSecretKey string `dynamodbav:"EncryptedSecretKey"`
	IsActive           string `dynamodbav:"IsActive"`
	CreationDate       string `dynamodbav:"CreationDate"`
	LastUpdated        string `dynamodbav:"LastUpdated"`
	IsActive_Exchange  string `dynamodbav:"IsActive_Exchange"`
}

// GetNestedDataAndUnmarshal retrieves a nested map value and unmarshals it into the provided result struct.
// func GetNestedDataAndUnmarshal(request map[string]interface{}, path []string, result interface{}) error {
// 	// Retrieve nested map value based on the provided path
// 	value, err := GetNestedMapValue(request, path)
// 	if err != nil {
// 		return err
// 	}

// 	// Type assert to map[string]interface{}
// 	dataMap, ok := value.(map[string]interface{})
// 	if !ok {
// 		return errors.New("invalid data format")
// 	}

// 	// Marshal the data map to JSON
// 	dataBytes, err := json.Marshal(dataMap)
// 	if err != nil {
// 		return errors.New("failed to marshal data: " + err.Error())
// 	}

// 	// Unmarshal the JSON to the result struct
// 	err = json.Unmarshal(dataBytes, result)
// 	if err != nil {
// 		return errors.New("failed to unmarshal data: " + err.Error())
// 	}

//		return nil
//	}
func GetNestedDataAndUnmarshal(request map[string]interface{}, path []string, result interface{}) error {
	// Retrieve nested map value based on the provided path
	value, err := GetNestedMapValue(request, path)
	if err != nil {
		return err
	}

	resultValue := reflect.ValueOf(result)
	if resultValue.Kind() != reflect.Ptr || resultValue.IsNil() {
		return errors.New("result must be a non-nil pointer")
	}

	switch v := value.(type) {
	case map[string]interface{}:
		// Marshal the data map to JSON
		dataBytes, err := json.Marshal(v)
		if err != nil {
			return errors.New("failed to marshal data: " + err.Error())
		}

		// Unmarshal the JSON to the result struct
		err = json.Unmarshal(dataBytes, result)
		if err != nil {
			return errors.New("failed to unmarshal data: " + err.Error())
		}
	case float64:
		// Handle float64 separately to allow for type conversion
		elem := resultValue.Elem()
		if elem.Kind() == reflect.Int {
			elem.SetInt(int64(v))
		} else if elem.Kind() == reflect.Float64 {
			elem.SetFloat(v)
		} else {
			return errors.New("type mismatch; cannot assign float64 to " + elem.Kind().String())
		}
	case int, string, bool:
		elem := resultValue.Elem()
		if elem.Kind() == reflect.TypeOf(v).Kind() {
			elem.Set(reflect.ValueOf(v))
		} else {
			return errors.New("type mismatch; cannot assign " + reflect.TypeOf(v).String() + " to " + elem.Kind().String())
		}
	default:
		return errors.New("unexpected data type at key")
	}

	return nil
}

// GetNestedMapValue retrieves a nested value from a map based on the given path.
func GetNestedMapValue(data map[string]interface{}, path []string) (interface{}, error) {
	if len(path) == 0 {
		return nil, errors.New("path cannot be empty")
	}

	current := data
	for i, key := range path {
		value, exists := current[key]
		if !exists {
			return nil, errors.New("key not found in path: " + key)
		}

		if i == len(path)-1 {
			return value, nil
		}

		// Type assertion to map for nested value
		next, ok := value.(map[string]interface{})
		if !ok {
			return nil, errors.New("value is not a map at key: " + key)
		}
		current = next
	}

	return nil, errors.New("invalid path")
}
