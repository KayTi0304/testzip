package common

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/secretsmanager"
	_ "github.com/go-sql-driver/mysql"
)

var DB *sql.DB

func init() {
	// Initialize a secrets manager session
	sess := session.Must(session.NewSession())
	sm := secretsmanager.New(sess)

	secretName := os.Getenv("DB_CREDENTIALS_SECRET")
	secretValue, err := sm.GetSecretValue(&secretsmanager.GetSecretValueInput{
		SecretId: aws.String(secretName),
	})
	if err != nil {
		log.Printf("Error for db init GetSecretValue: %v", err)
		panic(err)
	}

	var secretMap map[string]interface{}

	err = json.Unmarshal([]byte(*secretValue.SecretString), &secretMap)
	if err != nil {
		log.Printf("Error for db init jsonUnmarshal: %v", err)
		panic(err)
	}

	// Convert port to string if it's a number
	port, ok := secretMap["port"]
	if ok {
		switch v := port.(type) {
		case float64:
			secretMap["port"] = strconv.FormatFloat(v, 'f', 0, 64)
		case string:
			// no action needed
		default:
			panic("unexpected type for port")
		}
	}

	// Construct connection string
	// Assuming all other values are strings
	connectionString := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s",
		secretMap["username"].(string),
		secretMap["password"].(string),
		secretMap["host"].(string),
		secretMap["port"].(string), // Now safely asserting as string
		secretMap["dbname"].(string),
	)
	DB, err = sql.Open("mysql", connectionString)
	if err != nil {
		log.Printf("Error for db init Open Connection: %v", err)
		panic(err)
	}
}
