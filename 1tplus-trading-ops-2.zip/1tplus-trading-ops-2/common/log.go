package common

import "log"

func Log4Trace(err error, discPurpose, discMsg string) {
	if err != nil {
		log.Printf("Error occurred: %v", err)
	}
	log.Printf("Discord Msg: %s", discMsg)
	SendToDiscord(discPurpose, discMsg)
}
