package common

import (
	"context"
	"fmt"
	"log"
	"math"
	"strconv"
	"strings"
	"time"

	"github.com/adshao/go-binance/v2/futures"
	"github.com/go-gota/gota/dataframe"
	"golang.org/x/time/rate"
)

func countDecimals(value string) int {
	decimalPoint := false
	count := 0
	for _, char := range value {
		if decimalPoint {
			count++
		}
		if char == '.' {
			decimalPoint = true
		}
	}
	return count
}

func GetTickSize(client *futures.Client, symbol string) (float64, error) {
	exchangeInfo, err := client.NewExchangeInfoService().Do(context.Background())
	if err != nil {
		return 0, err
	}

	for _, s := range exchangeInfo.Symbols {
		if s.Symbol == symbol {
			for _, filter := range s.Filters {
				if filter["filterType"].(string) == "PRICE_FILTER" {
					tickSize, err := strconv.ParseFloat(filter["tickSize"].(string), 64)
					if err != nil {
						return 0, err
					}
					return tickSize, nil
				}
			}
		}
	}

	return 0, fmt.Errorf("symbol not found")
}

func GetPriceQuantityPrecision(client *futures.Client, symbolName string) (int, int, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second) // Adjust the timeout as needed
	defer cancel()

	exchangeInfo, err := client.NewExchangeInfoService().Do(ctx)
	if err != nil {
		return -1, -1, fmt.Errorf("failed to fetch exchange information: %v", err)
	}

	for _, symbol := range exchangeInfo.Symbols {
		if symbol.Symbol == symbolName {
			if symbol.PricePrecision >= 0 && symbol.QuantityPrecision >= 0 {
				return symbol.PricePrecision, symbol.QuantityPrecision, nil
			} else {
				log.Printf("Precision not found for symbol: %+v\n", symbol)
				// Try extracting from filters if not directly available
				pricePrecision := -1
				quantityPrecision := -1
				for _, filter := range symbol.Filters {
					if filter["filterType"] == "PRICE_FILTER" {
						pricePrecision = countDecimals(filter["tickSize"].(string))
					}
					if filter["filterType"] == "LOT_SIZE" {
						quantityPrecision = countDecimals(filter["stepSize"].(string))
					}
				}
				if pricePrecision >= 0 && quantityPrecision >= 0 {
					return pricePrecision, quantityPrecision, nil
				}
			}
		}
	}

	return -1, -1, fmt.Errorf("symbol not found: %s", symbolName)
}

func GetActiveUSDTFuturesPairs(client *futures.Client) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second) // Adjust the timeout as needed
	defer cancel()
	exchangeInfo, err := client.NewExchangeInfoService().Do(ctx)
	if err != nil {
		return nil, fmt.Errorf("error getting exchange info: %w", err)
	}

	var usdtPairs []string
	for _, symbol := range exchangeInfo.Symbols {
		if symbol.QuoteAsset == "USDT" && symbol.Status == "TRADING" {
			usdtPairs = append(usdtPairs, symbol.Symbol)
		}
	}

	return usdtPairs, nil
}

func GetMaxLeverage(client *futures.Client, symbol string) (int, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second) // Adjust the timeout as needed
	defer cancel()

	leverageBrackets, err := client.NewGetLeverageBracketService().Symbol(symbol).Do(ctx)
	if err != nil {
		return 0, fmt.Errorf("error getting leverage brackets: %w", err)
	}

	if len(leverageBrackets) == 0 {
		return 0, fmt.Errorf("no leverage brackets found for symbol: %s", symbol)
	}

	// The maximum leverage is the highest leverage in the first bracket
	// since leverage brackets are ordered by notional value
	maxLeverage := leverageBrackets[0].Brackets[0].InitialLeverage
	for _, bracket := range leverageBrackets[0].Brackets {
		if bracket.InitialLeverage > maxLeverage {
			maxLeverage = bracket.InitialLeverage
		}
	}

	// Ensure the maximum leverage does not exceed 100
	// if maxLeverage > 100 {
	// 	maxLeverage = 100
	// }

	return maxLeverage, nil
}

var rateLimiter = rate.NewLimiter(rate.Every(1*time.Second), 4)

func FetchBinanceFuturesKline(client *futures.Client, symbol, interval string, prevDaysFromNow int) ([]*futures.Kline, error) {
	// client := binance.NewFuturesClient(apiKey, secretKey)
	err := rateLimiter.Wait(context.Background())
	if err != nil {
		return nil, err
	}
	// Create a context with a timeout
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second) // Adjust the timeout as needed
	defer cancel()

	endTime := time.Now()
	startTime := endTime.AddDate(0, 0, -prevDaysFromNow)

	var allKlines []*futures.Kline
	for {
		klines, err := client.NewKlinesService().
			Symbol(symbol).
			Interval(interval).
			StartTime(startTime.UnixMilli()).
			EndTime(endTime.UnixMilli()).
			Limit(1000). // Max limit allowed by Binance
			Do(ctx)
		if err != nil {
			return allKlines, fmt.Errorf("error fetching futures price history: %v", err)
		}

		allKlines = append(allKlines, klines...)
		if len(klines) < 1000 {
			break // Break if the last request returned less than the limit, indicating it's the last batch
		}

		// Update startTime to the last kline's close time for the next batch
		lastKline := klines[len(klines)-1]
		startTime = time.UnixMilli(lastKline.CloseTime + 1)
	}

	return allKlines, nil
}

func FetchBinanceFuturesDf(client *futures.Client, symbol, interval string, prevDaysFromNow int) (dataframe.DataFrame, error) {

	klines, err := FetchBinanceFuturesKline(client, symbol, interval, prevDaysFromNow)
	if err != nil {
		return dataframe.DataFrame{}, fmt.Errorf("error fetching futures price history: %v", err)
	}

	// Convert []*futures.Kline to []map[string]interface{} for DataFrame creation
	records := make([]map[string]interface{}, len(klines))
	for i, kline := range klines {
		records[i] = map[string]interface{}{
			"OpenTime":                 kline.OpenTime,
			"Open":                     kline.Open,
			"High":                     kline.High,
			"Low":                      kline.Low,
			"Close":                    kline.Close,
			"Volume":                   kline.Volume,
			"CloseTime":                kline.CloseTime,
			"QuoteAssetVolume":         kline.QuoteAssetVolume,
			"NumberOfTrades":           kline.TradeNum,
			"TakerBuyBaseAssetVolume":  kline.TakerBuyBaseAssetVolume,
			"TakerBuyQuoteAssetVolume": kline.TakerBuyQuoteAssetVolume,
		}
	}

	// Create a DataFrame from the records
	df := dataframe.LoadMaps(records)
	log.Printf("DataFrame created with %d rows", df.Nrow())
	return df, nil
}

func FetchKlinesWithRetry(client *futures.Client, symbol string, interval string, prevDaysFromNow int) ([]*futures.Kline, error) {
	var klines []*futures.Kline
	var err error
	for retries := 0; retries < 5; retries++ {
		klines, err = FetchBinanceFuturesKline(client, symbol, interval, prevDaysFromNow)
		if err == nil {
			return klines, nil
		}
		log.Printf("Error fetching data for %s: %v. Retrying...", symbol, err)
		time.Sleep(time.Duration(retries*2) * time.Second) // Exponential backoff
	}
	return nil, fmt.Errorf("failed to fetch klines after retries: %w", err)
}

func IsPositionOpen(client *futures.Client, symbol string) (bool, *futures.PositionRisk, error) {
	positionRisk, err := client.NewGetPositionRiskService().Do(context.Background())
	if err != nil {
		return false, nil, err
	}

	for _, position := range positionRisk {
		if position.Symbol == symbol {
			positionAmt, err := strconv.ParseFloat(position.PositionAmt, 64)
			if err != nil {
				log.Printf("Error parsing PositionAmt: %v", err)
				return false, nil, err
			}
			log.Printf("PositionAmt for %s: %f", symbol, positionAmt)
			if positionAmt != 0 {
				return true, position, nil
			}
		}
	}

	return false, nil, nil
}

func GetOpenOrders(client *futures.Client, symbol string) ([]*futures.Order, error) {
	return client.NewListOpenOrdersService().Symbol(symbol).Do(context.Background())
}

func CancelOrder(client *futures.Client, symbol string, orderID int64) error {
	_, err := client.NewCancelOrderService().Symbol(symbol).OrderID(orderID).Do(context.Background())
	return err
}

func UpdateStopMarketOrder(client *futures.Client, symbol string, newStopPrice float64) error {
	openOrders, err := GetOpenOrders(client, symbol)
	if err != nil {
		return err
	}

	for _, order := range openOrders {
		if order.Type == futures.OrderTypeStopMarket {
			pricePrecision, _, err := GetPriceQuantityPrecision(client, symbol)
			if err != nil {
				return err
			}
			_, err = client.NewCancelOrderService().
				Symbol(symbol).
				OrderID(order.OrderID).
				Do(context.Background())
			if err != nil {
				return err
			}

			_, err = client.NewCreateOrderService().
				Symbol(symbol).
				Side(order.Side).
				Type(futures.OrderTypeStopMarket).
				StopPrice(strconv.FormatFloat(newStopPrice, 'f', pricePrecision, 64)).
				Quantity(order.OrigQuantity).
				Do(context.Background())
			if err != nil {
				return err
			}

			fmt.Printf("Stop market order for %s updated to stop price: %.2f\n", symbol, newStopPrice)
			break
		}
	}

	return nil
}

func UpdateStopOrder4Pos(client *futures.Client, posRisk *futures.PositionRisk, newStopPrice float64, bnbFutOrder BinanceFuturesOrder) error {
	openOrders, err := GetOpenOrders(client, posRisk.Symbol)
	if err != nil {
		return err
	}

	slIsExist := false
	tpIsExist := false

	for _, order := range openOrders {
		if order.Type == futures.OrderTypeStop {
			slIsExist = true
			pricePrecision, _, err := GetPriceQuantityPrecision(client, posRisk.Symbol)
			if err != nil {
				return err
			}
			_, err = client.NewCancelOrderService().
				Symbol(posRisk.Symbol).
				OrderID(order.OrderID).
				Do(context.Background())
			if err != nil {
				return err
			}

			_, err = client.NewCreateOrderService().
				Symbol(posRisk.Symbol).
				Side(order.Side).
				Type(futures.OrderTypeStop).
				TimeInForce(futures.TimeInForceTypeGTC).
				StopPrice(strconv.FormatFloat(newStopPrice, 'f', pricePrecision, 64)).
				Price(strconv.FormatFloat(newStopPrice, 'f', pricePrecision, 64)).
				Quantity(order.OrigQuantity).
				ReduceOnly(true).
				Do(context.Background())
			if err != nil {
				return err
			}

			fmt.Printf("Stop order for %s updated to stop price: %.2f\n", posRisk.Symbol, newStopPrice)
			break
		} else if order.Type == futures.OrderTypeTakeProfit {
			tpIsExist = true
		}
	}

	if !slIsExist || !tpIsExist {
		// newOpenOrders, err := GetOpenOrders(client, posRisk.Symbol)
		// if err != nil {
		// 	return err
		// }
		// for _, ord := range newOpenOrders {
		// 	if err := CancelOrder(client, posRisk.Symbol, ord.OrderID); err != nil {
		// 		return fmt.Errorf("failed to clear order: %v", err)
		// 	}
		// }
		return fmt.Errorf("no TP/SL found")
		// err = RecoverSlTp(client, posRisk, bnbFutOrder)
		// if err != nil {
		// 	return err
		// }
	}

	return nil
}

func CloseFutPosition(client *futures.Client, position *futures.PositionRisk, currentPosSide string) error {
	quantity := position.PositionAmt
	quantity = strings.TrimPrefix(quantity, "-")

	side := futures.SideTypeSell
	if currentPosSide == SELL {
		side = futures.SideTypeBuy
	}

	order, err := client.NewCreateOrderService().
		Symbol(position.Symbol).
		Side(side).
		Type(futures.OrderTypeMarket).
		Quantity(quantity).
		Do(context.Background())
	if err != nil {
		return err
	}

	log.Printf("Closed position: %+v\n", order)
	return nil
}

func GetPositionInfo(p *futures.PositionRisk) (string, float64, error) {
	amt, err := strconv.ParseFloat(p.PositionAmt, 64)
	if err != nil {
		return "", 0, err
	}
	quantity := math.Abs(amt)
	var side string
	if amt > 0 {
		side = BUY
	} else if amt < 0 {
		side = SELL
	} else {
		side = "FLAT"
	}
	return side, quantity, nil
}

func GetAdjustedPrice(client *futures.Client, price float64, symbol string) (float64, error) {
	tickSize, err := GetTickSize(client, symbol)
	if err != nil {
		return 0, fmt.Errorf("failed to get tickSize: %v", err)
	}
	price = adjustPriceToTickSize(price, tickSize)
	return math.Floor(price/tickSize) * tickSize, nil
}

func adjustPriceToTickSize(price float64, tickSize float64) float64 {
	return math.Floor(price/tickSize) * tickSize
}

func CalLastPriceFrmROE(entry, cost float64, leverage int, inBuy bool, roe float64) float64 {
	positionMultiplier := 1.0
	if !inBuy {
		positionMultiplier = -1.0
	}
	roeProfitLoss := (roe / 100) * cost
	lastPrice := entry + ((roeProfitLoss / (cost * float64(leverage)) * entry) * positionMultiplier)
	// return math.Round(lastPrice)
	return lastPrice
}

func SetFuturesLeverage4Symbol(client *futures.Client, order BinanceFuturesOrder) error {
	leverage, err := strconv.Atoi(order.Leverage)
	if err != nil {
		return fmt.Errorf("invalid leverage: %v", err)
	}
	_, err = client.NewChangeLeverageService().
		Symbol(order.Symbol).
		Leverage(leverage).
		Do(context.Background())
	if err != nil {
		return fmt.Errorf("failed to set leverage: %v", err)
	}

	return nil
}

func isSuccessfulOrderStatus(status futures.OrderStatusType) bool {
	successStatuses := []futures.OrderStatusType{
		futures.OrderStatusTypeNew,
		futures.OrderStatusTypePartiallyFilled,
		futures.OrderStatusTypeFilled,
	}
	for _, s := range successStatuses {
		if status == s {
			return true
		}
	}
	return false
}

func CreatePosLimitOrder(client *futures.Client, order BinanceFuturesOrder, side futures.SideType) (int64, error) {
	const (
		maxRetries  = 3
		retryDelay  = time.Second * 3
		verifyDelay = time.Second * 1
	)
	var limitOrderResponse *futures.CreateOrderResponse
	var err error

	for i := 0; i < maxRetries; i++ {
		limitTradeOrder := client.NewCreateOrderService().
			Symbol(order.Symbol).
			Side(side).
			Type(futures.OrderTypeLimit).
			TimeInForce(futures.TimeInForceTypeGTC).
			Quantity(order.Quantity).
			Price(order.EntryPrice)

		limitOrderResponse, err = limitTradeOrder.Do(context.Background())
		if err == nil {
			time.Sleep(verifyDelay)
			orderID := limitOrderResponse.OrderID
			orderStatus, err := client.NewGetOrderService().Symbol(order.Symbol).OrderID(orderID).Do(context.Background())
			if err == nil && isSuccessfulOrderStatus(orderStatus.Status) {
				return orderID, nil
			} else if err != nil {
				log.Printf("Verification failed (attempt %d/%d) for existing limit trade order: %v", i+1, maxRetries, err)
			} else {
				log.Printf("Order status mismatch (attempt %d/%d) for existing limit trade order: status = %s", i+1, maxRetries, orderStatus.Status)
			}
		} else {
			log.Printf("Failed to place limit trade order (attempt %d/%d): %v", i+1, maxRetries, err)
		}
		time.Sleep(retryDelay)
	}

	return 0, fmt.Errorf("failed to place limit trade order after %d attempts: %v", maxRetries, err)
}

func CreateMartStopLoss(client *futures.Client, order BinanceFuturesOrder, stopMartSide futures.SideType) (int64, error) {
	// stopLossOrder := client.NewCreateOrderService().
	// 	Symbol(order.Symbol).
	// 	Side(stopMartSide).
	// 	Type(futures.OrderTypeStopMarket).
	// 	StopPrice(order.StopLossPrice).
	// 	ClosePosition(true)

	// stopLossResponse, err := stopLossOrder.Do(context.Background())
	// if err != nil {
	// 	return 0, fmt.Errorf("failed to place market stop loss order: %v", err)
	// }

	// return stopLossResponse.OrderID, nil
	const (
		maxRetries  = 3
		retryDelay  = time.Second * 3
		verifyDelay = time.Second * 1
	)
	var stopLossResponse *futures.CreateOrderResponse
	var err error

	for i := 0; i < maxRetries; i++ {
		stopLossOrder := client.NewCreateOrderService().
			Symbol(order.Symbol).
			Side(stopMartSide).
			Type(futures.OrderTypeStopMarket).
			StopPrice(order.StopLossPrice).
			ClosePosition(true)

		stopLossResponse, err = stopLossOrder.Do(context.Background())
		if err == nil {
			time.Sleep(verifyDelay)
			orderID := stopLossResponse.OrderID
			orderStatus, err := client.NewGetOrderService().Symbol(order.Symbol).OrderID(orderID).Do(context.Background())
			if err == nil && isSuccessfulOrderStatus(orderStatus.Status) {
				return orderID, nil
			} else if err != nil {
				log.Printf("Verification failed (attempt %d/%d) for existing stop loss: %v", i+1, maxRetries, err)
			} else {
				log.Printf("Order status mismatch (attempt %d/%d) for existing stop loss: status = %s", i+1, maxRetries, orderStatus.Status)
			}
		} else {
			log.Printf("Failed to place stop loss order (attempt %d/%d): %v", i+1, maxRetries, err)
		}
		time.Sleep(retryDelay)
	}

	return 0, fmt.Errorf("failed to place stop loss order after %d attempts: %v", maxRetries, err)
}

func CreateMartTakeProfit(client *futures.Client, order BinanceFuturesOrder, stopMartSide futures.SideType) (int64, error) {
	// takeProfitOrder := client.NewCreateOrderService().
	// 	Symbol(order.Symbol).
	// 	Side(stopMartSide). // Adjust based on your position
	// 	Type(futures.OrderTypeTakeProfitMarket).
	// 	StopPrice(order.TakeProfitPrice).
	// 	ClosePosition(true)

	// takeProfitResponse, err := takeProfitOrder.Do(context.Background())
	// if err != nil {
	// 	return 0, fmt.Errorf("failed to place take profit order: %v", err)
	// }

	// return takeProfitResponse.OrderID, nil
	const (
		maxRetries  = 3
		retryDelay  = time.Second * 3
		verifyDelay = time.Second * 1
	)
	var takeProfitResponse *futures.CreateOrderResponse
	var err error

	for i := 0; i < maxRetries; i++ {
		takeProfitOrder := client.NewCreateOrderService().
			Symbol(order.Symbol).
			Side(stopMartSide).
			Type(futures.OrderTypeTakeProfitMarket).
			StopPrice(order.TakeProfitPrice).
			ClosePosition(true)

		takeProfitResponse, err = takeProfitOrder.Do(context.Background())
		if err == nil {
			time.Sleep(verifyDelay)
			orderID := takeProfitResponse.OrderID
			orderStatus, err := client.NewGetOrderService().Symbol(order.Symbol).OrderID(orderID).Do(context.Background())
			if err == nil && isSuccessfulOrderStatus(orderStatus.Status) {
				return orderID, nil
			} else if err != nil {
				log.Printf("Verification failed (attempt %d/%d) for existing take profit: %v", i+1, maxRetries, err)
			} else {
				log.Printf("Order status mismatch (attempt %d/%d): status = %s", i+1, maxRetries, orderStatus.Status)
			}
		} else {
			log.Printf("Failed to place take profit order (attempt %d/%d): %v", i+1, maxRetries, err)
		}
		time.Sleep(retryDelay)
	}

	// If all retries fail, return an error
	return 0, fmt.Errorf("failed to place take profit order after %d attempts: %v", maxRetries, err)
}

func UpdateMartStopOrder4Pos(client *futures.Client, posRisk *futures.PositionRisk, bnbFutOrder BinanceFuturesOrder) error {
	openOrders, err := GetOpenOrders(client, posRisk.Symbol)
	if err != nil {
		return err
	}

	slIsExist := false
	tpIsExist := false

	var slOrderID int64
	slOrderID = 0
	for _, order := range openOrders {
		if order.Type == futures.OrderTypeStopMarket {
			slIsExist = true
			slOrderID = order.OrderID
			// _, err = client.NewCancelOrderService().
			// 	Symbol(posRisk.Symbol).
			// 	OrderID(order.OrderID).
			// 	Do(context.Background())
			// if err != nil {
			// 	return err
			// }
		} else if order.Type == futures.OrderTypeTakeProfitMarket {
			tpIsExist = true
		}
	}

	if !slIsExist && !tpIsExist {
		return fmt.Errorf("no STOP LOSS AND TAKE PROFIT order found")
	}
	if !slIsExist {
		return fmt.Errorf("no STOP LOSS order found")
	}
	if !tpIsExist {
		return fmt.Errorf("no TAKE PROFIT order found")
	}

	currentPosSide, _, err := GetPositionInfo(posRisk)
	if err != nil {
		return fmt.Errorf("failed to get position side: %v", err)
	}
	stopMartSide := futures.SideTypeSell
	if currentPosSide == SELL {
		stopMartSide = futures.SideTypeBuy
	}

	_, err = client.NewCreateOrderService().
		Symbol(posRisk.Symbol).
		Side(stopMartSide).
		Type(futures.OrderTypeStopMarket).
		StopPrice(bnbFutOrder.StopLossPrice).
		ClosePosition(true).
		Do(context.Background())
	if err != nil {
		return err
	}

	_, err = client.NewCancelOrderService().
		Symbol(posRisk.Symbol).
		OrderID(slOrderID).
		Do(context.Background())
	if err != nil {
		return err
	}

	return nil
}

func ClearFuturesOrders(client *futures.Client, symbol string) error {
	openOrders, err := GetOpenOrders(client, symbol)
	if err != nil {
		return err
	}
	for _, order := range openOrders {
		_, err = client.NewCancelOrderService().
			Symbol(symbol).
			OrderID(order.OrderID).
			Do(context.Background())
		if err != nil {
			return err
		}
	}
	return nil
}

/******************************************************* NO ****************************************
func RecoverSlTp(client *futures.Client, positionRisk *futures.PositionRisk, order BinanceFuturesOrder) error {
	side, quantity, err := GetPositionInfo(positionRisk)
	if err != nil {
		return fmt.Errorf("failed to get position info: %v", err)
	}

	stopMartSide := futures.SideTypeBuy
	if side == BUY {
		stopMartSide = futures.SideTypeSell
	}
	quantityPrecision, err := strconv.Atoi(order.QuantityPrecision)
	if err != nil {
	//	log.Fatalf("Error converting order.QuantityPrecision to int: %v", err)
	}
	stopLossOrder := client.NewCreateOrderService().
		Symbol(positionRisk.Symbol).
		Side(stopMartSide). // This should be opposite of the original side
		Type(futures.OrderTypeStop).
		TimeInForce(futures.TimeInForceTypeGTC).
		Quantity(strconv.FormatFloat(quantity, 'f', quantityPrecision, 64)).
		Price(order.StopLossPrice).
		StopPrice(order.StopLossPrice)

	stopLossResponse, err := stopLossOrder.Do(context.Background())
	if err != nil {
		return fmt.Errorf("failed to place stop loss order: %v", err)
	}
	log.Printf("Stop loss order placed: %d", stopLossResponse.OrderID)
	SendToDiscord(fmt.Sprintf("[FuturesUserTrade-%s-%s] Stop loss order placed: %v", order.ExchangeTradeTypeCapRiskTradePair, order.UserID, stopLossResponse.OrderID))

	// pricePrecision, err := strconv.Atoi(order.PricePrecision)
	// if err != nil {
	// 	log.Fatalf("Error converting order.PricePrecision to int: %v", err)
	// }
	// investCapVol, err := strconv.ParseFloat(order.InvestCapitalVol, 64)
	// if err != nil {
	// 	log.Fatalf("Error converting order.InvestCapitalVol to float64: %v", err)
	// }
	// investVolPercent, err := strconv.ParseFloat(order.InvestVolPercent, 64)
	// if err != nil {
	// 	log.Fatalf("Error converting order.InvestVolPercent to float64: %v", err)
	// }
	// leverage, err := strconv.Atoi(order.Leverage)
	// if err != nil {
	// 	log.Fatalf("Error converting Leverage to int: %v", err)
	// }
	// cost := investVolPercent * investCapVol

	// entryPrice, err := strconv.ParseFloat(positionRisk.EntryPrice, 64)
	// if err != nil {
	// 	log.Fatalf("Error converting positionRisk.EntryPrice to float64: %v", err)
	// }
	// takeProfitPercent := 70.0
	// inBuy := true
	// if side == SELL {
	// 	inBuy = false
	// }

	// takeProfitPrice := CalLastPriceFrmROE(entryPrice, cost, leverage, inBuy, takeProfitPercent)
	// takeProfitPrice = GetAdjustedPrice(client, takeProfitPrice, positionRisk.Symbol)
	takeProfitOrder := client.NewCreateOrderService().
		Symbol(positionRisk.Symbol).
		Side(stopMartSide). // Adjust based on your position
		Type(futures.OrderTypeTakeProfit).
		TimeInForce(futures.TimeInForceTypeGTC).
		Quantity(strconv.FormatFloat(quantity, 'f', quantityPrecision, 64)).
		Price("67594.00").
		StopPrice("67594.00")

	takeProfitResponse, err := takeProfitOrder.Do(context.Background())
	if err != nil {
		return fmt.Errorf("failed to place take profit order: %v", err)
	}
	log.Printf("Take profit order placed: %d", takeProfitResponse.OrderID)
	SendToDiscord(fmt.Sprintf("[FuturesUserTrade-%s-%s] Take profit order placed: %v", order.ExchangeTradeTypeCapRiskTradePair, order.UserID, takeProfitResponse.OrderID))

	return nil
}
*/
