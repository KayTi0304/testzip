package common

import (
	"encoding/json"
	"fmt"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/secretsmanager"
)

type HostApiSecret struct {
	APIKey    string `json:"api_key"`
	SecretKey string `json:"secret_key"`
}

// RetrieveSecrets fetches the secret credentials from AWS Secrets Manager
func GetHostApiSecret() (HostApiSecret, error) {
	var secret HostApiSecret

	if HostApiSecretArn == "" {
		return secret, fmt.Errorf("error for host api - secret arn is required")
	}

	// Create a new AWS session
	sess := session.Must(session.NewSession())
	svc := secretsmanager.New(sess)

	// Retrieve the secret by its ARN
	result, err := svc.GetSecretValue(&secretsmanager.GetSecretValueInput{
		SecretId: aws.String(HostApiSecretArn),
	})
	if err != nil {
		return secret, fmt.Errorf("error for host api - failed to retrieve secret: %v", err)
	}

	// Unmarshal the secret string into Secret struct
	err = json.Unmarshal([]byte(*result.SecretString), &secret)
	if err != nil {
		return secret, fmt.Errorf("error for host api - failed to decode secret string: %v", err)
	}
	return secret, nil
}
