package common

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
)

type WebhookConfig struct {
	ID    string
	Token string
}

var webhookRegistry = map[string]WebhookConfig{}

const (
	L2ErrorAlertDisc   = "l2-error-alert"
	BotStatusDisc      = "bot-status"
	UserTradeDisc      = "all-user-trade"
	BotUndergroundDisc = "bot-underground"
)

var ErrorAlertDisc = EnvName + "-error-alert"

func GetHyperCareChannel(userID string) string {
	return userID + "-user-trade"
}

func GetUserChannel(userID string) string {
	return userID + "-user-trade"
}

func GetAlertChannel(userID string) string {
	return userID + "-error-alert"
}

func SendToDiscord(purpose, message string) {
	config, exists := webhookRegistry[purpose]
	if !exists {
		var ok bool

		is4UserTrade := strings.Contains(purpose, "-user-trade")
		is4ErrAlert := strings.Contains(purpose, "-error-alert")
		if is4UserTrade {
			config, ok = webhookRegistry[UserTradeDisc]
		} else if is4ErrAlert {
			// config, ok = webhookRegistry[L2ErrorAlertDisc]
			config, ok = webhookRegistry[ErrorAlertDisc]
		} else {
			config, ok = webhookRegistry[ErrorAlertDisc]
		}
		if !ok {
			log.Printf("[discord-handler] Webhook configuration not found for purpose: %s, and no default fallback available", purpose)
		}
	}
	DiscordSendMsg(config.ID, config.Token, message)
}

func DiscordSendMsg(id, token, message string) {
	webhookURL := fmt.Sprintf("https://discord.com/api/webhooks/%s/%s", id, token)

	// Create the JSON payload
	payload := map[string]string{"content": message}
	jsonData, err := json.Marshal(payload)
	if err != nil {
		log.Printf("[discord-handler] Error of json marshal: %v", err)
	}

	// Create a new request using http
	req, err := http.NewRequest("POST", webhookURL, bytes.NewBuffer(jsonData))
	if err != nil {
		log.Printf("[discord-handler] Error of POST: %v", err)
	}

	// Set the content type header to application/json
	req.Header.Set("Content-Type", "application/json")

	// Perform the request
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Printf("[discord-handler] Error of client do: %v", err)
	}
	defer resp.Body.Close()
}

func NewS3Client() *s3.S3 {
	sess := session.Must(session.NewSession())
	return s3.New(sess)
}

func LoadExchTradeTypeWebhookConfig() error {
	client := NewS3Client()

	key := fmt.Sprintf("trading-ops/%s/%s/webhook-configs.json", ExchName, TradeTypeNm)

	result, err := client.GetObject(&s3.GetObjectInput{
		Bucket: aws.String(IntResBucketName),
		Key:    aws.String(key),
	})
	if err != nil {
		return err
	}
	defer result.Body.Close()

	body, err := io.ReadAll(result.Body)
	if err != nil {
		return err
	}

	var configs map[string]WebhookConfig
	if err := json.Unmarshal(body, &configs); err != nil {
		return err
	}

	webhookRegistry = configs
	return nil
}
