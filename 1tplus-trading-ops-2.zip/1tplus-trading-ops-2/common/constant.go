package common

import (
	"os"
)

const (
	DISC_UR_ID      = "1255265710838382725"
	DISC_UR_TOKEN   = "m6P5iI_LHDgm0CwkjRU4zpY4qvPx61s4SNsn13-i7JfhuEdpGQZxRp6dHXuaN-BkuKLw"
	DISC_URGENT_MSG = "Discord channel configuration not found"
)

const (
	BinanceCode = "BNB"
	HuobiCode   = "HBI"
	KucoinCode  = "KUC"
)

const (
	True  = "true"
	False = "false"
)

const (
	BUY  = "BUY"
	SELL = "SELL"
)

const (
	ALGO_ST0 = "ST0"
	ALGO_ST1 = "ST1"
	ALGO_ST2 = "ST2"

	ALGO_ST6 = "ST6"

	ALGO_ST1_PLUS = "ST1_PLUS"

	ALGO_ICT0 = "ICT0"
)

const (
	SYMBOL_BTCUSDT = "BTCUSDT"
	SYMBOL_ETHUSDT = "ETHUSDT"
	SYMBOL_SOLUSDT = "SOLUSDT"
)

const (
	DEF_ACT_LOSS_LIMIT = -15.0
	DEF_ACT_LOSS_MUL   = "1.5"
)

var (
	PbCapRisks = []string{"AGG", "BAL", "CON"}
	PvCapRisks = []string{"JES", "SPE", "ROY"}
)

const (
	DEV = "dev"
	PRD = "prd"
)

const (
	AwsRegionEnv                = "APP_REGION"
	EnvNameEnv                  = "ENV_NAME"
	ExchCodeEnv                 = "EXCH_CODE"
	ExchNameEnv                 = "EXCH_NAME"
	TradeTypeCdEnv              = "TT_CODE"
	TradeTypeNmEnv              = "TT_NAME"
	HostApiSecretArnEnv         = "HOST_API_SECRET"
	ApiKeyTableNameEnv          = "AK_DB_TBL_NAME"
	ApiKeyKmsArnEnv             = "AK_KEY_KMS_ARN"
	TradePairTableNameEnv       = "ETTRCTP_CONFIG_DB_TBL_NAME"
	IntResBucketNameEnv         = "INTERNAL_RESOURCES_BUCKET_NAME"
	UserCapRiskTableNameEnv     = "USER_CAPRISK_DB_TBL_NAME"
	UserOrderSignalTableNameEnv = "USER_ORDER_SIGNAL_DB_TBL_NAME"
)

var AwsRegion = os.Getenv(AwsRegionEnv)
var EnvName = os.Getenv(EnvNameEnv)
var ExchCode = os.Getenv(ExchCodeEnv)
var ExchName = os.Getenv(ExchNameEnv)
var TradeTypeCd = os.Getenv(TradeTypeCdEnv)
var TradeTypeNm = os.Getenv(TradeTypeNmEnv)

var HostApiSecretArn = os.Getenv(HostApiSecretArnEnv)
var TradePairTableName = os.Getenv(TradePairTableNameEnv)
var IntResBucketName = os.Getenv(IntResBucketNameEnv)
var UserCapRiskTableName = os.Getenv(UserCapRiskTableNameEnv)
var UserOrderSignalTableName = os.Getenv(UserOrderSignalTableNameEnv)

var ApiKeyTableName = os.Getenv(ApiKeyTableNameEnv)
var ApiKeyKmsArn = os.Getenv(ApiKeyKmsArnEnv)
