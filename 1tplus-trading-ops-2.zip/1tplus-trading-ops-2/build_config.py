import argparse
import os
import shutil
import subprocess
from lambda_functions_configs import (
    RuntimeLang,
    lambda_functions_configs,
)
import tempfile
import zipfile
from common_tools import get_lambda_runtime

EXCLUDE_ITEMS = [".venv", "func.zip", "requirements.txt"]


# def remove_items(directory, items_to_remove):
#     """Remove specified items from the directory if they exist."""
#     for item in items_to_remove:
#         path = os.path.join(directory, item)
#         if os.path.isdir(path):
#             subprocess.run(f"rm -rf {path}", shell=True, check=True)
#         elif os.path.isfile(path):
#             os.remove(path)
def remove_items(directory, items_to_remove):
    """Remove specified items from the directory if they exist."""
    for item in items_to_remove:
        path = os.path.join(directory, item)
        if os.path.isdir(path):
            shutil.rmtree(path)  # Use shutil.rmtree to remove directories
        elif os.path.isfile(path):
            os.remove(path)


def zip_dir(directory_path, zip_path, python_version, exclude_dirs=None):
    exclude_dirs = exclude_dirs or []
    site_packages_path = f"python/lib/python{python_version}/site-packages"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        # Copy .venv\lib\site-packages to site_packages_path in the ZIP
        venv_site_packages = os.path.join(
            directory_path, ".venv", "lib", f"python{python_version}", "site-packages"
        )
        if os.path.exists(venv_site_packages):
            for root, dirs, files in os.walk(venv_site_packages):
                for file in files:
                    file_path = os.path.join(root, file)
                    # Compute relative path within site-packages and use that as the path in the ZIP
                    relative_path_within_venv = os.path.relpath(
                        file_path, venv_site_packages
                    )
                    zipf.write(file_path, relative_path_within_venv)
        for item in os.listdir(directory_path):
            if item.endswith(".py"):
                file_path = os.path.join(directory_path, item)
                zipf.write(file_path, item)


def fix_requirements(filename="requirements.txt"):
    print("fixing requirement")
    with open(filename, "r") as file:
        lines = file.readlines()

    with open(filename, "w") as file:
        for line in lines:
            # Check if the line contains an incorrect package name
            if "mysql_connector_repackaged" in line:
                # Replace the entire line with the correct package and version
                line = "mysql_connector_python==8.3.0\n"
            file.write(line)


def run_build_commands(target_service=None, target_child=None):
    os.environ["GOOS"] = "linux"
    os.environ["GOARCH"] = "amd64"
    # os.environ["CGO_ENABLED"] = "0"

    for service_configs in lambda_functions_configs:
        for config in service_configs:
            # service_name = config["service_name"]
            # child_name = config["child_name"]
            # handler = config["handler"]
            # runtime = config["runtime"]

            service_name = config.service_name
            child_name = config.child_name
            handler = config.handler
            runtime = config.runtime

            # Check for specific service_name and child_name
            if target_service and service_name != target_service:
                continue  # Skip this service
            if target_child and child_name != target_child:
                continue  # Skip this child

            folder_path = f"lambda_functions/{service_name}/{child_name}"

            if runtime == RuntimeLang.GOLANG:
                file_path = os.path.join(folder_path, f"{handler}.{runtime}")

                # Check if the Go file exists before adding it to build commands
                if os.path.exists(file_path):
                    build_command = (
                        f"go build -v -o {folder_path}/bootstrap ./{folder_path}"
                    )
                    subprocess.run(build_command, shell=True, check=True)

                    with tempfile.TemporaryDirectory() as temp_dir:
                        shutil.copy(f"{folder_path}/bootstrap", temp_dir)
                        shutil.make_archive(f"{folder_path}/func", "zip", temp_dir)

                    bootstrap_exists = os.path.exists(f"{folder_path}/bootstrap")
                    zip_exists = os.path.exists(f"{folder_path}/func.zip")

                    print(f"'bootstrap' file exists: {bootstrap_exists}")
                    print(f"'func.zip' file exists: {zip_exists}")

            elif runtime == RuntimeLang.PYTHON:
                remove_items(folder_path, EXCLUDE_ITEMS)
                python_folder_path = folder_path
                python_version = get_lambda_runtime(runtime)[1]
                if os.path.exists(python_folder_path):
                    print(
                        f"Packaging Python function in {python_folder_path} using Docker..."
                    )
                    subprocess.run(
                        f"pipreqs {python_folder_path} --force", shell=True, check=True
                    )
                    fix_requirements()

                    docker_python_folder_path = os.path.abspath(
                        python_folder_path
                    ).replace("\\", "/")

                    try:
                        subprocess.run(
                            f'docker run --rm --entrypoint bash -v "{docker_python_folder_path}:/var/task" public.ecr.aws/lambda/python:{python_version} '
                            f'-c "python -m venv /var/task/.venv && source /var/task/.venv/bin/activate && pip install -r /var/task/requirements.txt && deactivate"',
                            shell=True,
                            check=True,
                        )
                        zip_dir(
                            python_folder_path,
                            os.path.join(python_folder_path, "func.zip"),
                            python_version,
                            exclude_dirs=[
                                ".venv",
                                "__pycache__",
                            ],  # Exclude the virtual environment and any __pycache__ directories
                        )
                        print(
                            "Packaged Python function: func.zip created in "
                            + docker_python_folder_path
                        )
                    except subprocess.CalledProcessError as e:
                        print(f"Error occurred: {e}")

                    print(
                        f"Packaged Python function: {os.path.join(python_folder_path, 'func.zip')}"
                    )
                    main_exists = os.path.exists(f"{folder_path}/main")
                    zip_exists = os.path.exists(f"{folder_path}/func.zip")

                    print(f"'main' file exists: {main_exists}")
                    print(f"'func.zip' file exists: {zip_exists}")

            else:
                print(f"Unsupported runtime: {runtime}")

            # Check for the existence of the build artifacts
            # main_exists = os.path.exists(f"{folder_path}/main")
            # zip_exists = os.path.exists(f"{folder_path}/func.zip")

            # print(f"'main' file exists: {main_exists}")
            # print(f"'func.zip' file exists: {zip_exists}")

            print("Contents of the folder:")
            for item in os.listdir(folder_path):
                print(item)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build configurations for lambda functions."
    )
    parser.add_argument("--service", type=str, help="Specific service name to build")
    parser.add_argument("--child", type=str, help="Specific child name to build")

    args = parser.parse_args()

    run_build_commands(target_service=args.service, target_child=args.child)
