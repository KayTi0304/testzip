from lambda_functions_configs import RuntimeLang
from aws_cdk import aws_lambda as _lambda
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_dynamodb as dynamodb


def capitalize_join(s: str, splitter: str = "-"):
    components = s.split(splitter)
    return "".join(x.title() for x in components)


def retrieve_first_characters(text):
    import re

    words = re.split(r"[\s\-_]", text)
    first_characters = [word[0] for word in words if word]
    return "".join(first_characters)


def get_lambda_runtime(lang: str):
    if lang == RuntimeLang.PYTHON:
        return _lambda.Runtime.PYTHON_3_12, "3.12"
    if lang == RuntimeLang.GOLANG:
        return _lambda.Runtime.PROVIDED_AL2023, ""
    return _lambda.Runtime.NODEJS_20_X, ""


def get_env_config(env_name):
    """Return environment-specific configurations."""
    base_config = {
        "instance_type": ec2.InstanceType.of(
            ec2.InstanceClass.BURSTABLE3, ec2.InstanceSize.MICRO
        ),
        "instance_count": 1,
        "max_azs": 2,
        "key_name": "1tplus-key-pair",
        "billing_mode": dynamodb.BillingMode.PAY_PER_REQUEST,
    }
    if env_name == "prod":
        base_config.update(
            {
                "instance_type": ec2.InstanceType.of(
                    ec2.InstanceClass.MEMORY3, ec2.InstanceSize.LARGE
                ),
                "max_azs": 3,
                "instance_count": 2,
                "billing_mode": dynamodb.BillingMode.PROVISIONED,
            }
        )
    return base_config
