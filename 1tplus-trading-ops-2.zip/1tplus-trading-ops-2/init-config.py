import os

from lambda_functions_configs import lambda_functions_configs

code_snippet = """
package main

import (
	"context"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"
)

type Request struct {
	request    string `json:"request"`
}

func Handler(ctx context.Context, request Request) (common.Response, error) {
    // TODO

    return common.Response{
		Code:    200,
		Message: "Request test successfully",
		Data:    nil,
	}, nil
}

func main() {
    lambda.Start(Handler)
}
"""


def init():
    for service_config in lambda_functions_configs:
        for config in service_config:
            service_name = config.service_name
            child_name = config.child_name
            handler = config.handler
            runtime = config.runtime

            # Folder and file path
            folder_path = os.path.join(
                os.getcwd(), f"lambda_functions/{service_name}/{child_name}"
            )
            file_path = os.path.join(folder_path, f"{handler}.{runtime}")

            if not os.path.exists(file_path):
                os.makedirs(folder_path, exist_ok=True)

                with open(file_path, "w") as file:
                    # You can add initial content to the file if needed
                    file.write(code_snippet)
                    print(f"Created file: {file_path}")
            else:
                print(f"File {file_path} already exists. Skipping creation.")


if __name__ == "__main__":
    init()
