from aws_cdk import (
    Stack,
    aws_lambda as _lambda,
    aws_ssm as ssm,
)
from constructs import Construct


class TradingOpsStack(Stack):

    # def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
    #     super().__init__(scope, construct_id, **kwargs)

    # The code that defines your stack goes here

    # example resource
    # queue = sqs.Queue(
    #     self, "TradingOpsQueue",
    #     visibility_timeout=Duration.seconds(300),
    # )
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        env_name: str,
        function_configurations: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for function_config in function_configurations:
            self.output_function(env_name, function_config)

    def extract_alphanumeric(self, input_string):
        alphanumeric_string = "".join([char for char in input_string if char.isalnum()])
        return alphanumeric_string

    def output_function(self, env_name: str, function_config):
        lambda_func: _lambda.Function = function_config["function"]
        export_name: str = (
            f"{self.extract_alphanumeric(function_config['function_name'])}ArnExport"
        )

        ssm.StringParameter(
            self,
            f"TOLambdaFuncParameter_{export_name}_{env_name.upper()}",
            parameter_name=f"/{env_name}/ep/lambda/{export_name}",
            string_value=lambda_func.function_arn,
            description=f"Exchange Platform Lambda Function for {function_config['function_name']}",
        )
