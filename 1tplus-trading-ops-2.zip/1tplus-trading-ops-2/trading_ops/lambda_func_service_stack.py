import datetime
from aws_cdk import Duration, Stack
from aws_cdk import aws_iam as iam
from constructs import Construct
from aws_cdk import aws_ssm as ssm
from aws_cdk import aws_secretsmanager as secretsmanager
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_dynamodb as dynamodb, aws_lambda_event_sources as event_sources
from aws_cdk import aws_lambda as _lambda, aws_events as events, aws_events_targets as targets, aws_stepfunctions as sfn, aws_stepfunctions_tasks as tasks

from common_tools import capitalize_join, get_lambda_runtime, retrieve_first_characters
from trading_ops.base_service import BaseService


class LambdaFuncServiceStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        region: str,
        env_name: str,
        service_name: str,
        exch_code: str,
        exch_name: str,
        tt_code: str,
        tt_name: str,
        function_configs: list,
        **kwargs,
    ):
        super().__init__(scope, id, **kwargs)

        self.db_cred_arn = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTODBCredArnParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/db/cred/arn/param",
        ).string_value

        self.api_key_db_table_name = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOAPIKeyTableNameParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/dynamodb/table/name/exchangeApiKey",
        ).string_value
        self.api_key_kms_key_arn = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOApiKeyKmsKeyArnParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/kms/apiKeyKmsKey/arn/param",
        ).string_value

        self.api_secret = secretsmanager.Secret.from_secret_name_v2(
            self,
            f"ImportedTOBnbHostApiSecret_{env_name.upper()}",
            f"{env_name.lower()}/1tplus/{exch_code.lower()}/HostApi",
        )

        self.trade_pair_db_table_name = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOExchTradeTypeRiskCodeTradePairConfigTableNameParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/dynamodb/table/name/exchTtRcTradePairConfig",
        ).string_value

        self.internal_resources_bucket_name = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOInternalResourcesBucketNameParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/internal/resources/bucketName",
        ).string_value

        self.user_caprisk_db_table_name = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOUserExchTradeTypeCapRiskTradePairTableNameParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/dynamodb/table/name/userExchTtCrTradePair",
        ).string_value

        self.user_order_signal_db_table_name = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ImportedTOUserOrderTradeSignalTableNameParameter_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/dynamodb/table/name/userOrderTradeSignal",
        ).string_value
        
        self.env_vars = {
            "APP_REGION": region,
            "ENV_NAME": env_name,
            "EXCH_CODE": exch_code,
            "EXCH_NAME": exch_name,
            "TT_CODE": tt_code,
            "TT_NAME": tt_name,
            "DB_CREDENTIALS_SECRET": self.db_cred_arn,
            "AK_DB_TBL_NAME": self.api_key_db_table_name,
            "AK_KEY_KMS_ARN": self.api_key_kms_key_arn,
            "HOST_API_SECRET": self.api_secret.secret_arn,
            "ETTRCTP_CONFIG_DB_TBL_NAME": self.trade_pair_db_table_name,
            "INTERNAL_RESOURCES_BUCKET_NAME": self.internal_resources_bucket_name,
            "USER_CAPRISK_DB_TBL_NAME": self.user_caprisk_db_table_name,
            "USER_ORDER_SIGNAL_DB_TBL_NAME": self.user_order_signal_db_table_name
        }

        lambda_role = iam.Role(
            self,
            f"LambdaRole_TO_Func_{env_name.upper()}",
            role_name=f"LambdaRole_TO_Func_{env_name.upper()}",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name(
                    "service-role/AWSLambdaVPCAccessExecutionRole"
                )
            ],
        )

        secrets_manager_policy_statement = iam.PolicyStatement(
            actions=["secretsmanager:GetSecretValue"],
            resources=["*"],
        )
        lambda_role.add_to_policy(secrets_manager_policy_statement)

        dynamodb_policy_statement = iam.PolicyStatement(
            actions=["dynamodb:*"],
            resources=["*"],
        )
        lambda_role.add_to_policy(dynamodb_policy_statement)

        self.lambda_role_nm = lambda_role.role_name

        kms_policy_statement = iam.PolicyStatement(
            actions=["kms:Encrypt", "kms:Decrypt"],
            resources=["*"],
        )
        lambda_role.add_to_policy(kms_policy_statement)

        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "ec2:DescribeNetworkInterfaces",
                    "ec2:CreateNetworkInterface",
                    "ec2:DeleteNetworkInterface",
                    "ec2:DescribeInstances",
                    "ec2:AttachNetworkInterface",
                ],
                resources=[
                    "*"
                ],  # Ideally, you should restrict this to the specific VPC or resources
            )
        )

        s3_policy_statement = iam.PolicyStatement(
            actions=[
                "s3:GetObject",
                "s3:PutObject",
                "s3:ListBucket",
            ],
            resources=[
                "arn:aws:s3:::*"
            ],  # Wildcard to apply to all S3 buckets and objects.
        )
        lambda_role.add_to_policy(s3_policy_statement)

        vpc_id = ssm.StringParameter.value_from_lookup(
            self, f"/{env_name}/ep/{exch_code.lower()}/VpcId"
        )
        vpc = ec2.Vpc.from_lookup(
            self, f"ImportedVPC4TO_{exch_code.upper()}_{env_name}", vpc_id=vpc_id
        )

        security_group_id = ssm.StringParameter.value_from_lookup(
            self, f"/{env_name}/ep/{exch_code.lower()}/SecurityGroupId"
        )

        sg = ec2.SecurityGroup.from_security_group_id(
            self,
            f"ImportedSG4TO_{exch_code.upper()}_{env_name}",
            security_group_id=security_group_id,
        )

        # service = BaseService(
        #     self,
        #     id,
        #     env_name,
        #     function_configs,
        #     self.env_vars,
        #     iam.Role.from_role_name(self, self.lambda_role_nm, self.lambda_role_nm),
        #     vpc,
        #     sg,
        # )
        # self.function_configurations = service.function_configurations
        self.function_configurations = []
        self.lambda_tasks = {}
        self.task_sequences = {}
        
        for config in function_configs:
            self.create_function(lambda_role=lambda_role, vpc=vpc, sg=sg, env_name=env_name, env_vars=self.env_vars, **config.to_dict())

        self.create_state_machine(env_name, service_name, exch_code)

    def create_function(
        self,
        lambda_role: iam.Role,
        vpc: ec2.Vpc,
        sg: ec2.SecurityGroup,
        env_name: str,
        handler,
        runtime: str,
        service_name: str,
        exchange_code: str,
        exchange_name: str,
        trade_type_code: str,
        trade_type_name: str,
        child_name: str,
        env_vars,
        additional_config,
        trigger_interval,
        cron_schedule,
        memory_size,
        concurrent_exec,
    ):
        function_name = f"TO-{exchange_code.upper()}-{capitalize_join(service_name, "_")}-{capitalize_join(child_name, "_")}-{env_name.upper()}"
        
        additional_config = additional_config or {}
        lambda_func = _lambda.Function(
            self,  # Use the scope passed during initialization
            function_name,
            function_name=function_name,
            runtime=get_lambda_runtime(runtime)[0],
            handler=handler,
            role=lambda_role,
            code=_lambda.Code.from_asset(f"lambda_functions/{service_name}/{child_name}/func.zip"),
            environment=env_vars or {},
            vpc=vpc, 
            security_groups=[sg],
            timeout=Duration.seconds(600),
            memory_size=memory_size,
            reserved_concurrent_executions=concurrent_exec
        )

        # # Generate a version string from the current date and time
        # version_string = datetime.datetime.now(datetime.UTC).strftime("%Y%m%d%H%M%S")

        # # Publish a new version with the generated version string
        # version = _lambda.Version(
        #     self, 'MyLambdaVersion',
        #     lambda_=lambda_func,
        #     version=version_string
        # )
        # lambda_version = lambda_func.current_version

        short_func_name = f"TO{exchange_code.upper()}{retrieve_first_characters(service_name)}{retrieve_first_characters(child_name)}" 
        # if concurrent_exec > 0:
        #     alias = _lambda.Alias(
        #         self,
        #         f"{short_func_name}-LA-{env_name.upper()}",
        #         alias_name=f"{short_func_name}-LA-{env_name.upper()}",
        #         version=lambda_version,
        #         provisioned_concurrent_executions=concurrent_exec
        #     )
            
        if cron_schedule:
            # Add CloudWatch Events rule for cron schedule
            rule = events.Rule(
                self,
                f"{short_func_name}-Rule-{env_name.upper()}",
                rule_name=f"{short_func_name}-Rule-{env_name.upper()}",
                schedule=events.Schedule.cron(**cron_schedule)
            )
            rule.add_target(targets.LambdaFunction(lambda_func))
        
        state_machine_task_name = additional_config.get("state_machine_task_name", "")
        next_state_machine_task_name = additional_config.get("next_state_machine_task_name", "")
        is_map_state = additional_config.get("is_map_state", False)
        items_path = additional_config.get("items_path", "")
        # invoc_type = additional_config.get("invoc_type", tasks.LambdaInvocationType.REQUEST_RESPONSE)
        db_stream = additional_config.get("db_stream", "")
        http = additional_config.get("http", "")

        if is_map_state and items_path:
            map_state = sfn.Map(
                self, state_machine_task_name,
                max_concurrency=concurrent_exec,
                items_path=items_path
            ).item_processor(tasks.LambdaInvoke(
                self, f"TO-{exchange_code.upper()}-{capitalize_join(service_name, '_')}-{capitalize_join(child_name, '_')}Invoke-{env_name.upper()}",
                lambda_function=lambda_func,
                invocation_type=tasks.LambdaInvocationType.REQUEST_RESPONSE
            ))
            self.lambda_tasks[state_machine_task_name] = map_state
            self.task_sequences[state_machine_task_name] = next_state_machine_task_name
        else:
            lambda_task = tasks.LambdaInvoke(
                self, f"TO-{exchange_code.upper()}-{capitalize_join(service_name, '_')}-{capitalize_join(child_name, '_')}Invoke-{env_name.upper()}",
                lambda_function=lambda_func,
                invocation_type=tasks.LambdaInvocationType.REQUEST_RESPONSE
            )
            self.lambda_tasks[state_machine_task_name] = lambda_task
            self.task_sequences[state_machine_task_name] = next_state_machine_task_name

        if db_stream and db_stream != "":
            stream_table_stream_arn = ssm.StringParameter.from_string_parameter_name(
                self,
                f"ImportedTO{short_func_name}DdbStreamArnParameter_{env_name.upper()}",
                string_parameter_name=f"/{env_name}/dynamodb/table/name/{db_stream}/stream",
            ).string_value
            stream_table_name = ssm.StringParameter.from_string_parameter_name(
                self,
                f"ImportedTO{short_func_name}DdbTblNmParameter_{env_name.upper()}",
                string_parameter_name=f"/{env_name}/dynamodb/table/name/{db_stream}",
            ).string_value
            stream_table = dynamodb.Table.from_table_attributes(
                self,
                "ImportedTableWithStream",
                table_stream_arn=stream_table_stream_arn,
                table_name=stream_table_name
            )

            lambda_func.add_event_source(
                event_sources.DynamoEventSource(
                    stream_table,
                    starting_position=_lambda.StartingPosition.TRIM_HORIZON,
                    batch_size=20,  # Maximum records to read per batch
                    bisect_batch_on_error=True,
                    retry_attempts=2
                )
            )
        
        if http and http != "":
            path = f"{child_name.replace("_", "-")}"
            self.function_configurations.append(
                {
                    "function": lambda_func,
                    "function_name": function_name,
                    "path": path,
                    "method": http,
                    "query_params": additional_config.get("query_params", {}),
                    "path_params": additional_config.get("path_params", {}),
                    "body_params": additional_config.get("body_params", {}),
                }
            )

    def create_state_machine(
            self, 
            env_name: str,
            service_name: str,
            exchange_code: str  
        ):
        state_machine_definition = None
        previous_task = None
        task_name = "futures_initiator"

        while task_name:
            current_task = self.lambda_tasks[task_name]

            if previous_task:
                previous_task.next(current_task)

            previous_task = current_task

            if not state_machine_definition:
                state_machine_definition = current_task

            task_name = self.task_sequences.get(task_name)
        
        state_machine = sfn.StateMachine(
            self, f"TOStateWorkflow_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            state_machine_name=f"TOStateWorkflow_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            definition_body=sfn.DefinitionBody.from_chainable(state_machine_definition),
            timeout=Duration.minutes(15)
        )

        # JOB
        state_machine_role = iam.Role(
            self, f"EventBridgeSfnRole_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            role_name=f"EventBridgeSfnRole_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            assumed_by=iam.ServicePrincipal("events.amazonaws.com"),
            inline_policies={
                "AllowSfnExecution": iam.PolicyDocument(statements=[
                    iam.PolicyStatement(
                        actions=["states:StartExecution"],
                        resources=[state_machine.state_machine_arn]
                    )
                ])
            }
        )
        
        # Create an EventBridge rule that triggers every 5 minutes
        rule = events.Rule(
            self, f"EveryFiveMinutesRule_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            rule_name=f"EveryFiveMinutesRule_{exchange_code.upper()}_{capitalize_join(service_name, '_')}_{env_name.upper()}",
            schedule=events.Schedule.expression("cron(*/5 * * * ? *)")
        )

        # Add the state machine as the target of the EventBridge rule
        rule.add_target(targets.SfnStateMachine(state_machine, role=state_machine_role))

    # def create_state_machine(
    #         self, 
    #         env_name: str,
    #         service_name: str,
    #         exchange_code: str  
    #     ):
    #     state_machine_definition = None
    #     previous_task = None
    #     task_name = "futures_initiator"

    #     while task_name:
    #         current_task = self.lambda_tasks[task_name]

    #         if previous_task:
    #             previous_task.next(current_task)

    #         previous_task = current_task

    #         if not state_machine_definition:
    #             state_machine_definition = current_task

    #         task_name = self.task_sequences.get(task_name)
        
    #     state_machine = sfn.StateMachine(
    #         self, f"TOStateWorkflow_{exchange_code.upper()}_{capitalize_join(service_name, "_")}_{env_name.upper()}",
    #         definition=state_machine_definition,
    #         timeout=Duration.minutes(15)  # Adjust based on your timeout requirements
    #     )
