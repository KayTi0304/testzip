from constructs import Construct
from aws_cdk import Duration, aws_lambda as _lambda, aws_events as events, aws_events_targets as targets, aws_stepfunctions as sfn, aws_stepfunctions_tasks as tasks
from aws_cdk import aws_iam as iam
from aws_cdk import aws_ec2 as ec2

from common_tools import capitalize_join, get_lambda_runtime


class BaseService:
    def __init__(
        self,
        scope: Construct,
        id: str,
        env_name: str,
        function_configs: list,
        env_vars: dict,
        lambda_role: iam.Role,
        vpc: ec2.Vpc,
        sg: ec2.SecurityGroup,
    ):
        self.scope = scope
        self.id = id
        self.function_configurations = []
        self.lambda_tasks = {}
        self.task_sequences = {}

        for config in function_configs:
            self.add_function(lambda_role=lambda_role, vpc=vpc, sg=sg, env_name=env_name, env_vars=env_vars, **config.to_dict())

        # self.create_state_machine()

    def add_function(
        self,
        lambda_role: iam.Role,
        vpc: ec2.Vpc,
        sg: ec2.SecurityGroup,
        env_name: str,
        handler,
        runtime: str,
        service_name: str,
        exchange_code: str,
        child_name: str,
        env_vars,
        additional_config,
        trigger_interval,
        cron_schedule,
        memory_size,
        concurrent_exec,
    ):
        function_name = f"TO-{exchange_code.upper()}-{capitalize_join(service_name, "_")}-{capitalize_join(child_name, "_")}-{env_name.upper()}"
        
        additional_config = additional_config or {}
        lambda_func = _lambda.Function(
            self.scope,  # Use the scope passed during initialization
            function_name,
            function_name=function_name,
            runtime=get_lambda_runtime(runtime)[0],
            handler=handler,
            role=lambda_role,
            code=_lambda.Code.from_asset(f"lambda_functions/{service_name}/{child_name}/func.zip"),
            environment=env_vars or {},
            vpc=vpc, 
            security_groups=[sg],
            timeout=Duration.seconds(600),
            memory_size=memory_size,
            reserved_concurrent_executions=concurrent_exec if concurrent_exec > 0 else None
        )

        if concurrent_exec > 0:
            alias = _lambda.Alias(
                self,
                f"{function_name}-LambdaAlias",
                alias_name=f"{function_name}-LambdaAlias",
                version=lambda_func.current_version,
                provisioned_concurrent_executions=concurrent_exec
            )
        
        if cron_schedule:
            # Add CloudWatch Events rule for cron schedule
            rule = events.Rule(
                self,
                f"{function_name}-Rule",
                schedule=events.Schedule.cron(**cron_schedule)
            )
            rule.add_target(targets.LambdaFunction(lambda_func))

    #     state_machine_task_name = additional_config.get("state_machine_task_name", "")
    #     next_state_machine_task_name = additional_config.get("next_state_machine_task_name", "")
    #     is_map_state = additional_config.get("is_map_state", False)
    #     items_path = additional_config.get("items_path", "")
    #     invoc_type = additional_config.get("invoc_type", tasks.LambdaInvocationType.EVENT)

    #     if is_map_state and items_path:
    #         map_state = sfn.Map(
    #             self, state_machine_task_name,
    #             max_concurrency=concurrent_exec,
    #             items_path=items_path
    #         ).iterator(
    #             tasks.LambdaInvoke(
    #                 self, f"TO-{exchange_code.upper()}-{capitalize_join(service_name, "_")}-{capitalize_join(child_name, "_")}Invoke-{env_name.upper()}",
    #                 lambda_function=lambda_func,
    #                 invocation_type=invoc_type
    #             )
    #         )
    #         self.lambda_tasks[state_machine_task_name] = map_state
    #         self.task_sequences[state_machine_task_name] = next_state_machine_task_name
    #     else:
    #         lambda_task = tasks.LambdaInvoke(
    #             self, f"TO-{exchange_code.upper()}-{capitalize_join(service_name, "_")}-{capitalize_join(child_name, "_")}Invoke-{env_name.upper()}",
    #             lambda_function=lambda_func,
    #             invocation_type=invoc_type
    #         )
    #         self.lambda_tasks[state_machine_task_name] = lambda_task
    #         self.task_sequences[state_machine_task_name] = next_state_machine_task_name

    #     path = f"{child_name.replace("_", "-")}"

    #     self.function_configurations.append(
    #         {
    #             "function": lambda_func,
    #             "function_name": function_name,
    #             "path": path,
    #             "query_params": additional_config.get("query_params", {}),
    #             "path_params": additional_config.get("path_params", {}),
    #             "body_params": additional_config.get("body_params", {}),
    #         }
    #     )

    # def create_state_machine(
    #         self, 
    #         env_name: str,
    #         handler,
    #         runtime: str,
    #         service_name: str,
    #         exchange_code: str  
    #     ):
    #     state_machine_definition = None
    #     previous_task = None
    #     task_name = "futures_initiator"

    #     while task_name:
    #         current_task = self.lambda_tasks[task_name]

    #         if previous_task:
    #             previous_task.next(current_task)

    #         previous_task = current_task

    #         if not state_machine_definition:
    #             state_machine_definition = current_task

    #         task_name = self.task_sequences.get(task_name)
        
    #     state_machine = sfn.StateMachine(
    #         self, f"TOStateWorkflow_{exchange_code.upper()}_{capitalize_join(service_name, "_")}_{env_name.upper()}",
    #         definition=state_machine_definition,
    #         timeout=Duration.minutes(15)  # Adjust based on your timeout requirements
    #     )
