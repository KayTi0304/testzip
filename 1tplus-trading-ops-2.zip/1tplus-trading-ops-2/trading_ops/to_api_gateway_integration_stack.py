import datetime
from aws_cdk import (
    Stack,
    aws_apigateway as apigateway,
    aws_apigateway as apigateway,
    aws_ssm as ssm,
    aws_cognito as cognito,
)
from constructs import Construct

from lambda_functions_configs import HttpMethod

GET_PUBLIC_SUB_PATH = [
    "get-languages",
    "get-country-list",
    "get-eula",
    "get-terms-use-disclaimers",
    "get-user-explore",
]
POST_PUBLIC_SUB_PATH = [
    "user-register",
    "user-login",
    "refresh-token",
    "first-time-email-otp",
    "request-email-otp",
    "verify-email-otp",
    "forgot-password-email-otp",
    "update-default-language",
    "verify-inviter-detail",
]


class ToApiGatewayIntegrationStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        env_name: str,
        function_configurations: list,
        **kwargs,
    ):
        super().__init__(scope, id, **kwargs)

        root_resource_id_param = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ParameterImport_TORestApiRootResId_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/to/api/root/resource/id/param",
        )
        root_resource_id = root_resource_id_param.string_value

        rest_api_id_param = ssm.StringParameter.from_string_parameter_name(
            self,
            f"ParameterImport_TORestApiId_{env_name.upper()}",
            string_parameter_name=f"/{env_name}/to/rest/api/id/param",
        )
        rest_api_id = rest_api_id_param.string_value

        self.api = apigateway.RestApi.from_rest_api_attributes(
            self,
            f"ApiImport_TORestApi_{env_name.upper()}",
            rest_api_id=rest_api_id,
            root_resource_id=root_resource_id,
        )

        # user_pool_id_parameter = ssm.StringParameter.from_string_parameter_name(
        #     self,
        #     f"ImportedTOUserPoolId_{env_name.upper()}",
        #     string_parameter_name=f"/{env_name}/to/cognito/userPoolId",
        # )
        # user_pool_id = user_pool_id_parameter.string_value

        # user_pool = cognito.UserPool.from_user_pool_id(
        #     self, f"ImportedTOUserPool_{env_name.upper()}", user_pool_id
        # )

        # # Use the imported User Pool in the Cognito User Pools Authorizer
        # cog_user_pool_authorizer = apigateway.CognitoUserPoolsAuthorizer(
        #     self,
        #     f"AppCognitoAuthorizer_{env_name.upper()}",
        #     cognito_user_pools=[user_pool],
        # )

        generic_validator = apigateway.RequestValidator(
            self,
            "TOGenericRequestValidator",
            request_validator_name="TOGenericRequestValidator",
            rest_api=self.api,
            validate_request_body=False,
        )
        for function_config in function_configurations:
            self.integrate_function(function_config, None, generic_validator)

        api_deployment = apigateway.Deployment(
            self,
            f"TORestApiDeploy_{env_name.upper()}_{datetime.datetime.now().isoformat()}",
            api=self.api,
        )
        self.api.deployment_stage = apigateway.Stage(
            self,
            f"TORestApiStage_{env_name.upper()}",
            deployment=api_deployment,
            stage_name=env_name,
        )

    def integrate_function(
        self,
        function_config,
        cog_user_pool_authorizer,
        generic_validator: apigateway.RequestValidator,
    ):
        lambda_function = function_config["function"]

        resource = self.api.root.add_resource(function_config["path"])
        integration = apigateway.LambdaIntegration(lambda_function)

        # Enable CORS for each resource
        resource.add_cors_preflight(
            allow_origins=apigateway.Cors.ALL_ORIGINS,
            allow_methods=[function_config["method"]],
            allow_headers=apigateway.Cors.DEFAULT_HEADERS,
        )

        if function_config["method"] in [HttpMethod.GET]:
            request_parameters = self.prepare_request_parameters(
                function_config.get("query_params"), function_config.get("path_params")
            )
            resource.add_method(
                http_method=function_config["method"],
                integration=integration,
                request_parameters=request_parameters,
            )
            # if any(
            #     keyword in function_config["path"] for keyword in GET_PUBLIC_SUB_PATH
            # ):
            #     resource.add_method(
            #         http_method=function_config["method"],
            #         integration=integration,
            #         request_parameters=request_parameters,
            #     )
            # else:
            #     resource.add_method(
            #         http_method=function_config["method"],
            #         integration=integration,
            #         request_parameters=request_parameters,
            #         authorizer=cog_user_pool_authorizer,
            #         authorization_type=apigateway.AuthorizationType.COGNITO,
            #     )

        if "body_params" in function_config and function_config["method"] in [
            HttpMethod.POST,
            HttpMethod.PUT,
        ]:
            function_name = function_config["function_name"]
            model_name = "Model" + "".join(
                char for char in function_name if char.isalnum()
            )

            model = apigateway.Model(
                self,
                f"Model_{function_name}",
                model_name=model_name,
                rest_api=self.api,
                content_type="application/json",
                schema=self.define_model_schema(function_config["body_params"]),
            )

            resource.add_method(
                http_method=function_config["method"],
                integration=integration,
                # request_validator=apigateway.RequestValidator(
                #     self,
                #     f"AppRequestValidator_{function_name}",
                #     request_validator_name=f"AppRequestValidator_{function_name}",
                #     rest_api=self.api,
                #     validate_request_body=True,
                # ),
                request_validator=generic_validator,
                request_models={"application/json": model},
            )

            # Update the add_method call to include the request validator
            # if any(
            #     keyword in function_config["path"] for keyword in POST_PUBLIC_SUB_PATH
            # ):
            #     resource.add_method(
            #         http_method=function_config["method"],
            #         integration=integration,
            #         # request_validator=apigateway.RequestValidator(
            #         #     self,
            #         #     f"AppRequestValidator_{function_name}",
            #         #     request_validator_name=f"AppRequestValidator_{function_name}",
            #         #     rest_api=self.api,
            #         #     validate_request_body=True,
            #         # ),
            #         request_validator=generic_validator,
            #         request_models={"application/json": model},
            #     )
            # else:
            #     resource.add_method(
            #         http_method=function_config["method"],
            #         integration=integration,
            #         # request_validator=apigateway.RequestValidator(
            #         #     self,
            #         #     f"AppRequestValidator_{function_name}",
            #         #     request_validator_name=f"AppRequestValidator_{function_name}",
            #         #     rest_api=self.api,
            #         #     validate_request_body=True,
            #         # ),
            #         request_validator=generic_validator,
            #         request_models={"application/json": model},
            #         authorizer=cog_user_pool_authorizer,
            #         authorization_type=apigateway.AuthorizationType.COGNITO,
            #     )

    def prepare_request_parameters(self, query_params, path_params):
        request_parameters = {}
        if query_params:
            for param, required in query_params.items():
                request_parameters[f"method.request.querystring.{param}"] = required

        if path_params:
            for param, required in path_params.items():
                request_parameters[f"method.request.path.{param}"] = required

        return request_parameters

    def define_model_schema(self, body_params):
        schema = {
            "type": apigateway.JsonSchemaType.OBJECT,
            "properties": {},
        }

        # Populate properties
        for key, value in body_params.items():
            if key != "required":  # Exclude the 'required' key from properties
                schema["properties"][key] = {"type": value}

        # Add "required" only if it's not empty
        if "required" in body_params and body_params["required"]:
            schema["required"] = body_params["required"]

        return schema
