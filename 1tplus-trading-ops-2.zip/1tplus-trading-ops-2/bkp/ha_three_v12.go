package bkp

// import (
// 	"fmt"
// 	"log"
// 	"math"
// 	"strconv"
// 	"strings"
// 	"trading-ops/common"

// 	"github.com/adshao/go-binance/v2/futures"
// )

// type MacdAtrData struct {
// 	OpenTime      []string
// 	CloseTime     []string
// 	Open          []float64
// 	High          []float64
// 	Low           []float64
// 	Close         []float64
// 	BUY           []float64
// 	SELL          []float64
// 	StopLoss      []float64
// 	MacdHistogram []float64
// 	SameTrendHist []string
// 	HistPeaks     []string
// 	KlinePeaks    []string
// }

// func (data *MacdAtrData) ToMapSlice() []map[string]interface{} {
// 	length := len(data.OpenTime) // Assuming all slices are the same length
// 	results := make([]map[string]interface{}, length)

// 	for i := 0; i < length; i++ {
// 		row := map[string]interface{}{
// 			"OpenTime":      data.OpenTime[i],
// 			"CloseTime":     data.CloseTime[i],
// 			"Open":          data.Open[i],
// 			"High":          data.High[i],
// 			"Low":           data.Low[i],
// 			"Close":         data.Close[i],
// 			"BUY":           data.BUY[i],
// 			"SELL":          data.SELL[i],
// 			"StopLoss":      data.StopLoss[i],
// 			"MacdHistogram": data.MacdHistogram[i],
// 			"SameTrendHist": data.SameTrendHist[i],
// 			"HistPeaks":     data.HistPeaks[i],
// 			"KlinePeaks":    data.KlinePeaks[i],
// 		}
// 		results[i] = row
// 	}

// 	return results
// }

// func findPeaks(arr []float64) ([]int, error) {
// 	if len(arr) < 3 {
// 		// Not enough elements to have a peak
// 		return nil, fmt.Errorf("array must contain at least 3 elements")
// 	}

// 	var peaks []int

// 	for i := 1; i < len(arr)-1; i++ {
// 		if arr[i] > arr[i-1] && arr[i] > arr[i+1] {
// 			peaks = append(peaks, i)
// 		}
// 	}

// 	if len(peaks) <= 0 {
// 		return peaks, nil
// 	}

// 	//make sure the peaks are far enough apart (start from the back, keep the most recent peak)
// 	ReverseSliceInt(peaks)

// 	finalPeaks := []int{peaks[0]}
// 	for i := 1; i < len(peaks); i++ {
// 		if math.Abs(float64(peaks[i]-finalPeaks[len(finalPeaks)-1])) >= 5 {
// 			finalPeaks = append(finalPeaks, peaks[i])
// 		}
// 	}

// 	ReverseSliceInt(finalPeaks)

// 	return finalPeaks, nil
// }

// func getSameTrends(uptrend []bool, hist, high, low []float64, curr, prev int) ([]float64, []float64, []int, []float64, []float64, error) {
// 	sameTrendHist := []float64{math.Round(hist[curr]*100) / 100}
// 	sameTrendKline := []float64{}
// 	currTrend := uptrend[curr]
// 	ignoreConstantInd, ignoreConstantGrp := 7, 3
// 	ignoreCounterInd, ignoreCounterGrp := 0, 0

// 	if currTrend {
// 		sameTrendKline = append(sameTrendKline, high[curr])
// 	} else {
// 		sameTrendKline = append(sameTrendKline, low[curr])
// 	}

// 	for prev >= 0 && ignoreCounterGrp < ignoreConstantGrp {
// 		if uptrend[prev] == currTrend {
// 			sameTrendHist = append([]float64{math.Round(hist[prev]*100) / 100}, sameTrendHist...)
// 			if currTrend {
// 				sameTrendKline = append([]float64{high[prev]}, sameTrendKline...)
// 			} else {
// 				sameTrendKline = append([]float64{low[prev]}, sameTrendKline...)
// 			}

// 			if ignoreCounterInd > 0 { // went back to normal trend; count how many groups of anomalies
// 				if ignoreCounterInd > 3 { // just ignore small anomaly groups
// 					ignoreCounterGrp++
// 				}
// 				ignoreCounterInd = 0
// 			}
// 		} else { // ignore outliers (individual candles)
// 			if math.Abs(hist[prev]) > 0.02 {
// 				ignoreCounterInd++
// 			}

// 			if math.Abs(hist[prev]) > 0.2 || ignoreCounterInd > ignoreConstantInd { // too many; stop
// 				break // if the outlier is too high, better to just stop
// 			}
// 		}
// 		prev--
// 	}

// 	if !currTrend {
// 		for i := range sameTrendHist {
// 			sameTrendHist[i] *= -1
// 		}
// 	}
// 	var sigPeaks []int

// 	sigPeaks, _ = findPeaks(sameTrendHist)

// 	histPeaks := make([]float64, len(sigPeaks))
// 	klinePeaks := make([]float64, len(sigPeaks))

// 	for i, idx := range sigPeaks {
// 		histPeaks[i] = sameTrendHist[idx]
// 		klinePeaks[i] = sameTrendKline[idx]
// 	}

// 	histPeaks = append(histPeaks, sameTrendHist[len(sameTrendHist)-1])
// 	klinePeaks = append(klinePeaks, sameTrendKline[len(sameTrendKline)-1])

// 	return sameTrendHist, sameTrendKline, sigPeaks, histPeaks, klinePeaks, nil
// }

// func MacdAtrTrend(klines []*futures.Kline, vsDivide float64) ResultData {
// 	candles := ExtractCandles(klines)
// 	length := len(candles)
// 	histCount := 3
// 	data := MacdAtrData{
// 		OpenTime:      make([]string, length),
// 		CloseTime:     make([]string, length),
// 		Open:          make([]float64, length),
// 		High:          make([]float64, length),
// 		Low:           make([]float64, length),
// 		Close:         make([]float64, length),
// 		BUY:           make([]float64, length),
// 		SELL:          make([]float64, length),
// 		StopLoss:      make([]float64, length),
// 		MacdHistogram: make([]float64, length),
// 		SameTrendHist: make([]string, length),
// 		HistPeaks:     make([]string, length),
// 		KlinePeaks:    make([]string, length),
// 	}

// 	// Calculate ATR for both periods
// 	candlesHigh := ExtractCandlesHighs(candles)
// 	candlesClose := ExtractCandlesCloses(candles)
// 	candlesLow := ExtractCandlesLows(candles)
// 	atr := CalculateATR(candlesHigh, candlesLow, candlesClose, 13)

// 	_, _, macdHistogram := CalculateMACD(candlesClose, 13, 34, 9)

// 	data.MacdHistogram = macdHistogram

// 	uptrend := make([]bool, length)
// 	isGrow := make([]bool, length)
// 	for i := 1; i < length; i++ {
// 		uptrend[i] = true
// 		isGrow[i] = false
// 	}

// 	for i := 1; i < length; i++ {
// 		curr, prev := i, i-1

// 		// Set OpenTime and CloseTime
// 		data.OpenTime[i] = candles[i].OpenTime
// 		data.CloseTime[i] = candles[i].CloseTime

// 		data.Open[i] = candles[i].Open
// 		data.High[i] = candles[i].High
// 		data.Low[i] = candles[i].Low
// 		data.Close[i] = candles[i].Close

// 		// Check for buy or sell signals
// 		// if isBuyTrend12(macdHistogram, i) {
// 		// 	data.BUY[i] = candles[i].Close
// 		// }
// 		// if isSellTrend12(macdHistogram, i) {
// 		// 	data.SELL[i] = candles[i].Close
// 		// }

// 		if macdHistogram[curr] < 0.0 {
// 			uptrend[curr] = false
// 		}

// 		if macdHistogram[curr] > macdHistogram[prev] {
// 			isGrow[curr] = true
// 		}

// 		action := ""
// 		if !isGrow[curr] && !uptrend[curr] {
// 			action = "BUY"

// 		}

// 		if isGrow[curr] && uptrend[curr] {
// 			action = "SELL"
// 		}

// 		// if macdHistogram[curr] < 0.0 {
// 		// 	data.StopLoss[i] = candles[i].Close - atr[i]
// 		// } else {
// 		// 	data.StopLoss[i] = candles[i].Close + atr[i]
// 		// }

// 		if action == "" {
// 			continue
// 		}

// 		sameTrendHist, _, _, histPeaks, klinePeaks, err := getSameTrends(uptrend, macdHistogram, candlesHigh, candlesLow, curr, prev)
// 		if err != nil {
// 			log.Fatalf(err.Error())
// 		}

// 		if len(sameTrendHist) < 3 {
// 			continue
// 		}

// 		data.SameTrendHist[i] = Float64ArrayToString(sameTrendHist)
// 		data.HistPeaks[i] = Float64ArrayToString(histPeaks)
// 		data.KlinePeaks[i] = Float64ArrayToString(klinePeaks)

// 		// fmt.Printf("data.OpenTime: %v\n", data.OpenTime[i])

// 		// fmt.Printf("sameTrendHist: %v\n", sameTrendHist)
// 		// fmt.Printf("histPeaks: %v\n", histPeaks)
// 		// fmt.Printf("klinePeaks: %v\n", klinePeaks)

// 		// indices := filterIndices(histPeaks, 0.7)
// 		// fmt.Printf("len(indices): %v\n", len(indices))
// 		// if len(indices) <= 0 {
// 		// 	continue
// 		// }

// 		// fmt.Printf("indices: %v\n", indices)

// 		var hline []float64
// 		var iline []float64
// 		j := 0
// 		ReverseSlice(histPeaks)
// 		ReverseSlice(klinePeaks)

// 		// fmt.Printf("histPeaks: %v\n", histPeaks)
// 		// fmt.Printf("klinePeaks: %v\n", klinePeaks)
// 		// fmt.Printf("action: %v\n", action)

// 		for j < len(histPeaks) {
// 			hisp := histPeaks[j]
// 			klip := klinePeaks[j]
// 			if j == 0 ||
// 				(action == "BUY" && hisp > hline[len(hline)-1] && klip > iline[len(iline)-1]) ||
// 				(action == "SELL" && hisp > hline[len(hline)-1] && klip < iline[len(iline)-1]) {
// 				// (j > 0 && action == "BUY" && hisp < hline[j-1] && klip > iline[j-1]) ||
// 				// (j > 0 && action == "SELL" && hisp > hline[j-1] && klip < iline[j-1]) {
// 				hline = append(hline, hisp)
// 				iline = append(iline, klip)
// 			}
// 			j += 1
// 		}

// 		ReverseSlice(hline)
// 		ReverseSlice(iline)
// 		ReverseSlice(histPeaks)
// 		ReverseSlice(klinePeaks)

// 		// fmt.Printf("len(hline): %v\n", len(hline))
// 		// fmt.Printf("len(iline): %v\n", len(iline))

// 		if action == "BUY" && len(hline) >= histCount && len(iline) >= histCount &&
// 			compHeadTail(hline, vsDivide) {
// 			data.BUY[i] = candles[i].Close
// 			data.StopLoss[i] = candles[i].Close - atr[i]
// 		}

// 		if action == "SELL" && len(hline) >= histCount && len(iline) >= histCount &&
// 			compHeadTail(hline, vsDivide) {
// 			data.SELL[i] = candles[i].Close
// 			data.StopLoss[i] = candles[i].Close + atr[i]
// 		}

// 	}
// 	// common.SaveCsv4(data.ToMapSlice(), "abc")
// 	// return data
// 	// SupertrendData6ToCsv(data, "st-di-all")
// 	// return data
// 	// log.println(len(data))
// 	common.SaveCsv4(data.ToMapSlice(), "detail")
// 	// SupertrendData6ToCsv(data, "detail")

// 	result := ConvertToResultData(data)
// 	return result
// }

// func Float64ArrayToString(arr []float64) string {
// 	strArr := make([]string, len(arr))
// 	for i, v := range arr {
// 		strArr[i] = strconv.FormatFloat(v, 'f', -1, 64)
// 	}
// 	return strings.Join(strArr, ", ")
// }

// func compHeadTail(hline []float64, vsDivide float64) bool {
// 	head := hline[0]
// 	tail := hline[len(hline)-1]

// 	if tail == 0.0 {
// 		tail = 0.1
// 	}

// 	divide := math.Round(head/tail*100) / 100
// 	return divide > vsDivide
// }

// func filterIndices(histPeaks []float64, quakeLimit float64) []int {
// 	var indices []int
// 	for i, x := range histPeaks {
// 		if x >= quakeLimit {
// 			indices = append(indices, i)
// 		}
// 	}
// 	return indices
// }

// func ReverseSlice(slice []float64) {
// 	left, right := 0, len(slice)-1
// 	for left < right {
// 		slice[left], slice[right] = slice[right], slice[left] // Swap elements
// 		left++
// 		right--
// 	}
// }

// func ReverseSliceInt(slice []int) {
// 	left, right := 0, len(slice)-1
// 	for left < right {
// 		slice[left], slice[right] = slice[right], slice[left] // Swap elements
// 		left++
// 		right--
// 	}
// }
