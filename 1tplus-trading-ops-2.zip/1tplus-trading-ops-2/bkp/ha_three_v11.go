package bkp

// import (
// 	"fmt"
// 	"math"
// 	"trading-ops/common"

// 	"github.com/adshao/go-binance/v2/futures"
// )

// func isBuyTrend11(candles []Candle, demandZones, stochRSI, ema, FinalLowerBand14 []float64, supertrend14, supertrend10 []bool, curr, prev int) bool {
// 	return candles[curr].Close > FinalLowerBand14[curr] &&
// 		candles[curr].Close >= demandZones[curr] &&
// 		stochRSI[curr] < 30 && (candles[curr].Close > ema[curr] || candles[curr].High > ema[curr])
// 	// ((plusDI10[curr] > minusDI10[curr] && adx10[curr] > 25) &&
// 	// 	(plusDI14[curr] > minusDI14[curr] && adx14[curr] > 25) &&
// 	// 	(plusDI21[curr] > minusDI21[curr] && adx21[curr] > 25)) &&
// 	// ((supertrend21[curr] && !supertrend21[prev] && supertrend14[curr] && supertrend10[curr]) ||
// 	// 	(supertrend14[curr] && !supertrend14[prev] && supertrend21[curr] && supertrend10[curr]) ||
// 	// 	(supertrend10[curr] && !supertrend10[prev] && supertrend21[curr] && supertrend14[curr]))
// }

// func isSellTrend11(candles []Candle, supplyZones, stochRSI, ema, FinalUpperBand14 []float64, supertrend14, supertrend10 []bool, curr, prev int) bool {
// 	return candles[curr].Close < FinalUpperBand14[curr] &&
// 		candles[curr].Close <= supplyZones[curr] &&
// 		stochRSI[curr] > 70 && (candles[curr].Close < ema[curr] || candles[curr].High < ema[curr])
// 	// ((plusDI10[curr] < minusDI10[curr] && adx10[curr] > 25) &&
// 	// 	(plusDI14[curr] < minusDI14[curr] && adx14[curr] > 25) &&
// 	// 	(plusDI21[curr] < minusDI21[curr] && adx21[curr] > 25)) &&
// 	// (!supertrend21[curr] && supertrend21[prev] && !supertrend14[curr] && !supertrend10[curr]) ||
// 	// (!supertrend14[curr] && supertrend14[prev] && !supertrend21[curr] && !supertrend10[curr]) ||
// 	// (!supertrend10[curr] && supertrend10[prev] && !supertrend21[curr] && !supertrend14[curr])
// }

// // IdentifyDemandSupplyZones calculates demand and supply zones based on historical price data
// func IdentifyDemandSupplyZones(candles []Candle, lookBackPeriod int) ([]float64, []float64) {
// 	length := len(candles)
// 	demandZones := make([]float64, length)
// 	supplyZones := make([]float64, length)

// 	for i := lookBackPeriod; i < length-lookBackPeriod; i++ {
// 		// Check for Demand Zone (Swing Low)
// 		isSwingLow := true
// 		for j := 1; j <= lookBackPeriod; j++ {
// 			if candles[i].Low >= candles[i-j].Low || candles[i].Low >= candles[i+j].Low {
// 				isSwingLow = false
// 				break
// 			}
// 		}
// 		if isSwingLow {
// 			demandZones[i] = candles[i].Low
// 		} else {
// 			demandZones[i] = 0 // No demand zone
// 		}

// 		// Check for Supply Zone (Swing High)
// 		isSwingHigh := true
// 		for j := 1; j <= lookBackPeriod; j++ {
// 			if candles[i].High <= candles[i-j].High || candles[i].High <= candles[i+j].High {
// 				isSwingHigh = false
// 				break
// 			}
// 		}
// 		if isSwingHigh {
// 			supplyZones[i] = candles[i].High
// 		} else {
// 			supplyZones[i] = 0 // No supply zone
// 		}
// 	}

// 	return demandZones, supplyZones
// }

// func HaThreeSupertrendsV11(klines []*futures.Kline, multiplier14, multiplier10 float64, atrPeriod14, atrPeriod10, rsiPeriod, stoplossNoLine int) SupertrendData2 {
// 	candles := ExtractCandles(klines)
// 	length := len(candles)
// 	data := SupertrendData2{
// 		OpenTime:         make([]string, length),
// 		CloseTime:        make([]string, length),
// 		Open:             make([]float64, length),
// 		High:             make([]float64, length),
// 		Low:              make([]float64, length),
// 		Close:            make([]float64, length),
// 		Supertrend14:     make([]bool, length),
// 		FinalLowerBand14: make([]float64, length),
// 		FinalUpperBand14: make([]float64, length),
// 		Supertrend10:     make([]bool, length),
// 		FinalLowerBand10: make([]float64, length),
// 		FinalUpperBand10: make([]float64, length),
// 		BUY:              make([]float64, length),
// 		SELL:             make([]float64, length),
// 		StopLoss:         make([]float64, length),
// 		Rsi21:            make([]float64, length),
// 	}

// 	// Calculate ATR for both periods
// 	candlesHigh := ExtractCandlesHighs(candles)
// 	candlesClose := ExtractCandlesCloses(candles)
// 	candlesLow := ExtractCandlesLows(candles)
// 	atr14 := CalculateATR(candlesHigh, candlesLow, candlesClose, atrPeriod14)
// 	atr10 := CalculateATR(candlesHigh, candlesLow, candlesClose, atrPeriod10)

// 	fmt.Printf("atr14: %v\n", atr14)

// 	// Calculate Directional Movements
// 	// plusDM, minusDM := calculateDirectionalMovements(candlesHigh, candlesLow)
// 	// plusDI10, minusDI10, adx10 := calculateDirectionalIndicators(plusDM, minusDM, atr10, atrPeriod10)
// 	// plusDI14, minusDI14, adx14 := calculateDirectionalIndicators(plusDM, minusDM, atr10, atrPeriod10)

// 	//candles15 := AggregateCandles(candles, 3)
// 	//candles30 := AggregateCandles(candles15, 2)
// 	ema := CalculateEMA200(candles)

// 	stochRSI := CalculateStochasticRSI(candles, rsiPeriod)
// 	lookBackPeriod := 5 // Example look-back period
// 	demandZones, supplyZones := IdentifyDemandSupplyZones(candles, lookBackPeriod)

// 	data.Rsi21 = stochRSI
// 	// data.Ema = ema

// 	prevEma := ema[0]

// 	for i := 1; i < length; i++ {
// 		// Set OpenTime and CloseTime
// 		data.OpenTime[i] = candles[i].OpenTime
// 		data.CloseTime[i] = candles[i].CloseTime

// 		data.Open[i] = candles[i].Open
// 		data.High[i] = candles[i].High
// 		data.Low[i] = candles[i].Low
// 		data.Close[i] = candles[i].Close

// 		data.Rsi21[i] = stochRSI[i]
// 		hl2 := (candles[i].High + candles[i].Low) / 2
// 		// data.FinalUpperBand21[i] = hl2 + multiplier21*atr21[i]
// 		// data.FinalLowerBand21[i] = hl2 - multiplier21*atr21[i]

// 		data.FinalUpperBand14[i] = hl2 + multiplier14*atr14[i]
// 		data.FinalLowerBand14[i] = hl2 - multiplier14*atr14[i]

// 		data.FinalUpperBand10[i] = hl2 + multiplier10*atr10[i]
// 		data.FinalLowerBand10[i] = hl2 - multiplier10*atr10[i]

// 		// Calculate Supertrend logic for 21 period
// 		// if candles[i].Close > data.FinalUpperBand21[i-1] {
// 		// 	data.Supertrend21[i] = true
// 		// } else if candles[i].Close < data.FinalLowerBand21[i-1] {
// 		// 	data.Supertrend21[i] = false
// 		// } else {
// 		// 	data.Supertrend21[i] = data.Supertrend21[i-1]
// 		// 	if data.Supertrend21[i] {
// 		// 		if data.FinalLowerBand21[i] < data.FinalLowerBand21[i-1] {
// 		// 			data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
// 		// 		}
// 		// 	} else {
// 		// 		if data.FinalUpperBand21[i] > data.FinalUpperBand21[i-1] {
// 		// 			data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
// 		// 		}
// 		// 	}
// 		// }
// 		// if data.Supertrend21[i] {
// 		// 	data.FinalUpperBand21[i] = math.NaN()
// 		// } else {
// 		// 	data.FinalLowerBand21[i] = math.NaN()
// 		// }

// 		if candles[i].Close > data.FinalUpperBand14[i-1] {
// 			data.Supertrend14[i] = true
// 		} else if candles[i].Close < data.FinalLowerBand14[i-1] {
// 			data.Supertrend14[i] = false
// 		} else {
// 			data.Supertrend14[i] = data.Supertrend14[i-1]
// 			if data.Supertrend14[i] {
// 				if data.FinalLowerBand14[i] < data.FinalLowerBand14[i-1] {
// 					data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
// 				}
// 			} else {
// 				if data.FinalUpperBand14[i] > data.FinalUpperBand14[i-1] {
// 					data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
// 				}
// 			}
// 		}
// 		if data.Supertrend14[i] {
// 			data.FinalUpperBand14[i] = math.NaN()
// 		} else {
// 			data.FinalLowerBand14[i] = math.NaN()
// 		}

// 		if candles[i].Close > data.FinalUpperBand10[i-1] {
// 			data.Supertrend10[i] = true
// 		} else if candles[i].Close < data.FinalLowerBand10[i-1] {
// 			data.Supertrend10[i] = false
// 		} else {
// 			data.Supertrend10[i] = data.Supertrend10[i-1]
// 			if data.Supertrend10[i] {
// 				if data.FinalLowerBand10[i] < data.FinalLowerBand10[i-1] {
// 					data.FinalLowerBand10[i] = data.FinalLowerBand10[i-1]
// 				}
// 			} else {
// 				if data.FinalUpperBand10[i] > data.FinalUpperBand10[i-1] {
// 					data.FinalUpperBand10[i] = data.FinalUpperBand10[i-1]
// 				}
// 			}
// 		}
// 		if data.Supertrend10[i] {
// 			data.FinalUpperBand10[i] = math.NaN()
// 		} else {
// 			data.FinalLowerBand10[i] = math.NaN()
// 		}

// 		// STOP LOSS
// 		// if !math.IsNaN(data.FinalLowerBand14[i]) && data.FinalLowerBand14[i] > 0 {
// 		// 	data.StopLoss[i] = data.FinalLowerBand14[i]
// 		// }

// 		// if !math.IsNaN(data.FinalUpperBand14[i]) && data.FinalUpperBand14[i] > 0 {
// 		// 	data.StopLoss[i] = data.FinalUpperBand14[i]
// 		// }

// 		// if !math.IsNaN(data.FinalLowerBand10[i]) && stoplossNoLine == 3 && data.FinalLowerBand10[i] > 0 {
// 		// 	data.StopLoss[i] = data.FinalLowerBand10[i]

// 		// }

// 		// if !math.IsNaN(data.FinalUpperBand10[i]) && stoplossNoLine == 3 && data.FinalUpperBand10[i] > 0 {
// 		// 	data.StopLoss[i] = data.FinalUpperBand10[i]
// 		// }

// 		// if candles[i].Close >= demandZones[i] { // stoploss for buy signal
// 		// 	data.StopLoss[i] = candles[i].Close - atr14[i]*0.5
// 		// }

// 		// if candles[i].Close <= supplyZones[i] { // stoploss for sell signal
// 		// 	data.StopLoss[i] = candles[i].Close + atr14[i]*0.5
// 		// }

// 		if prevEma > ema[i] {
// 			data.StopLoss[i] = candles[i].Close - atr14[i]*0.5
// 		} else {
// 			data.StopLoss[i] = candles[i].Close + atr14[i]*0.5
// 		}

// 		prevEma = ema[i]

// 		// Stop loss is placed below the demand zone

// 		// Check for buy or sell signals
// 		if isBuyTrend11(candles, demandZones, stochRSI, ema, data.FinalLowerBand14, data.Supertrend14, data.Supertrend10, i, i-1) {
// 			data.BUY[i] = candles[i].Close
// 			data.StopLoss[i] = calculateStopLoss(data.BUY[i], atr14[i], multiplier14, "long")
// 		}
// 		if isSellTrend11(candles, supplyZones, stochRSI, ema, data.FinalUpperBand14, data.Supertrend14, data.Supertrend10, i, i-1) {
// 			data.SELL[i] = candles[i].Close
// 			data.StopLoss[i] = calculateStopLoss(data.SELL[i], atr14[i], multiplier14, "short")
// 		}
// 	}

// 	common.SaveCsv4(data.ToMapSlice(), "newpaindetail")

// 	return data
// }

// func calculateStopLoss(entryPrice, atrValue float64, multiplier float64, positionType string) float64 {
// 	if positionType == "long" {
// 		return entryPrice - atrValue*multiplier
// 	} else if positionType == "short" {
// 		return entryPrice + atrValue*multiplier
// 	} else {
// 		fmt.Println("Invalid position type. Use 'long' or 'short'.")
// 		return 0.0
// 	}
// }
