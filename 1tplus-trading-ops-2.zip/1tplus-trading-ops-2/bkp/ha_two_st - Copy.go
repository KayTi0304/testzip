package bkp

// import (
// 	"fmt"
// 	"math"
// 	"time"

// 	"github.com/go-gota/gota/dataframe"
// )

// type Candle struct {
// 	OpenTime  string
// 	Open      float64
// 	High      float64
// 	Low       float64
// 	Close     float64
// 	CloseTime string
// }

// type HeikenAshiCandle struct {
// 	Open, High, Low, Close float64
// }

// // CalculateHeikenAshi takes a slice of Candle and returns a slice of HeikenAshiCandle.
// func CalculateHeikenAshi(candles []Candle) []HeikenAshiCandle {
// 	hCandles := make([]HeikenAshiCandle, len(candles))
// 	if len(candles) == 0 {
// 		return hCandles
// 	}

// 	// Calculate the first Heiken Ashi candle based on the first regular candle
// 	hCandles[0].Close = (candles[0].Open + candles[0].High + candles[0].Low + candles[0].Close) / 4
// 	hCandles[0].Open = (candles[0].Open + candles[0].Close) / 2
// 	hCandles[0].High = candles[0].High
// 	hCandles[0].Low = candles[0].Low

// 	// Calculate subsequent Heiken Ashi candles
// 	for i := 1; i < len(candles); i++ {
// 		hCandles[i].Close = (candles[i].Open + candles[i].High + candles[i].Low + candles[i].Close) / 4
// 		hCandles[i].Open = (hCandles[i-1].Open + hCandles[i-1].Close) / 2
// 		hCandles[i].High = math.Max(math.Max(candles[i].High, hCandles[i].Open), hCandles[i].Close)
// 		hCandles[i].Low = math.Min(math.Min(candles[i].Low, hCandles[i].Open), hCandles[i].Close)
// 	}

// 	return hCandles
// }

// // CalculateDelta calculates the difference between elements in a slice.
// func CalculateDeltas(data []float64) []float64 {
// 	deltas := make([]float64, len(data))
// 	for i := 1; i < len(data); i++ {
// 		deltas[i] = data[i] - data[i-1]
// 	}
// 	return deltas
// }

// // CalculateDM calculates the Positive and Negative Directional Movements.
// func CalculateDM(high, low []float64) (posDM, negDM []float64) {
// 	deltaHigh := CalculateDeltas(high)
// 	deltaLow := CalculateDeltas(low)
// 	posDM = make([]float64, len(high))
// 	negDM = make([]float64, len(low))

// 	for i := 1; i < len(high); i++ {
// 		if deltaHigh[i] > 0 && deltaHigh[i] > deltaLow[i] {
// 			posDM[i] = deltaHigh[i]
// 		}
// 		if deltaLow[i] > 0 && deltaLow[i] > deltaHigh[i] {
// 			negDM[i] = deltaLow[i]
// 		}
// 	}
// 	return posDM, negDM
// }

// func CalculateTrueRange(high, low, close []float64) []float64 {
// 	trueRange := make([]float64, len(high))
// 	for i := 0; i < len(high); i++ {
// 		hl := high[i] - low[i]
// 		var hc, lc float64
// 		if i > 0 {
// 			hc = math.Abs(high[i] - close[i-1])
// 			lc = math.Abs(low[i] - close[i-1])
// 		}
// 		trueRange[i] = math.Max(hl, math.Max(hc, lc))
// 	}
// 	return trueRange
// }

// func SimpleMovingSum(data []float64, period int) []float64 {
// 	result := make([]float64, len(data))
// 	var sum float64
// 	for i := 0; i < len(data); i++ {
// 		if i >= period {
// 			sum -= data[i-period]
// 		}
// 		sum += data[i]
// 		if i >= period-1 {
// 			result[i] = sum
// 		}
// 	}
// 	return result
// }

// // CalculateADX calculates the Average Directional Movement Index.
// func CalculateADX(high, low, close []float64, period int) []float64 {
// 	trueRange := CalculateTrueRange(high, low, close)
// 	posDM, negDM := CalculateDM(high, low)

// 	smoothedTR := SimpleMovingSum(trueRange, period)
// 	smoothedPosDM := SimpleMovingSum(posDM, period)
// 	smoothedNegDM := SimpleMovingSum(negDM, period)

// 	posDI := make([]float64, len(high))
// 	negDI := make([]float64, len(low))
// 	for i := range posDI {
// 		if smoothedTR[i] != 0 {
// 			posDI[i] = 100 * smoothedPosDM[i] / smoothedTR[i]
// 			negDI[i] = 100 * smoothedNegDM[i] / smoothedTR[i]
// 		}
// 	}

// 	dx := make([]float64, len(posDI))
// 	for i := range dx {
// 		if (posDI[i] + negDI[i]) != 0 {
// 			dx[i] = 100 * math.Abs(posDI[i]-negDI[i]) / (posDI[i] + negDI[i])
// 		}
// 	}

// 	adx := SimpleMovingSum(dx, period)
// 	for i := range adx {
// 		adx[i] /= float64(period)
// 	}

// 	return adx
// }

// func CalculateGainsAndLosses(deltas []float64) (gains, losses []float64) {
// 	gains = make([]float64, len(deltas))
// 	losses = make([]float64, len(deltas))
// 	for i, delta := range deltas {
// 		if delta > 0 {
// 			gains[i] = delta
// 		} else {
// 			losses[i] = -delta // Make losses positive
// 		}
// 	}
// 	return gains, losses
// }

// func SimpleMovingAverage(data []float64, period int) []float64 {
// 	result := make([]float64, len(data))
// 	var sum float64
// 	var count int
// 	for i := 0; i < len(data); i++ {
// 		sum += data[i]
// 		if i >= period {
// 			sum -= data[i-period]
// 		}
// 		if i >= period-1 {
// 			result[i] = sum / float64(period)
// 		} else {
// 			count++
// 			result[i] = sum / float64(count)
// 		}
// 	}
// 	return result
// }

// func CalculateEMA(data []float64, period int) []float64 {
// 	ema := make([]float64, len(data))
// 	alpha := 2.0 / (float64(period) + 1.0) // Smoothing factor
// 	ema[0] = data[0]                       // Start with the first data point

// 	for i := 1; i < len(data); i++ {
// 		ema[i] = data[i]*alpha + ema[i-1]*(1-alpha)
// 	}

// 	return ema
// }

// // CalculateATR calculates the Average True Range for given high, low, and close slices.
// func CalculateATR(high, low, close []float64, period int) []float64 {
// 	trueRange := CalculateTrueRange(high, low, close)
// 	atr := SimpleMovingAverage(trueRange, period)
// 	return atr
// }

// func CalculateRSI(data []float64, period int) []float64 {
// 	deltas := CalculateDeltas(data)
// 	gains, losses := CalculateGainsAndLosses(deltas)

// 	avgGains := SimpleMovingAverage(gains, period)
// 	avgLosses := SimpleMovingAverage(losses, period)

// 	rsi := make([]float64, len(data))
// 	for i := range rsi {
// 		if avgLosses[i] == 0 {
// 			rsi[i] = 100 // If no losses, RSI is set to 100
// 		} else {
// 			rs := avgGains[i] / avgLosses[i]
// 			rsi[i] = 100 - (100 / (1 + rs))
// 		}
// 	}
// 	return rsi
// }

// func CalculateKeltnerChannel(high, low, close []float64, emaPeriod, atrPeriod int, multiplier float64) ([]float64, []float64, []float64) {
// 	ema := CalculateEMA(close, emaPeriod)
// 	atr := CalculateATR(high, low, close, atrPeriod)

// 	upperBand := make([]float64, len(close))
// 	lowerBand := make([]float64, len(close))

// 	for i := range ema {
// 		upperBand[i] = ema[i] + multiplier*atr[i]
// 		lowerBand[i] = ema[i] - multiplier*atr[i]
// 	}

// 	return ema, upperBand, lowerBand
// }

// // CalculateKeltnerChannelWidths calculates the widths of the Keltner Channel.
// func CalculateKeltnerChannelWidths(high, low, close []float64, emaPeriod, atrPeriod int, multiplier float64) []float64 {
// 	_, upperBand, lowerBand := CalculateKeltnerChannel(high, low, close, emaPeriod, atrPeriod, multiplier)
// 	widths := make([]float64, len(upperBand))
// 	for i := range upperBand {
// 		widths[i] = upperBand[i] - lowerBand[i]
// 	}
// 	return widths
// }

// // CalculateAverage returns the average of a slice of float64.
// func CalculateAverage(data []float64) float64 {
// 	sum := 0.0
// 	for _, value := range data {
// 		sum += value
// 	}
// 	return sum / float64(len(data))
// }

// // IsLowVolatilityKeltner checks if the current Keltner Channel width is below a historical threshold.
// func IsLowVolatilityKeltner(high, low, close []float64, emaPeriod, atrPeriod, historyPeriod int, multiplier, thresholdRatio float64) bool {
// 	widths := CalculateKeltnerChannelWidths(high, low, close, emaPeriod, atrPeriod, multiplier)
// 	if len(widths) < historyPeriod {
// 		fmt.Println("Not enough data to determine volatility.")
// 		return false
// 	}
// 	historicalWidths := widths[len(widths)-historyPeriod-1 : len(widths)-1]
// 	currentWidth := widths[len(widths)-1]
// 	historicalAverageWidth := CalculateAverage(historicalWidths)

// 	return currentWidth < thresholdRatio*historicalAverageWidth
// }

// func isBuyTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
// 	return supertrend21[curr] && !supertrend21[prev] && supertrend14[curr]
// }

// func isSellTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
// 	return !supertrend21[curr] && supertrend21[prev] && !supertrend14[curr]
// }

// type SupertrendData struct {
// 	OpenTime         []string
// 	CloseTime        []string
// 	Supertrend21     []bool
// 	FinalLowerBand21 []float64
// 	FinalUpperBand21 []float64
// 	Supertrend14     []bool
// 	FinalLowerBand14 []float64
// 	FinalUpperBand14 []float64
// 	Rsi21            []float64
// 	Rsi3             []float64
// 	AdxSignal        []float64
// 	BuySignals       []float64
// 	SellSignals      []float64
// 	StopLoss         []float64
// }

// func (data *SupertrendData) ToMapSlice() []map[string]interface{} {
// 	length := len(data.Supertrend21) // Assuming all slices are the same length
// 	results := make([]map[string]interface{}, length)

// 	for i := 0; i < length; i++ {
// 		row := map[string]interface{}{
// 			"OpenTime":         data.OpenTime[i],
// 			"CloseTime":        data.CloseTime[i],
// 			"Supertrend21":     data.Supertrend21[i],
// 			"FinalLowerBand21": data.FinalLowerBand21[i],
// 			"FinalUpperBand21": data.FinalUpperBand21[i],
// 			"Supertrend14":     data.Supertrend14[i],
// 			"FinalLowerBand14": data.FinalLowerBand14[i],
// 			"FinalUpperBand14": data.FinalUpperBand14[i],
// 			"Rsi21":            data.Rsi21[i],
// 			"Rsi3":             data.Rsi3[i],
// 			"AdxSignal":        data.AdxSignal[i],
// 			"BuySignals":       data.BuySignals[i],
// 			"SellSignals":      data.SellSignals[i],
// 			"StopLoss":         data.StopLoss[i],
// 		}
// 		results[i] = row
// 	}

// 	return results
// }

// func ExtractCandles(df dataframe.DataFrame) []Candle {
// 	candles := make([]Candle, df.Nrow())
// 	for i := 0; i < df.Nrow(); i++ {
// 		openTime := time.UnixMilli(int64(df.Col("OpenTime").Elem(i).Float())).Format("2006-01-02 15:04:05")
// 		closeTime := time.UnixMilli(int64(df.Col("CloseTime").Elem(i).Float())).Format("2006-01-02 15:04:05")

// 		candles[i] = Candle{
// 			OpenTime:  openTime,
// 			Open:      df.Col("Open").Elem(i).Float(),
// 			High:      df.Col("High").Elem(i).Float(),
// 			Low:       df.Col("Low").Elem(i).Float(),
// 			Close:     df.Col("Close").Elem(i).Float(),
// 			CloseTime: closeTime,
// 		}
// 	}
// 	return candles
// }

// // ExtractCloses extracts the closing prices from a slice of HeikenAshiCandle.
// func ExtractCloses(candles []HeikenAshiCandle) []float64 {
// 	closes := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		closes[i] = candle.Close
// 	}
// 	return closes
// }

// // ExtractHighs extracts the high prices from a slice of HeikenAshiCandle.
// func ExtractHighs(candles []HeikenAshiCandle) []float64 {
// 	highs := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		highs[i] = candle.High
// 	}
// 	return highs
// }

// // ExtractLows extracts the low prices from a slice of HeikenAshiCandle.
// func ExtractLows(candles []HeikenAshiCandle) []float64 {
// 	lows := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		lows[i] = candle.Low
// 	}
// 	return lows
// }

// func HaTwoSupertrends(df dataframe.DataFrame, multiplier21, multiplier14 float64, atrPeriod21, atrPeriod14 int) dataframe.DataFrame {
// 	candles := ExtractCandles(df)
// 	haCandles := CalculateHeikenAshi(candles)
// 	length := len(haCandles)
// 	data := SupertrendData{
// 		OpenTime:         make([]string, length),
// 		CloseTime:        make([]string, length),
// 		Supertrend21:     make([]bool, length),
// 		FinalLowerBand21: make([]float64, length),
// 		FinalUpperBand21: make([]float64, length),
// 		Supertrend14:     make([]bool, length),
// 		FinalLowerBand14: make([]float64, length),
// 		FinalUpperBand14: make([]float64, length),
// 		Rsi21:            CalculateRSI(ExtractCloses(haCandles), 21),
// 		Rsi3:             CalculateRSI(ExtractCloses(haCandles), 3),
// 		AdxSignal:        CalculateADX(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), 14),
// 		BuySignals:       make([]float64, length),
// 		SellSignals:      make([]float64, length),
// 		StopLoss:         make([]float64, length),
// 	}

// 	// Calculate ATR for both periods
// 	atr21 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21)
// 	atr14 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14)

// 	for i := 1; i < length; i++ {
// 		// Set OpenTime and CloseTime
// 		data.OpenTime[i] = candles[i].OpenTime
// 		data.CloseTime[i] = candles[i].CloseTime

// 		// Calculate rolling mean for upper and lower bands
// 		if i >= atrPeriod21 {
// 			data.FinalUpperBand21[i] = haCandles[i].High + multiplier21*atr21[i]
// 			data.FinalLowerBand21[i] = haCandles[i].Low - multiplier21*atr21[i]
// 		} else {
// 			data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
// 			data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
// 		}

// 		if i >= atrPeriod14 {
// 			data.FinalUpperBand14[i] = haCandles[i].High + multiplier14*atr14[i]
// 			data.FinalLowerBand14[i] = haCandles[i].Low - multiplier14*atr14[i]
// 		} else {
// 			data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
// 			data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
// 		}

// 		// Calculate Supertrend logic for 21 period
// 		if haCandles[i].Close > data.FinalUpperBand21[i-1] {
// 			data.Supertrend21[i] = true
// 		} else if haCandles[i].Close < data.FinalLowerBand21[i-1] {
// 			data.Supertrend21[i] = false
// 		} else {
// 			data.Supertrend21[i] = data.Supertrend21[i-1]
// 			if data.Supertrend21[i] {
// 				data.FinalLowerBand21[i] = math.Max(data.FinalLowerBand21[i], data.FinalLowerBand21[i-1])
// 			} else {
// 				data.FinalUpperBand21[i] = math.Min(data.FinalUpperBand21[i], data.FinalUpperBand21[i-1])
// 			}
// 		}

// 		// Calculate Supertrend logic for 14 period
// 		if haCandles[i].Close > data.FinalUpperBand14[i-1] {
// 			data.Supertrend14[i] = true
// 		} else if haCandles[i].Close < data.FinalLowerBand14[i-1] {
// 			data.Supertrend14[i] = false
// 		} else {
// 			data.Supertrend14[i] = data.Supertrend14[i-1]
// 			if data.Supertrend14[i] {
// 				data.FinalLowerBand14[i] = math.Max(data.FinalLowerBand14[i], data.FinalLowerBand14[i-1])
// 			} else {
// 				data.FinalUpperBand14[i] = math.Min(data.FinalUpperBand14[i], data.FinalUpperBand14[i-1])
// 			}
// 		}

// 		// Check for buy or sell signals
// 		if isBuyTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 			data.BuySignals[i] = haCandles[i].Close
// 		}
// 		if isSellTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 			data.SellSignals[i] = haCandles[i].Close
// 		}

// 		// Assign stop loss values based on Supertrend14
// 		if data.Supertrend14[i] {
// 			data.StopLoss[i] = data.FinalLowerBand14[i]
// 		}
// 	}

// 	dataFrameLike := data.ToMapSlice()
// 	resultDf := dataframe.LoadMaps(dataFrameLike)

// 	return resultDf
// }

// // HaTwoSupertrends calculates two sets of supertrend indicators using Heiken Ashi candles.
// // func HaTwoSupertrends(df dataframe.DataFrame, multiplier21, multiplier14 float64, atrPeriod21, atrPeriod14 int) dataframe.DataFrame {
// // 	candles := ExtractCandles(df)
// // 	haCandles := CalculateHeikenAshi(candles)
// // 	length := len(haCandles)
// // 	data := SupertrendData{
// // 		OpenTime:         make([]string, length),
// // 		CloseTime:        make([]string, length),
// // 		Supertrend21:     make([]bool, length),
// // 		FinalLowerBand21: make([]float64, length),
// // 		FinalUpperBand21: make([]float64, length),
// // 		Supertrend14:     make([]bool, length),
// // 		FinalLowerBand14: make([]float64, length),
// // 		FinalUpperBand14: make([]float64, length),
// // 		Rsi21:            CalculateRSI(ExtractCloses(haCandles), 21),
// // 		Rsi3:             CalculateRSI(ExtractCloses(haCandles), 3),
// // 		AdxSignal:        CalculateADX(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), 14),
// // 		BuySignals:       make([]float64, length),
// // 		SellSignals:      make([]float64, length),
// // 		StopLoss:         make([]float64, length),
// // 	}

// // 	// Calculate ATR for both periods
// // 	atr21 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21)
// // 	atr14 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14)

// // 	for i := 1; i < length; i++ {
// // 		// Set OpenTime and CloseTime
// // 		data.OpenTime[i] = candles[i].OpenTime
// // 		data.CloseTime[i] = candles[i].CloseTime

// // 		// Set the initial condition for the first element if needed
// // 		data.FinalUpperBand21[i] = haCandles[i].High + multiplier21*atr21[i]
// // 		data.FinalLowerBand21[i] = haCandles[i].Low - multiplier21*atr21[i]
// // 		data.FinalUpperBand14[i] = haCandles[i].High + multiplier14*atr14[i]
// // 		data.FinalLowerBand14[i] = haCandles[i].Low - multiplier14*atr14[i]

// // 		// Calculate Supertrend logic for 21 period
// // 		if haCandles[i].Close > data.FinalUpperBand21[i-1] {
// // 			data.Supertrend21[i] = true
// // 		} else if haCandles[i].Close < data.FinalLowerBand21[i-1] {
// // 			data.Supertrend21[i] = false
// // 		} else {
// // 			data.Supertrend21[i] = data.Supertrend21[i-1]
// // 			if data.Supertrend21[i] {
// // 				data.FinalLowerBand21[i] = math.Max(data.FinalLowerBand21[i], data.FinalLowerBand21[i-1])
// // 			} else {
// // 				data.FinalUpperBand21[i] = math.Min(data.FinalUpperBand21[i], data.FinalUpperBand21[i-1])
// // 			}
// // 		}

// // 		// Calculate Supertrend logic for 14 period
// // 		if haCandles[i].Close > data.FinalUpperBand14[i-1] {
// // 			data.Supertrend14[i] = true
// // 		} else if haCandles[i].Close < data.FinalLowerBand14[i-1] {
// // 			data.Supertrend14[i] = false
// // 		} else {
// // 			data.Supertrend14[i] = data.Supertrend14[i-1]
// // 			if data.Supertrend14[i] {
// // 				data.FinalLowerBand14[i] = math.Max(data.FinalLowerBand14[i], data.FinalLowerBand14[i-1])
// // 			} else {
// // 				data.FinalUpperBand14[i] = math.Min(data.FinalUpperBand14[i], data.FinalUpperBand14[i-1])
// // 			}
// // 		}

// // 		// Check for buy or sell signals
// // 		if isBuyTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// // 			data.BuySignals[i] = haCandles[i].Close
// // 		}
// // 		if isSellTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// // 			data.SellSignals[i] = haCandles[i].Close
// // 		}

// // 		// Assign stop loss values based on Supertrend14
// // 		if data.Supertrend14[i] {
// // 			data.StopLoss[i] = data.FinalLowerBand14[i]
// // 		}
// // 	}

// // 	dataFrameLike := data.ToMapSlice()
// // 	resultDf := dataframe.LoadMaps(dataFrameLike)

// // 	return resultDf
// // }

// // type SupertrendData struct {
// // 	Supertrend21         bool
// // 	FinalLowerband21     float64
// // 	FinalUpperband21     float64
// // 	Supertrend14         bool
// // 	FinalLowerband14     float64
// // 	FinalUpperband14     float64
// // 	RSI21                float64
// // 	RSI3                 float64
// // 	ADX                  float64
// // 	Buy                  float64
// // 	Sell                 float64
// // 	StopLoss             float64
// // }

// // func haTwoSupertrends(candles []Candle, multiplier21, multiplier14 int, atrPeriod21, atrPeriod14 int) []SupertrendData {
// // 	results := make([]SupertrendData, len(candles))
// // 	if len(candles) == 0 {
// // 		return results
// // 	}

// // 	// Placeholder for indicator calculations
// // 	atr21 := calculateATR(candles, atrPeriod21)
// // 	atr14 := calculateATR(candles, atrPeriod14)
// // 	rsi21 := calculateRSI(candles, 21)
// // 	rsi3 := calculateRSI(candles, 3)
// // 	adx := calculateADX(candles, 14)

// // 	for i := 1; i < len(candles); i++ {
// // 		haOpen := (candles[i-1].Open + candles[i-1].Close) / 2
// // 		haClose := (candles[i].Open + candles[i].High + candles[i].Low + candles[i].Close) / 4
// // 		haHigh := max(candles[i].High, haOpen, haClose)
// // 		haLow := min(candles[i].Low, haOpen, haClose)

// // 		finalUpperband21 := haHigh + float64(multiplier21)*atr21[i]
// // 		finalLowerband21 := haLow - float64(multiplier21)*atr21[i]
// // 		finalUpperband14 := haHigh + float64(multiplier14)*atr14[i]
// // 		finalLowerband14 := haLow - float64(multiplier14)*atr14[i]

// // 		current := &results[i]
// // 		previous := &results[i-1]

// // 		// Determine supertrend status based on previous band and current price
// // 		current.Supertrend21 = haClose > previous.FinalUpperband21
// // 		current.Supertrend14 = haClose > previous.FinalUpperband14
// // 		current.FinalUpperband21 = finalUpperband21
// // 		current.FinalLowerband21 = finalLowerband21
// // 		current.FinalUpperband14 = finalUpperband14
// // 		current.FinalLowerband14 = finalLowerband14
// // 		current.RSI21 = rsi21[i]
// // 		current.RSI3 = rsi3[i]
// // 		current.ADX = adx[i]

// // 		// Buy/Sell logic
// // 		if isBuyTrend(current, previous) {
// // 			current.Buy = haClose
// // 		} else if isSellTrend(current, previous) {
// // 			current.Sell = haClose
// // 		}

// // 		// Assign stop loss based on supertrend status
// // 		if current.Supertrend14 {
// // 			current.StopLoss = current.FinalLowerband14
// // 		} else {
// // 			current.StopLoss = current.FinalUpperband14
// // 		}
// // 	}

// // 	return results
// // }

// // func isBuyTrend(current, previous *SupertrendData) bool {
// // 	return current.Supertrend21 && !previous.Supertrend21 && current.Supertrend14
// // }

// // func isSellTrend(current, previous *SupertrendData) bool {
// // 	return !current.Supertrend21 && previous.Supertrend21 && !current.Supertrend14
// // }

// // func max(values ...float64) float64 {
// // 	maxValue := values[0]
// // 	for _, v := range values {
// // 		if v > maxValue {
// // 			maxValue = v
// // 		}
// // 	}
// // 	return maxValue
// // }

// // func min(values ...float64) float64 {
// // 	minValue := values[0]
// // 	for _, v := range values {
// // 		if v < minValue {
// // 			minValue = v
// // 		}
// // 	}
// // 	return minValue
// // }

// HERE

// import (
// 	"fmt"
// 	"math"
// 	"time"

// 	"github.com/go-gota/gota/dataframe"
// )

// type Candle struct {
// 	OpenTime  string
// 	Open      float64
// 	High      float64
// 	Low       float64
// 	Close     float64
// 	CloseTime string
// }

// type HeikenAshiCandle struct {
// 	Open, High, Low, Close float64
// }

// type SupertrendData struct {
// 	OpenTime         []string
// 	CloseTime        []string
// 	Open             []float64
// 	High             []float64
// 	Low              []float64
// 	Close            []float64
// 	Supertrend21     []bool
// 	FinalLowerBand21 []float64
// 	FinalUpperBand21 []float64
// 	Supertrend14     []bool
// 	FinalLowerBand14 []float64
// 	FinalUpperBand14 []float64
// 	Rsi21            []float64
// 	Rsi3             []float64
// 	AdxSignal        []float64
// 	BUY              []float64
// 	SELL             []float64
// 	StopLoss         []float64
// }

// // CalculateHeikenAshi takes a slice of Candle and returns a slice of HeikenAshiCandle.
// func CalculateHeikenAshi(candles []Candle) []HeikenAshiCandle {
// 	hCandles := make([]HeikenAshiCandle, len(candles))
// 	if len(candles) == 0 {
// 		return hCandles
// 	}

// 	// Calculate the first Heiken Ashi candle based on the first regular candle
// 	hCandles[0].Close = (candles[0].Open + candles[0].High + candles[0].Low + candles[0].Close) / 4
// 	hCandles[0].Open = (candles[0].Open + candles[0].Close) / 2
// 	hCandles[0].High = candles[0].High
// 	hCandles[0].Low = candles[0].Low

// 	// Calculate subsequent Heiken Ashi candles
// 	for i := 1; i < len(candles); i++ {
// 		hCandles[i].Close = (candles[i].Open + candles[i].High + candles[i].Low + candles[i].Close) / 4
// 		hCandles[i].Open = (hCandles[i-1].Open + hCandles[i-1].Close) / 2
// 		hCandles[i].High = math.Max(math.Max(candles[i].High, hCandles[i].Open), hCandles[i].Close)
// 		hCandles[i].Low = math.Min(math.Min(candles[i].Low, hCandles[i].Open), hCandles[i].Close)
// 	}

// 	return hCandles
// }

// // CalculateDeltas calculates the difference between elements in a slice.
// func CalculateDeltas(data []float64) []float64 {
// 	deltas := make([]float64, len(data))
// 	for i := 1; i < len(data); i++ {
// 		deltas[i] = data[i] - data[i-1]
// 	}
// 	return deltas
// }

// // CalculateDM calculates the Positive and Negative Directional Movements.
// func CalculateDM(high, low []float64) (posDM, negDM []float64) {
// 	deltaHigh := CalculateDeltas(high)
// 	deltaLow := CalculateDeltas(low)
// 	posDM = make([]float64, len(high))
// 	negDM = make([]float64, len(low))

// 	for i := 1; i < len(high); i++ {
// 		if deltaHigh[i] > 0 && deltaHigh[i] > deltaLow[i] {
// 			posDM[i] = deltaHigh[i]
// 		}
// 		if deltaLow[i] > 0 && deltaLow[i] > deltaHigh[i] {
// 			negDM[i] = deltaLow[i]
// 		}
// 	}
// 	return posDM, negDM
// }

// // CalculateTrueRange calculates the True Range.
// func CalculateTrueRange(high, low, close []float64) []float64 {
// 	trueRange := make([]float64, len(high))
// 	for i := 0; i < len(high); i++ {
// 		hl := high[i] - low[i]
// 		var hc, lc float64
// 		if i > 0 {
// 			hc = math.Abs(high[i] - close[i-1])
// 			lc = math.Abs(low[i] - close[i-1])
// 		}
// 		trueRange[i] = math.Max(hl, math.Max(hc, lc))
// 	}
// 	return trueRange
// }

// // SimpleMovingSum calculates the sum over a window.
// func SimpleMovingSum(data []float64, period int) []float64 {
// 	result := make([]float64, len(data))
// 	var sum float64
// 	for i := 0; i < len(data); i++ {
// 		if i >= period {
// 			sum -= data[i-period]
// 		}
// 		sum += data[i]
// 		if i >= period-1 {
// 			result[i] = sum
// 		}
// 	}
// 	return result
// }

// // CalculateADX calculates the Average Directional Movement Index.
// func CalculateADX(high, low, close []float64, period int) []float64 {
// 	trueRange := CalculateTrueRange(high, low, close)
// 	posDM, negDM := CalculateDM(high, low)

// 	smoothedTR := SimpleMovingSum(trueRange, period)
// 	smoothedPosDM := SimpleMovingSum(posDM, period)
// 	smoothedNegDM := SimpleMovingSum(negDM, period)

// 	posDI := make([]float64, len(high))
// 	negDI := make([]float64, len(low))
// 	for i := range posDI {
// 		if smoothedTR[i] != 0 {
// 			posDI[i] = 100 * smoothedPosDM[i] / smoothedTR[i]
// 			negDI[i] = 100 * smoothedNegDM[i] / smoothedTR[i]
// 		}
// 	}

// 	dx := make([]float64, len(posDI))
// 	for i := range dx {
// 		if (posDI[i] + negDI[i]) != 0 {
// 			dx[i] = 100 * math.Abs(posDI[i]-negDI[i]) / (posDI[i] + negDI[i])
// 		}
// 	}

// 	adx := SimpleMovingSum(dx, period)
// 	for i := range adx {
// 		adx[i] /= float64(period)
// 	}

// 	return adx
// }

// // CalculateGainsAndLosses calculates the gains and losses.
// func CalculateGainsAndLosses(deltas []float64) (gains, losses []float64) {
// 	gains = make([]float64, len(deltas))
// 	losses = make([]float64, len(deltas))
// 	for i, delta := range deltas {
// 		if delta > 0 {
// 			gains[i] = delta
// 		} else {
// 			losses[i] = -delta // Make losses positive
// 		}
// 	}
// 	return gains, losses
// }

// // SimpleMovingAverage calculates the simple moving average.
// func SimpleMovingAverage(data []float64, period int) []float64 {
// 	result := make([]float64, len(data))
// 	var sum float64
// 	for i := 0; i < len(data); i++ {
// 		sum += data[i]
// 		if i >= period {
// 			sum -= data[i-period]
// 		}
// 		if i >= period-1 {
// 			result[i] = sum / float64(period)
// 		} else {
// 			result[i] = sum / float64(i+1)
// 		}
// 	}
// 	return result
// }

// // CalculateEMA calculates the exponential moving average.
// func CalculateEMA(data []float64, period int) []float64 {
// 	ema := make([]float64, len(data))
// 	alpha := 2.0 / (float64(period) + 1.0) // Smoothing factor
// 	ema[0] = data[0]                       // Start with the first data point

// 	for i := 1; i < len(data); i++ {
// 		ema[i] = data[i]*alpha + ema[i-1]*(1-alpha)
// 	}

// 	return ema
// }

// // CalculateATR calculates the Average True Range.
// func CalculateATR(high, low, close []float64, period int) []float64 {
// 	trueRange := CalculateTrueRange(high, low, close)
// 	atr := SimpleMovingAverage(trueRange, period)
// 	return atr
// }

// // CalculateRSI calculates the Relative Strength Index.
// func CalculateRSI(data []float64, period int) []float64 {
// 	deltas := CalculateDeltas(data)
// 	gains, losses := CalculateGainsAndLosses(deltas)

// 	avgGains := SimpleMovingAverage(gains, period)
// 	avgLosses := SimpleMovingAverage(losses, period)

// 	rsi := make([]float64, len(data))
// 	for i := range rsi {
// 		if avgLosses[i] == 0 {
// 			rsi[i] = 100 // If no losses, RSI is set to 100
// 		} else {
// 			rs := avgGains[i] / avgLosses[i]
// 			rsi[i] = 100 - (100 / (1 + rs))
// 		}
// 	}
// 	return rsi
// }

// // CalculateKeltnerChannel calculates the Keltner Channel.
// func CalculateKeltnerChannel(high, low, close []float64, emaPeriod, atrPeriod int, multiplier float64) ([]float64, []float64, []float64) {
// 	ema := CalculateEMA(close, emaPeriod)
// 	atr := CalculateATR(high, low, close, atrPeriod)

// 	upperBand := make([]float64, len(close))
// 	lowerBand := make([]float64, len(close))

// 	for i := range ema {
// 		upperBand[i] = ema[i] + multiplier*atr[i]
// 		lowerBand[i] = ema[i] - multiplier*atr[i]
// 	}

// 	return ema, upperBand, lowerBand
// }

// // CalculateKeltnerChannelWidths calculates the widths of the Keltner Channel.
// func CalculateKeltnerChannelWidths(high, low, close []float64, emaPeriod, atrPeriod int, multiplier float64) []float64 {
// 	_, upperBand, lowerBand := CalculateKeltnerChannel(high, low, close, emaPeriod, atrPeriod, multiplier)
// 	widths := make([]float64, len(upperBand))
// 	for i := range upperBand {
// 		widths[i] = upperBand[i] - lowerBand[i]
// 	}
// 	return widths
// }

// // CalculateAverage returns the average of a slice of float64.
// func CalculateAverage(data []float64) float64 {
// 	sum := 0.0
// 	for _, value := range data {
// 		sum += value
// 	}
// 	return sum / float64(len(data))
// }

// // IsLowVolatilityKeltner checks if the current Keltner Channel width is below a historical threshold.
// func IsLowVolatilityKeltner(high, low, close []float64, emaPeriod, atrPeriod, historyPeriod int, multiplier, thresholdRatio float64) bool {
// 	widths := CalculateKeltnerChannelWidths(high, low, close, emaPeriod, atrPeriod, multiplier)
// 	if len(widths) < historyPeriod {
// 		fmt.Println("Not enough data to determine volatility.")
// 		return false
// 	}
// 	historicalWidths := widths[len(widths)-historyPeriod-1 : len(widths)-1]
// 	currentWidth := widths[len(widths)-1]
// 	historicalAverageWidth := CalculateAverage(historicalWidths)

// 	return currentWidth < thresholdRatio*historicalAverageWidth
// }

// func isBuyTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
// 	return supertrend21[curr] && !supertrend21[prev] && supertrend14[curr]
// }

// func isSellTrend(supertrend21, supertrend14 []bool, curr, prev int) bool {
// 	return !supertrend21[curr] && supertrend21[prev] && !supertrend14[curr]
// }

// func (data *SupertrendData) ToMapSlice() []map[string]interface{} {
// 	length := len(data.Supertrend21) // Assuming all slices are the same length
// 	results := make([]map[string]interface{}, length)

// 	for i := 0; i < length; i++ {
// 		row := map[string]interface{}{
// 			"OpenTime":         data.OpenTime[i],
// 			"CloseTime":        data.CloseTime[i],
// 			"Supertrend21":     data.Supertrend21[i],
// 			"FinalLowerBand21": data.FinalLowerBand21[i],
// 			"FinalUpperBand21": data.FinalUpperBand21[i],
// 			"Supertrend14":     data.Supertrend14[i],
// 			"FinalLowerBand14": data.FinalLowerBand14[i],
// 			"FinalUpperBand14": data.FinalUpperBand14[i],
// 			"Rsi21":            data.Rsi21[i],
// 			"Rsi3":             data.Rsi3[i],
// 			"AdxSignal":        data.AdxSignal[i],
// 			"BuySignals":       data.BuySignals[i],
// 			"SellSignals":      data.SellSignals[i],
// 			"StopLoss":         data.StopLoss[i],
// 		}
// 		results[i] = row
// 	}

// 	return results
// }

// func ExtractCandles(df dataframe.DataFrame) []Candle {
// 	candles := make([]Candle, df.Nrow())
// 	for i := 0; i < df.Nrow(); i++ {
// 		openTime := time.UnixMilli(int64(df.Col("OpenTime").Elem(i).Float())).Format("2006-01-02 15:04:05")
// 		closeTime := time.UnixMilli(int64(df.Col("CloseTime").Elem(i).Float())).Format("2006-01-02 15:04:05")

// 		candles[i] = Candle{
// 			OpenTime:  openTime,
// 			Open:      df.Col("Open").Elem(i).Float(),
// 			High:      df.Col("High").Elem(i).Float(),
// 			Low:       df.Col("Low").Elem(i).Float(),
// 			Close:     df.Col("Close").Elem(i).Float(),
// 			CloseTime: closeTime,
// 		}
// 	}
// 	return candles
// }

// // ExtractCloses extracts the closing prices from a slice of HeikenAshiCandle.
// func ExtractCloses(candles []HeikenAshiCandle) []float64 {
// 	closes := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		closes[i] = candle.Close
// 	}
// 	return closes
// }

// // ExtractHighs extracts the high prices from a slice of HeikenAshiCandle.
// func ExtractHighs(candles []HeikenAshiCandle) []float64 {
// 	highs := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		highs[i] = candle.High
// 	}
// 	return highs
// }

// // ExtractLows extracts the low prices from a slice of HeikenAshiCandle.
// func ExtractLows(candles []HeikenAshiCandle) []float64 {
// 	lows := make([]float64, len(candles))
// 	for i, candle := range candles {
// 		lows[i] = candle.Low
// 	}
// 	return lows
// }

// func CalculateSupertrend(high, low, close []float64, period int, multiplier float64) ([]float64, []float64, []float64) {
// 	atr := CalculateATR(high, low, close, period)

// 	upperBand := make([]float64, len(close))
// 	lowerBand := make([]float64, len(close))
// 	supertrend := make([]float64, len(close))
// 	inUptrend := make([]bool, len(close))

// 	for i := range close {
// 		upperBand[i] = (high[i]+low[i])/2 + multiplier*atr[i]
// 		lowerBand[i] = (high[i]+low[i])/2 - multiplier*atr[i]
// 	}

// 	for i := range close {
// 		if i == 0 {
// 			inUptrend[i] = true
// 			supertrend[i] = close[i]
// 			continue
// 		}

// 		if close[i] > upperBand[i-1] {
// 			inUptrend[i] = true
// 		} else if close[i] < lowerBand[i-1] {
// 			inUptrend[i] = false
// 		} else {
// 			inUptrend[i] = inUptrend[i-1]
// 			if inUptrend[i] && lowerBand[i] < lowerBand[i-1] {
// 				lowerBand[i] = lowerBand[i-1]
// 			}
// 			if !inUptrend[i] && upperBand[i] > upperBand[i-1] {
// 				upperBand[i] = upperBand[i-1]
// 			}
// 		}

// 		if inUptrend[i] {
// 			supertrend[i] = lowerBand[i]
// 		} else {
// 			supertrend[i] = upperBand[i]
// 		}
// 	}

// 	return supertrend, upperBand, lowerBand
// }

// func HaTwoSupertrends(df dataframe.DataFrame, multiplier21, multiplier14 float64, atrPeriod21, atrPeriod14 int) dataframe.DataFrame {
// 	candles := ExtractCandles(df)
// 	haCandles := CalculateHeikenAshi(candles)
// 	length := len(haCandles)
// 	data := SupertrendData{
// 		OpenTime:         make([]string, length),
// 		CloseTime:        make([]string, length),
// 		Open:             make([]float64, length),
// 		High:             make([]float64, length),
// 		Low:              make([]float64, length),
// 		Close:            make([]float64, length),
// 		Supertrend21:     make([]bool, length),
// 		FinalLowerBand21: make([]float64, length),
// 		FinalUpperBand21: make([]float64, length),
// 		Supertrend14:     make([]bool, length),
// 		FinalLowerBand14: make([]float64, length),
// 		FinalUpperBand14: make([]float64, length),
// 		Rsi21:            CalculateRSI(ExtractCloses(haCandles), 21),
// 		Rsi3:             CalculateRSI(ExtractCloses(haCandles), 3),
// 		AdxSignal:        CalculateADX(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), 7), // Corrected to use 7
// 		BUY:              make([]float64, length),
// 		SELL:             make([]float64, length),
// 		StopLoss:         make([]float64, length),
// 	}

// 	// Calculate ATR for both periods
// 	// atr21 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21)
// 	// atr14 := CalculateATR(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14)

// 	// for i := 1; i < length; i++ {
// 	// 	// Set OpenTime and CloseTime
// 	// 	data.OpenTime[i] = candles[i].OpenTime
// 	// 	data.CloseTime[i] = candles[i].CloseTime

// 	// 	// Calculate rolling mean for upper and lower bands
// 	// 	if i >= atrPeriod21 {
// 	// 		data.FinalUpperBand21[i] = haCandles[i].High + multiplier21*atr21[i]
// 	// 		data.FinalLowerBand21[i] = haCandles[i].Low - multiplier21*atr21[i]
// 	// 	} else {
// 	// 		data.FinalUpperBand21[i] = data.FinalUpperBand21[i-1]
// 	// 		data.FinalLowerBand21[i] = data.FinalLowerBand21[i-1]
// 	// 	}

// 	// 	if i >= atrPeriod14 {
// 	// 		data.FinalUpperBand14[i] = haCandles[i].High + multiplier14*atr14[i]
// 	// 		data.FinalLowerBand14[i] = haCandles[i].Low - multiplier14*atr14[i]
// 	// 	} else {
// 	// 		data.FinalUpperBand14[i] = data.FinalUpperBand14[i-1]
// 	// 		data.FinalLowerBand14[i] = data.FinalLowerBand14[i-1]
// 	// 	}

// 	// 	// Calculate Supertrend logic for 21 period
// 	// 	if haCandles[i].Close > data.FinalUpperBand21[i-1] {
// 	// 		data.Supertrend21[i] = true
// 	// 	} else if haCandles[i].Close < data.FinalLowerBand21[i-1] {
// 	// 		data.Supertrend21[i] = false
// 	// 	} else {
// 	// 		data.Supertrend21[i] = data.Supertrend21[i-1]
// 	// 		if data.Supertrend21[i] {
// 	// 			data.FinalLowerBand21[i] = math.Max(data.FinalLowerBand21[i], data.FinalLowerBand21[i-1])
// 	// 		} else {
// 	// 			data.FinalUpperBand21[i] = math.Min(data.FinalUpperBand21[i], data.FinalUpperBand21[i-1])
// 	// 		}
// 	// 	}

// 	// 	// Calculate Supertrend logic for 14 period
// 	// 	if haCandles[i].Close > data.FinalUpperBand14[i-1] {
// 	// 		data.Supertrend14[i] = true
// 	// 	} else if haCandles[i].Close < data.FinalLowerBand14[i-1] {
// 	// 		data.Supertrend14[i] = false
// 	// 	} else {
// 	// 		data.Supertrend14[i] = data.Supertrend14[i-1]
// 	// 		if data.Supertrend14[i] {
// 	// 			data.FinalLowerBand14[i] = math.Max(data.FinalLowerBand14[i], data.FinalLowerBand14[i-1])
// 	// 		} else {
// 	// 			data.FinalUpperBand14[i] = math.Min(data.FinalUpperBand14[i], data.FinalUpperBand14[i-1])
// 	// 		}
// 	// 	}

// 	// 	// Check for buy or sell signals
// 	// 	if isBuyTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 	// 		data.BuySignals[i] = candles[i].Close
// 	// 	}
// 	// 	if isSellTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 	// 		data.SellSignals[i] = candles[i].Close
// 	// 	}

// 	// 	// Assign stop loss values based on Supertrend14
// 	// 	if data.Supertrend14[i] {
// 	// 		data.StopLoss[i] = data.FinalLowerBand14[i]
// 	// 	}
// 	// }
// 	supertrend21, upperBand21, lowerBand21 := CalculateSupertrend(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod21, multiplier21)
// 	supertrend14, upperBand14, lowerBand14 := CalculateSupertrend(ExtractHighs(haCandles), ExtractLows(haCandles), ExtractCloses(haCandles), atrPeriod14, multiplier14)

// 	for i := range supertrend21 {
// 		// Set OpenTime and CloseTime
// 		data.OpenTime[i] = candles[i].OpenTime
// 		data.CloseTime[i] = candles[i].CloseTime

// 		data.Supertrend21[i] = supertrend21[i] > ExtractCloses(haCandles)[i]
// 		data.FinalLowerBand21[i] = lowerBand21[i]
// 		data.FinalUpperBand21[i] = upperBand21[i]
// 		data.Supertrend14[i] = supertrend14[i] > ExtractCloses(haCandles)[i]
// 		data.FinalLowerBand14[i] = lowerBand14[i]
// 		data.FinalUpperBand14[i] = upperBand14[i]

// 		// Check for buy or sell signals
// 		if i > 0 && isBuyTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 			data.BuySignals[i] = candles[i].Close
// 		}
// 		if i > 0 && isSellTrend(data.Supertrend21, data.Supertrend14, i, i-1) {
// 			data.SellSignals[i] = candles[i].Close
// 		}

// 		// Assign stop loss values based on Supertrend14
// 		if data.Supertrend14[i] {
// 			data.StopLoss[i] = data.FinalLowerBand14[i]
// 		}
// 	}

// 	dataFrameLike := data.ToMapSlice()
// 	resultDf := dataframe.LoadMaps(dataFrameLike)

// 	return resultDf
// }
