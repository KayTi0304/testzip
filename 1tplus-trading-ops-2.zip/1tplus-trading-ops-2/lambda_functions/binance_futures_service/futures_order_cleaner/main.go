package main

import (
	"context"
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"trading-ops/common"

	"github.com/adshao/go-binance/v2/futures"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/kms"
)

var db *dynamodb.DynamoDB
var kmsClient *kms.KMS

func init() {
	sess := session.Must(session.NewSession())
	db = dynamodb.New(sess)
	kmsClient = kms.New(sess)
}

const publicKey = "66a7654bcc82709b168e1a932a4579c7f488c8fb7519a1031997bb2654677cea"

// var (
// 	capRisks = pbCapRisks
// )

var (
	positionSymbols = []string{common.SYMBOL_BTCUSDT, common.SYMBOL_ETHUSDT, common.SYMBOL_SOLUSDT}
)

func filterItem(strings []string, target string) []string {
	var result []string
	for _, str := range strings {
		if str == target {
			result = append(result, str)
			break
		}
	}
	return result
}

type DiscordRequest struct {
	Type int `json:"type"`
	Data struct {
		Name string `json:"name"`
	} `json:"data"`
}

type DiscordResponse struct {
	Type int         `json:"type"`
	Data interface{} `json:"data,omitempty"`
}

func replyMsg(content string) DiscordResponse {
	return DiscordResponse{
		Type: 4,
		Data: map[string]string{
			"content": content,
		},
	}
}

func closeAllFutUsersSymbol(symbol string) {
	for _, capRisk := range common.PbCapRisks {
		capRiskItem := fmt.Sprintf("BNB_FUT_%s_%s", capRisk, symbol)
		activeRecords, err := common.GetUserActiveCapRiskByTradePair(db, capRiskItem)
		capRiskItem = common.RenameCR4Display(capRiskItem)
		if err != nil {
			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during cancellation for %s: %+v", capRiskItem, err))
		}
		len := len(activeRecords)
		if len > 0 {
			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Starting to cancel %s position", capRiskItem))
		} else {
			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("No cancellation needed for %s", capRiskItem))
			continue
		}

		for index, record := range activeRecords {
			count := index + 1
			apiKey, secretKey, err := common.GetAndDecryptAPIKeys(db, kmsClient, record.UserID)
			if err != nil {
				common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
				continue
			}
			client := futures.NewClient(apiKey, secretKey)
			open, positionRisk, err := common.IsPositionOpen(client, symbol)
			if err != nil {
				common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
				continue
			}
			if open {
				currentPosSide, _, err := common.GetPositionInfo(positionRisk)
				if err != nil {
					common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
				}
				err = common.CloseFutPosition(client, positionRisk, currentPosSide)
				if err != nil {
					common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
					continue
				}
				common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Closed %s position for user %s", count, len, capRiskItem, record.UserID))
				openOrders, err := common.GetOpenOrders(client, symbol)
				if err != nil {
					common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
					continue
				}
				for _, order := range openOrders {
					if err := common.CancelOrder(client, order.Symbol, order.OrderID); err != nil {
						common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Error occurred during cancellation of %s for user %s: %+v", count, len, capRiskItem, record.UserID, err))
						continue
					}
					common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d Canceled %s %s order for user %s", count, len, capRiskItem, string(order.Type), record.UserID))
				}
			} else {
				common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%d/%d No %s position for user %s", count, len, capRiskItem, record.UserID))
			}
		}
	}
}

func process4ClosePos(symbol string) DiscordResponse {
	closeAllFutUsersSymbol(symbol)
	response := replyMsg(fmt.Sprintf("All users' %s positions have been closed!", symbol))
	return response
}

func updateDynamoDBItem(key string, tableName string, attributeName string, attributeValue string) error {
	sess := session.Must(session.NewSession())
	svc := dynamodb.New(sess)

	// Update item in DynamoDB
	_, err := svc.UpdateItem(&dynamodb.UpdateItemInput{
		TableName: aws.String(tableName),
		Key: map[string]*dynamodb.AttributeValue{
			"Exch_TradeType_CapRisk_TradePair": {
				S: aws.String(key),
			},
			"Exch_TradeType": {
				S: aws.String(common.ExchCode + "_" + common.TradeTypeCd),
			},
		},
		UpdateExpression: aws.String(fmt.Sprintf("SET %s = :val", attributeName)),
		ExpressionAttributeValues: map[string]*dynamodb.AttributeValue{
			":val": {
				S: aws.String(attributeValue),
			},
		},
		ReturnValues: aws.String(dynamodb.ReturnValueUpdatedNew),
	})

	if err != nil {
		return fmt.Errorf("failed to update item, %v", err)
	}

	return nil
}

func batchProcess4PauseResume(algoFunc string, reqSymbols []string, isPaused string) {
	intervals := common.GetAllIntervals()
	tradePairs, err := common.FetchActiveTradePairs(common.ExchCode, common.TradeTypeCd, intervals)
	if err != nil {
		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during fetching trade pairs: %+v", err))
	}
	msgAction := "pause"
	if isPaused != common.True {
		msgAction = "resume"
	}
	for _, tradePair := range tradePairs {
		if !common.ContainsStr(common.PbCapRisks, tradePair.CapitalRiskCode) {
			continue
		}
		if !common.ContainsStr(reqSymbols, tradePair.TradePair) {
			continue
		}
		key := fmt.Sprintf("%s_%s_%s_%s", common.ExchCode, common.TradeTypeCd, tradePair.CapitalRiskCode, tradePair.TradePair)
		if algoFunc != "" {
			err := updateDynamoDBItem(key, common.TradePairTableName, "AlgorithmFunction", algoFunc)
			if err != nil {
				common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during resume %s algo for trade pair %s: %+v", algoFunc, tradePair.TradePair, err))
			}
			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Resumed %s algo for trade pair code: %s", algoFunc, common.RenameCR4Display(key)))
		}

		err := updateDynamoDBItem(key, common.TradePairTableName, "IsPaused", isPaused)
		if err != nil {
			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during %s trade pair %s: %+v", msgAction, tradePair.TradePair, err))
		}
		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%sd trade pair code: %s", common.ToTitleCase(msgAction), common.RenameCR4Display(key)))
	}
}

func processSymbol4PauseResume(algo string, symbol string, isPaused string) DiscordResponse {
	reqSymbols := filterItem(positionSymbols, symbol)
	if len(reqSymbols) == 0 {
		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Requested trade pair %s does not exist", symbol))
	}
	batchProcess4PauseResume(algo, reqSymbols, isPaused)
	response := replyMsg("Done command successfully!")
	return response
}

type TickerValue struct {
	Symbol string
	Value  float64
}

// func test() {
// 	client := futures.NewClient("cFiTqhslaQTjOshIJKbrD1brXSKU8NOCOVLYRwPrSl9DpnE2VRPUL0HDsjEwguuW", "qWOdF5PY0k5L1KyMcTqYeY9h7iDQ9GGIHhnjAbyrTwNko5ahLnDoJaBGUFZX8d9n")
// 	tickers, err := client.NewListPriceChangeStatsService().Do(context.Background())
// 	if err != nil {
// 		log.Fatal(err)
// 	}

// 	// Fetch latest market prices
// 	prices, err := client.NewListPricesService().Do(context.Background())
// 	if err != nil {
// 		log.Fatal(err)
// 	}

// 	// Create a map for quick lookup of prices by symbol
// 	priceMap := make(map[string]float64)
// 	for _, price := range prices {
// 		priceValue, err := strconv.ParseFloat(price.Price, 64)
// 		if err != nil {
// 			log.Println(err)
// 			continue
// 		}
// 		priceMap[price.Symbol] = priceValue
// 	}

// 	var values []TickerValue
// 	for _, ticker := range tickers {
// 		// Filter symbols that end with 'USDT'
// 		if !strings.HasSuffix(ticker.Symbol, "USDT") {
// 			continue
// 		}

// 		volume, err := strconv.ParseFloat(ticker.Volume, 64)
// 		if err != nil {
// 			log.Println(err)
// 			continue
// 		}

// 		price, ok := priceMap[ticker.Symbol]
// 		if !ok {
// 			continue
// 		}

// 		value := volume * price
// 		values = append(values, TickerValue{Symbol: ticker.Symbol, Value: value})
// 	}

// 	sort.Slice(values, func(i, j int) bool {
// 		return values[i].Value > values[j].Value
// 	})

// 	top20 := values
// 	if len(values) > 20 {
// 		top20 = values[:20]
// 	}

// 	for _, tickerValue := range top20 {
// 		fmt.Printf("Symbol: %s, Value: %f\n", tickerValue.Symbol, tickerValue.Value)
// 	}
// }

func processAll4PauseResume(algo string, isPaused string) DiscordResponse {
	// test()
	batchProcess4PauseResume(algo, positionSymbols, isPaused)
	response := replyMsg("Done command successfully!")
	return response
}

// func processOnOffNightMode4AllSymbol(isOnNightMode string) DiscordResponse {
// 	intervals := common.GetAllIntervals()
// 	tradePairs, err := common.FetchActiveTradePairs(common.ExchCode, common.TradeTypeCd, intervals)
// 	if err != nil {
// 		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during fetching trade pairs: %+v", err))
// 	}
// 	algoFunc := common.ALGO_ST1
// 	msgAct := "Off"
// 	msgAction2 := "pause"
// 	isPaused := common.True
// 	if isOnNightMode == common.True {
// 		algoFunc = common.ALGO_ST2
// 		msgAct = "On"
// 		msgAction2 = "resume"
// 		isPaused = common.False
// 	}
// 	for _, tradePair := range tradePairs {
// 		if !common.ContainsStr(common.PbCapRisks, tradePair.CapitalRiskCode) {
// 			continue
// 		}
// 		key := fmt.Sprintf("%s_%s_%s_%s", common.ExchCode, common.TradeTypeCd, tradePair.CapitalRiskCode, tradePair.TradePair)
// 		err := updateDynamoDBItem(key, common.TradePairTableName, "AlgorithmFunction", algoFunc)
// 		if err != nil {
// 			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during %s Night Mode for trade pair %s: %+v", msgAct, tradePair.TradePair, err))
// 		}
// 		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%s Night Mode for trade pair code: %s", msgAct, key))

// 		// PAUSED
// 		err = updateDynamoDBItem(key, common.TradePairTableName, "IsPaused", isPaused)
// 		if err != nil {
// 			common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("Error occurred during %s trade pair %s: %+v", msgAction2, tradePair.TradePair, err))
// 		}
// 		common.Log4Trace(nil, common.BotUndergroundDisc, fmt.Sprintf("%sd trade pair code: %s", common.ToTitleCase(msgAction2), key))
// 	}
// 	response := replyMsg("Done command successfully!")
// 	return response
// }

func processSlashCmd(discordReq DiscordRequest) DiscordResponse {
	var response DiscordResponse
	err := common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		response = replyMsg("Having trouble with discord!")
		return response
	}

	switch discordReq.Data.Name {
	case "hi":
		response = replyMsg("Hello!")
	case "bin_ftrs_close_btcusdt":
		response = process4ClosePos(common.SYMBOL_BTCUSDT)
	case "bin_ftrs_close_ethusdt":
		response = process4ClosePos(common.SYMBOL_ETHUSDT)
	case "bin_ftrs_close_solusdt":
		response = process4ClosePos(common.SYMBOL_SOLUSDT)
	case "bin_ftrs_pause_all":
		response = processAll4PauseResume("", common.True)
	case "bin_ftrs_pause_btcusdt":
		response = processSymbol4PauseResume("", common.SYMBOL_BTCUSDT, common.True)
	case "bin_ftrs_pause_ethusdt":
		response = processSymbol4PauseResume("", common.SYMBOL_ETHUSDT, common.True)
	case "bin_ftrs_pause_solusdt":
		response = processSymbol4PauseResume("", common.SYMBOL_SOLUSDT, common.True)
	case "bin_ftrs_resume_st1_all":
		response = processAll4PauseResume(common.ALGO_ST1, common.False)
	case "bin_ftrs_resume_st2_all":
		response = processAll4PauseResume(common.ALGO_ST2, common.False)
	case "bin_ftrs_resume_st1_btcusdt":
		response = processSymbol4PauseResume(common.ALGO_ST1, common.SYMBOL_BTCUSDT, common.False)
	case "bin_ftrs_resume_st1_ethusdt":
		response = processSymbol4PauseResume(common.ALGO_ST1, common.SYMBOL_ETHUSDT, common.False)
	case "bin_ftrs_resume_st1_solusdt":
		response = processSymbol4PauseResume(common.ALGO_ST1, common.SYMBOL_SOLUSDT, common.False)
	case "bin_ftrs_resume_st2_btcusdt":
		response = processSymbol4PauseResume(common.ALGO_ST2, common.SYMBOL_BTCUSDT, common.False)
	case "bin_ftrs_resume_st2_ethusdt":
		response = processSymbol4PauseResume(common.ALGO_ST2, common.SYMBOL_ETHUSDT, common.False)
	case "bin_ftrs_resume_st2_solusdt":
		response = processSymbol4PauseResume(common.ALGO_ST2, common.SYMBOL_SOLUSDT, common.False)
	// case "bin_ftrs_resume_all":
	// 	response = processAll4PauseResume(common.False)
	// case "bin_ftrs_resume_btcusdt":
	// 	response = processSymbol4PauseResume(common.SYMBOL_BTCUSDT, common.False)
	// case "bin_ftrs_resume_ethusdt":
	// 	response = processSymbol4PauseResume(common.SYMBOL_ETHUSDT, common.False)
	// case "bin_ftrs_resume_solusdt":
	// 	response = processSymbol4PauseResume(common.SYMBOL_SOLUSDT, common.False)
	// case "bin_ftrs_on_night_mode":
	// 	response = processOnOffNightMode4AllSymbol(common.True)
	// case "bin_ftrs_off_night_mode":
	// 	response = processOnOffNightMode4AllSymbol(common.False)
	default:
		response = replyMsg("Unknown Command!")
	}
	return response
}

func verifySignature(body, signature, timestamp string) bool {
	log.Println("Signature:", signature)
	log.Println("Timestamp:", timestamp)
	log.Println("Body:", body)

	sigBytes, err := hex.DecodeString(signature)
	if err != nil {
		log.Println("Error decoding signature:", err)
		return false
	}

	pubKeyBytes, err := hex.DecodeString(publicKey)
	if err != nil {
		log.Println("Error decoding public key:", err)
		return false
	}

	msg := []byte(timestamp + body)
	log.Println("Verifying message:", msg)

	verified := ed25519.Verify(pubKeyBytes, msg, sigBytes)
	log.Println("Verification result:", verified)
	return verified
}

func handler(ctx context.Context, request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	log.Println("Received Headers:", request.Headers)
	log.Println("Received Body:", request.Body)

	signature := request.Headers["x-signature-ed25519"]
	timestamp := request.Headers["x-signature-timestamp"]

	log.Println("Received signature:", signature)
	log.Println("Received timestamp:", timestamp)

	if !verifySignature(request.Body, signature, timestamp) {
		log.Println("Failed signature verification")
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusUnauthorized,
			Body:       "invalid request signature",
			Headers: map[string]string{
				"Access-Control-Allow-Origin":  "*",
				"Access-Control-Allow-Headers": "Content-Type",
			},
		}, nil
	}

	var discordReq DiscordRequest
	err := json.Unmarshal([]byte(request.Body), &discordReq)
	if err != nil {
		log.Println("Error parsing JSON:", err)
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusBadRequest,
			Body:       "Invalid JSON",
			Headers: map[string]string{
				"Access-Control-Allow-Origin":  "*",
				"Access-Control-Allow-Headers": "Content-Type",
			},
		}, nil
	}

	if discordReq.Type == 1 {
		response := DiscordResponse{
			Type: 1,
		}
		responseBody, err := json.Marshal(response)
		if err != nil {
			log.Println("Error marshalling response JSON:", err)
			return events.APIGatewayProxyResponse{
				StatusCode: http.StatusInternalServerError,
				Body:       "JSON Encoding Error",
				Headers: map[string]string{
					"Access-Control-Allow-Origin":  "*",
					"Access-Control-Allow-Headers": "Content-Type",
				},
			}, nil
		}

		log.Println("Responding to PING with:", string(responseBody))
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusOK,
			Body:       string(responseBody),
			Headers: map[string]string{
				"Access-Control-Allow-Origin":  "*",
				"Access-Control-Allow-Headers": "Content-Type",
			},
		}, nil
	}

	if discordReq.Type == 2 {
		response := processSlashCmd(discordReq)

		responseBody, err := json.Marshal(response)
		if err != nil {
			log.Println("Error marshalling response JSON:", err)
			return events.APIGatewayProxyResponse{
				StatusCode: http.StatusInternalServerError,
				Body:       "JSON Encoding Error",
				Headers: map[string]string{
					"Access-Control-Allow-Origin":  "*",
					"Access-Control-Allow-Headers": "Content-Type",
				},
			}, nil
		}

		log.Println("Responding to command with:", string(responseBody))
		return events.APIGatewayProxyResponse{
			StatusCode: http.StatusOK,
			Body:       string(responseBody),
			Headers: map[string]string{
				"Access-Control-Allow-Origin":  "*",
				"Access-Control-Allow-Headers": "Content-Type",
			},
		}, nil
	}

	return events.APIGatewayProxyResponse{
		StatusCode: http.StatusNotImplemented,
		Body:       "Not Implemented",
		Headers: map[string]string{
			"Access-Control-Allow-Origin":  "*",
			"Access-Control-Allow-Headers": "Content-Type",
		},
	}, nil
}

func main() {
	lambda.Start(handler)
}
