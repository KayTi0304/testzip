package main

import (
	"context"
	"fmt"
	"log"
	"sort"
	"strconv"
	"time"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
)

type Request struct {
	UserID           string `json:"userID"`
	CapRisk          string `json:"capital_risk_code"`
	AllocVolume      string `json:"alloc_volume"`
	UserReqCapVolume string `json:"user_req_cap_volume"`
}

func Handler(ctx context.Context, req Request) (common.Response, error) {
	sess := session.Must(session.NewSession())

	// Create DynamoDB client
	svc := dynamodb.New(sess)
	// First deactivate existing items
	err := deleteExistingItems(svc, req)
	if err != nil {
		return common.Response{
			Code:    500,
			Message: "Failed to delete existing items",
			Data:    err.Error(),
		}, nil
	}

	intervals := common.GetAllIntervals()
	tradePairs, err := common.FetchActiveTradePairs(common.ExchCode, common.TradeTypeCd, intervals)
	if err != nil {
		return common.Response{
			Code:    500,
			Message: "Failed to fetch active trade pairs",
			Data:    err.Error(),
		}, nil
	}

	filteredPairs := filterAndSortTradePairs(tradePairs, req.CapRisk)

	allocVolume, err := strconv.ParseFloat(req.AllocVolume, 64)
	if err != nil {
		log.Fatalf("Error converting req.AllocVolume to float64: %v", err)
	}
	var cumulativeVolume float64 = 0
	affordablePairs := []common.TradePair{}

	for _, pair := range filteredPairs {
		reqCapVolStr := pair.ReqCapVol
		if req.UserReqCapVolume != "" && common.IsFloat(req.UserReqCapVolume) {
			reqCapVolStr = req.UserReqCapVolume
		}
		reqCapVol, err := strconv.ParseFloat(reqCapVolStr, 64)
		if err != nil {
			log.Fatalf("Error converting reqCapVolStr to float64 for pair %s: %v", pair.TradePair, err)
		}

		if cumulativeVolume+reqCapVol > allocVolume {
			break
		}
		cumulativeVolume += reqCapVol
		affordablePairs = append(affordablePairs, pair)
	}

	if cumulativeVolume > 0 && len(affordablePairs) > 0 {
		for _, pair := range affordablePairs {
			// reqCapVol, err := strconv.ParseFloat(pair.ReqCapVol, 64)
			// if err != nil {
			// 	log.Fatalf("Error converting pair.ReqCapVol to float64 for pair %s: %v", pair.TradePair, err)
			// }
			reqCapVolStr := pair.ReqCapVol
			if req.UserReqCapVolume != "" && common.IsFloat(req.UserReqCapVolume) {
				reqCapVolStr = req.UserReqCapVolume
			}
			reqCapVol, err := strconv.ParseFloat(reqCapVolStr, 64)
			if err != nil {
				log.Fatalf("Error converting reqCapVolStr to float64 for pair %s: %v", pair.TradePair, err)
			}
			proportion := reqCapVol / cumulativeVolume
			allocatedVolume := allocVolume * proportion
			putItemIntoDynamoDB(svc, req, pair, allocatedVolume)
		}
	}

	return common.Response{
		Code:    200,
		Message: "User inserted successfully into DynamoDB",
		Data:    nil,
	}, nil
}

func deleteExistingItems(svc *dynamodb.DynamoDB, request Request) error {
	// Build the query to find all items that should be deleted
	input := &dynamodb.QueryInput{
		TableName:              aws.String(common.UserCapRiskTableName),
		IndexName:              aws.String("UserExchTradeTypeIndex"),
		KeyConditionExpression: aws.String("UserID = :userID AND Exch_TradeType = :exchTradeType"),
		ExpressionAttributeValues: map[string]*dynamodb.AttributeValue{
			":userID":        {S: aws.String(request.UserID)},
			":exchTradeType": {S: aws.String(common.ExchCode + "_" + common.TradeTypeCd)},
		},
		ProjectionExpression: aws.String("UserID, Exch_TradeType_CapRisk_TradePair"),
	}

	result, err := svc.Query(input)
	if err != nil {
		return err
	}

	// Delete all fetched items
	for _, item := range result.Items {
		deleteInput := &dynamodb.DeleteItemInput{
			TableName: aws.String(common.UserCapRiskTableName),
			Key: map[string]*dynamodb.AttributeValue{
				"UserID":                           item["UserID"],
				"Exch_TradeType_CapRisk_TradePair": item["Exch_TradeType_CapRisk_TradePair"],
			},
		}
		_, err = svc.DeleteItem(deleteInput)
		if err != nil {
			return err
		}
	}
	return nil
}

func filterAndSortTradePairs(pairs []common.TradePair, capRisk string) []common.TradePair {
	var filteredPairs []common.TradePair

	// Filter
	for _, pair := range pairs {
		if pair.CapitalRiskCode == capRisk {
			filteredPairs = append(filteredPairs, pair)
		}
	}

	// Sort by priority
	sort.Slice(filteredPairs, func(i, j int) bool {
		pi, err1 := strconv.Atoi(filteredPairs[i].Priority)
		pj, err2 := strconv.Atoi(filteredPairs[j].Priority)
		if err1 != nil || err2 != nil {
			log.Fatal("Priority conversion error:", err1, err2)
		}
		return pi < pj
	})

	return filteredPairs
}

func putItemIntoDynamoDB(svc *dynamodb.DynamoDB, req Request, pair common.TradePair, allocVol float64) {
	exchTradeTypeCapRiskTradePair := fmt.Sprintf("%s_%s_%s_%s", common.ExchCode, common.TradeTypeCd, req.CapRisk, pair.TradePair)

	item := map[string]*dynamodb.AttributeValue{
		"UserID": {
			S: aws.String(req.UserID),
		},
		"Exch_TradeType_CapRisk_TradePair": {
			S: aws.String(exchTradeTypeCapRiskTradePair),
		},
		"Exch_TradeType": {
			S: aws.String(common.ExchCode + "_" + common.TradeTypeCd),
		},
		"CapRisk_TradePair": {
			S: aws.String(req.CapRisk + "_" + pair.TradePair),
		},
		"TradePair": {
			S: aws.String(pair.TradePair),
		},
		"Alloc_Volume": {
			N: aws.String(fmt.Sprintf("%f", allocVol)),
		},
		"IsActive": {
			S: aws.String("true"),
		},
		"CreationDate": {
			S: aws.String(time.Now().UTC().Format(time.RFC3339)),
		},
	}

	input := &dynamodb.PutItemInput{
		Item:      item,
		TableName: aws.String(common.UserCapRiskTableName),
	}

	_, err := svc.PutItem(input)
	if err != nil {
		log.Printf("Failed to put item into DynamoDB: %s", err)
	}
}

func main() {
	lambda.Start(Handler)
}
