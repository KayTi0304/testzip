package main

import (
	"context"
	"fmt"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"
)

type Request struct {
	Intervals []string `json:"intervals"`
}

func Handler(ctx context.Context, request Request) (common.Response, error) {
	err := common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    []interface{}{},
		}, nil
	}
	var intervals []string
	if len(request.Intervals) > 0 {
		intervals = request.Intervals
	} else {
		intervals = common.GetAllIntervals()
	}
	common.SendToDiscord(common.BotStatusDisc, fmt.Sprintf("[FuturesInitiator-%s-%s] Trade bot is awake.", common.ExchName, common.TradeTypeNm))
	tradePairs, err := common.FetchActiveTradePairs(common.ExchCode, common.TradeTypeCd, intervals)
	if err != nil {
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    []interface{}{},
		}, nil
	}

	return common.Response{
		Code:    200,
		Message: "Active trade pairs retrieved successfully",
		Data:    tradePairs,
	}, nil
}

func main() {
	lambda.Start(Handler)
}
