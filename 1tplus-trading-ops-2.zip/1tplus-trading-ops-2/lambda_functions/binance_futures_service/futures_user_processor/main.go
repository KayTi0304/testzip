package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"time"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbiface"
)

var db *dynamodb.DynamoDB

func init() {
	sess := session.Must(session.NewSession())
	db = dynamodb.New(sess)
}

func createTTL(hours int) int64 {
	return time.Now().Add(time.Hour * time.Duration(hours)).Unix()
}

func putItemsToSignalTable(db dynamodbiface.DynamoDBAPI, record common.UserExchTradeTypeCapRisk, order common.BinanceFuturesOrder, isTrend string) error {
	orderSignalJSON, err := json.Marshal(order)
	if err != nil {
		return err
	}
	userIDDateTime := fmt.Sprintf("%s_%s", record.UserID, time.Now().UTC().Format("20060102150405000"))

	// Construct the item to put into DynamoDB
	item := map[string]*dynamodb.AttributeValue{
		"UserID_UTCDateTime":               {S: aws.String(userIDDateTime)},
		"UserID":                           {S: aws.String(order.UserID)},
		"Exch_TradeType_CapRisk_TradePair": {S: aws.String(order.ExchangeTradeTypeCapRiskTradePair)},
		"Exch_TradeType":                   {S: aws.String(record.ExchTradeType)},
		"OrderSignal":                      {S: aws.String(string(orderSignalJSON))},
		"IsTrend":                          {S: aws.String(isTrend)},
		"TTL":                              {N: aws.String(fmt.Sprintf("%d", createTTL(168)))},
		"CreationDate":                     {S: aws.String(time.Now().UTC().Format(time.RFC3339))},
	}

	input := &dynamodb.PutItemInput{
		TableName: aws.String(common.UserOrderSignalTableName),
		Item:      item,
	}

	_, err = db.PutItem(input)
	if err != nil {
		return err
	}
	return nil
}

func process4Trend(db dynamodbiface.DynamoDBAPI, records []common.UserExchTradeTypeCapRisk, order common.BinanceFuturesOrder) error {

	leverage, err := strconv.Atoi(order.Leverage)
	if err != nil {
		return fmt.Errorf("error converting order.Leverage to int: %v", err)
	}
	quantityPrecision, err := strconv.Atoi(order.QuantityPrecision)
	if err != nil {
		return fmt.Errorf("error converting order.QuantityPrecision to int: %v", err)
	}
	pricePrecision, err := strconv.Atoi(order.PricePrecision)
	if err != nil {
		return fmt.Errorf("error converting order.PricePrecision to int: %v", err)
	}
	investVolPercent, err := strconv.ParseFloat(order.InvestVolPercent, 64)
	if err != nil {
		return fmt.Errorf("error converting order.InvestVolPercent to float64: %v", err)
	}
	entryPrice, err := strconv.ParseFloat(order.EntryPrice, 64)
	if err != nil {
		return fmt.Errorf("error converting order.EntryPrice to float64: %v", err)
	}
	actualLossMultiple, err := strconv.ParseFloat(order.ActualLossLimit, 64)
	if err != nil {
		return fmt.Errorf("error converting order.ActualLossLimit to float64: %v", err)
	}

	for _, record := range records {
		order.UserID = record.UserID
		investCapitalVol := investVolPercent * record.AllocVolume * float64(leverage)
		order.InvestCapitalVol = strconv.FormatFloat(investCapitalVol, 'f', pricePrecision, 64)

		quantity := investCapitalVol / entryPrice
		order.Quantity = strconv.FormatFloat(quantity, 'f', quantityPrecision, 64)

		actualLossLimit := investVolPercent * record.AllocVolume * actualLossMultiple
		order.ActualLossLimit = strconv.FormatFloat(actualLossLimit, 'f', pricePrecision, 64)

		err = putItemsToSignalTable(db, record, order, common.True)
		if err != nil {
			return err
		}
	}
	return nil
}

func process4ClearanceNUpdateSL(db dynamodbiface.DynamoDBAPI, records []common.UserExchTradeTypeCapRisk, order common.BinanceFuturesOrder) error {
	pricePrecision, err := strconv.Atoi(order.PricePrecision)
	if err != nil {
		return fmt.Errorf("error converting order.PricePrecision to int: %v", err)
	}
	investVolPercent, err := strconv.ParseFloat(order.InvestVolPercent, 64)
	if err != nil {
		return fmt.Errorf("error converting order.InvestVolPercent to float64: %v", err)
	}
	actualLossMultiple, err := strconv.ParseFloat(order.ActualLossLimit, 64)
	if err != nil {
		return fmt.Errorf("error converting order.ActualLossLimit to float64: %v", err)
	}
	for _, record := range records {
		order.UserID = record.UserID

		actualLossLimit := investVolPercent * record.AllocVolume * actualLossMultiple
		order.ActualLossLimit = strconv.FormatFloat(actualLossLimit, 'f', pricePrecision, 64)

		err := putItemsToSignalTable(db, record, order, common.False)
		if err != nil {
			return err
		}
	}
	return nil
}

func processOrder(db dynamodbiface.DynamoDBAPI, records []common.UserExchTradeTypeCapRisk, order common.BinanceFuturesOrder) error {
	if order.Side != "" && order.EntryPrice != "" && order.TakeProfitPrice != "" {
		return process4Trend(db, records, order)
	} else {
		return process4ClearanceNUpdateSL(db, records, order)
	}
}

func Handler(ctx context.Context, request map[string]interface{}) (common.Response, error) {

	log.Printf("request: %+v", request)
	var signalProcessStat int
	err := common.GetNestedDataAndUnmarshal(request, []string{"Payload", "code"}, &signalProcessStat)
	if err != nil {
		discMsg := fmt.Sprintf("[FuturesUserProcessor] Failed to get nested data status code: %v", err)
		common.DiscordSendMsg(common.DISC_UR_ID, common.DISC_UR_TOKEN, discMsg)
		return common.Response{
			Code:    400,
			Message: "Failed to process status code: " + err.Error(),
			Data:    common.BinanceFuturesOrder{},
		}, nil
	}
	if signalProcessStat != 200 {
		discMsg := fmt.Sprintf("[FuturesUserProcessor] Signal data status: %d", signalProcessStat)
		common.DiscordSendMsg(common.DISC_UR_ID, common.DISC_UR_TOKEN, discMsg)
		return common.Response{
			Code:    400,
			Message: "Trade Process has been held",
			Data:    map[string]int{"ReceivedStatusCode": signalProcessStat}, // Providing context to the client
		}, nil
	}

	var order common.BinanceFuturesOrder
	err = common.GetNestedDataAndUnmarshal(request, []string{"Payload", "data"}, &order)
	if err != nil {
		discMsg := fmt.Sprintf("[FuturesUserProcessor] Failed to get nested data: %v", err)
		common.DiscordSendMsg(common.DISC_UR_ID, common.DISC_UR_TOKEN, discMsg)
		return common.Response{
			Code:    400,
			Message: "Failed to process request: " + err.Error(),
			Data:    common.BinanceFuturesOrder{},
		}, nil
	}

	// Log the extracted order
	log.Printf("Order: %+v", order)

	err = common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		discMsg := fmt.Sprintf("[FuturesUserProcessor-%s] Webhook config error occurred: %s", order.ExchangeTradeTypeCapRiskTradePair, common.DISC_URGENT_MSG)
		common.DiscordSendMsg(common.DISC_UR_ID, common.DISC_UR_TOKEN, discMsg)
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    common.BinanceFuturesOrder{},
		}, nil
	}

	// Retrieve active records based on Exch_TradeType_CapRisk_TradePair
	capRiskItem := order.ExchangeTradeTypeCapRiskTradePair
	activeRecords, err := common.GetUserActiveCapRiskByTradePair(db, capRiskItem)

	if err != nil {
		discMsg := fmt.Sprintf("[FuturesUserProcessor-%s] Failed to get user capital risks: %v", order.ExchangeTradeTypeCapRiskTradePair, err)
		common.Log4Trace(err, common.ErrorAlertDisc, discMsg)
		return common.Response{
			Code:    500,
			Message: "Failed to retrieve active records: " + err.Error(),
			Data:    nil,
		}, nil
	}

	if err := processOrder(db, activeRecords, order); err != nil {
		discMsg := fmt.Sprintf("[FuturesUserProcessor-%s] Failed to process order: %v", order.ExchangeTradeTypeCapRiskTradePair, err)
		common.Log4Trace(err, common.ErrorAlertDisc, discMsg)
		return common.Response{
			Code:    500,
			Message: "Failed to process analyzed order: " + err.Error(),
			Data:    nil,
		}, nil
	}

	return common.Response{
		Code:    200,
		Message: "Request processed successfully",
		Data:    activeRecords, // Return the order struct
	}, nil
}

func main() {
	lambda.Start(Handler)
}
