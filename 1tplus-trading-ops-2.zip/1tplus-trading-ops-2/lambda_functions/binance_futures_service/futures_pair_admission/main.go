package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"time"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/s3"
)

type TradePair struct {
	ExchangeCode      string `json:"exchange_code"`
	TradeTypeCode     string `json:"trade_type_code"`
	CapitalRiskCode   string `json:"capital_risk_code"`
	TradePair         string `json:"trade_pair"`
	Interval          string `json:"interval"`
	ReqCapVol         string `json:"req_cap_vol"`
	Priority          string `json:"priority"`
	AlgorithmFunction string `json:"algorithm_function"`
	FunctionArgument  string `json:"function_argument"`
}

type Request struct {
	TradePairs []TradePair `json:"trade_pairs"`
}

func fetchRequestFromS3(bucket, key string) (Request, error) {
	sess := session.Must(session.NewSession())
	svc := s3.New(sess)

	input := &s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(key),
	}

	result, err := svc.GetObject(input)
	if err != nil {
		return Request{}, err
	}
	defer result.Body.Close()

	body, err := io.ReadAll(result.Body)
	if err != nil {
		return Request{}, err
	}

	var request Request
	err = json.Unmarshal(body, &request)
	if err != nil {
		return Request{}, err
	}

	return request, nil
}

func Handler(ctx context.Context, request Request) (common.Response, error) {
	// bucket := "your-s3-bucket-name"
	key := fmt.Sprintf("trading-ops/%s/%s/trading-pairs.json", common.ExchName, common.TradeTypeNm)

	// Fetch request from S3
	request, err := fetchRequestFromS3(common.IntResBucketName, key)
	if err != nil {
		return common.Response{
			Code:    500,
			Message: "Failed to fetch request from S3",
			Data:    err.Error(),
		}, nil
	}
	log.Println(request)
	// Initialize DynamoDB client
	sess := session.Must(session.NewSession())
	svc := dynamodb.New(sess)

	for _, item := range request.TradePairs {
		// Construct item to be inserted
		dynamodbItem := map[string]*dynamodb.AttributeValue{
			"Exch_TradeType_CapRisk_TradePair": {
				S: aws.String(common.ExchCode + "_" + common.TradeTypeCd + "_" + item.CapitalRiskCode + "_" + item.TradePair),
			},
			"Exch_TradeType": {
				S: aws.String(common.ExchCode + "_" + common.TradeTypeCd),
			},
			"Exch": {
				S: aws.String(common.ExchCode),
			},
			"TradeType": {
				S: aws.String(common.TradeTypeCd),
			},
			"Interval": {
				S: aws.String(item.Interval),
			},
			"CapRisk": {
				S: aws.String(item.CapitalRiskCode),
			},
			"TradePair": {
				S: aws.String(item.TradePair),
			},
			"ReqCapVol": {
				S: aws.String(item.ReqCapVol),
			},
			"Priority": {
				S: aws.String(item.Priority),
			},
			"AlgorithmFunction": {
				S: aws.String(item.AlgorithmFunction),
			},
			"FunctionArguments": {
				S: aws.String(item.FunctionArgument),
			},
			"IsActive": {
				S: aws.String(common.True),
			},
			"IsPaused": {
				S: aws.String(common.False),
			},
			"CreationDate": {
				S: aws.String(time.Now().UTC().Format(time.RFC3339)),
			},
		}

		// Insert item into DynamoDB table
		input := &dynamodb.PutItemInput{
			Item:      dynamodbItem,
			TableName: aws.String(common.TradePairTableName),
		}

		_, err := svc.PutItem(input)
		if err != nil {
			return common.Response{
				Code:    500,
				Message: "Failed to insert item into DynamoDB",
				Data:    err.Error(),
			}, nil
		}
	}

	return common.Response{
		Code:    200,
		Message: "Items inserted successfully",
		Data:    nil,
	}, nil
}

func main() {
	lambda.Start(Handler)
}
