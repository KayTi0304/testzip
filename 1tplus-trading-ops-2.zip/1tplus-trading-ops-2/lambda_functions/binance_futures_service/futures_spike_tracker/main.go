package main

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"time"
	"trading-ops/common"

	"github.com/adshao/go-binance/v2/futures"
	"github.com/aws/aws-lambda-go/lambda"
)

type Request struct {
	request string `json:"request"`
}

var (
	prevDaysFromNow       = 1
	defSpikeVolMultiplier = 10.0
	comparePeriod         = 240
)

func isLastKlineVolumeHigh(client *futures.Client, symbol, interval string) (bool, string, error) {
	klines, err := common.FetchKlinesWithRetry(client, symbol, interval, prevDaysFromNow)
	if err != nil {
		return false, "", err
	}
	if len(klines) > 0 {
		klines = klines[:len(klines)-1]
	} else {
		return false, "", fmt.Errorf("no data available in klines to remove")
	}

	if len(klines) < (comparePeriod + 1) {
		return false, "", fmt.Errorf("not enough klines to calculate the average volume")
	}

	// Calculate the average volume of the last 240 klines
	var totalVolume float64
	for i := len(klines) - (comparePeriod + 1); i < len(klines)-1; i++ {
		volume, err := strconv.ParseFloat(klines[i].Volume, 64)
		if err != nil {
			return false, "", fmt.Errorf("error parsing volume: %v", err)
		}
		totalVolume += volume

	}
	log.Printf("%s\nTotal Volume among %d: %.1f", symbol, comparePeriod, totalVolume)
	averageVolume := totalVolume / float64(comparePeriod)
	log.Printf("%s\nAverage Volume among %d: %.1f", symbol, comparePeriod, averageVolume)

	// Get the volume of the last kline
	lastKlineVolume, err := strconv.ParseFloat(klines[len(klines)-1].Volume, 64)
	if err != nil {
		return false, "", fmt.Errorf("error parsing last kline volume: %v", err)
	}
	log.Printf("%s\nLast kline volume among %d: %.1f", symbol, comparePeriod, lastKlineVolume)
	isHighVolume := lastKlineVolume >= defSpikeVolMultiplier*averageVolume

	lastKlineCloseTime := klines[len(klines)-1].CloseTime
	lastKlineCloseTimeTime := time.Unix(0, lastKlineCloseTime*int64(time.Millisecond))
	adjustedTime := lastKlineCloseTimeTime.Add(8*time.Hour + 1*time.Second)
	lastKlineCloseTimeString := adjustedTime.Format("2006-01-02 15:04:05")
	msg := fmt.Sprintf("%s (%s)\nTotal Volume among %d minutes: %.1f\nAverage Volume among %d minutes: %.1f\nLast kline volume: %.1f", symbol, lastKlineCloseTimeString, comparePeriod, totalVolume, comparePeriod, averageVolume, lastKlineVolume)

	return isHighVolume, msg, nil
}

func groupByTradePair(tradePairs []common.TradePair) map[string][]common.TradePair {
	grouped := make(map[string][]common.TradePair)
	for _, tradePair := range tradePairs {
		key := tradePair.TradePair
		grouped[key] = append(grouped[key], tradePair)
	}
	return grouped
}

func log4Rec(msg string) {
	common.Log4Trace(nil, common.BotUndergroundDisc, msg)
	log.Print(msg)
}

func Handler(ctx context.Context, request Request) (common.Response, error) {
	err := common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		log4Rec(fmt.Sprintf("[FuturesSpikeTracker] Having trouble with discord - %s", err))
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}
	// secret, err := common.GetHostApiSecret()
	// if err != nil {
	// 	log4Rec(fmt.Sprintf("[FuturesSpikeTracker] Having trouble of getting host api - %s", err))
	// 	return common.Response{
	// 		Code:    500,
	// 		Message: err.Error(),
	// 		Data:    nil,
	// 	}, nil
	// }
	client := futures.NewClient("cFiTqhslaQTjOshIJKbrD1brXSKU8NOCOVLYRwPrSl9DpnE2VRPUL0HDsjEwguuW", "qWOdF5PY0k5L1KyMcTqYeY9h7iDQ9GGIHhnjAbyrTwNko5ahLnDoJaBGUFZX8d9n")
	intervals := common.GetAllIntervals()
	tradePairs, err := common.FetchActiveTradePairs(common.ExchCode, common.TradeTypeCd, intervals)
	if err != nil {
		log4Rec(fmt.Sprintf("[FuturesSpikeTracker] Error occurred during fetching trade pairs: %+v", err))
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}
	var actualTradePairs []common.TradePair
	for _, tradePair := range tradePairs {
		if !common.ContainsStr(common.PbCapRisks, tradePair.CapitalRiskCode) {
			continue
		}
		actualTradePairs = append(actualTradePairs, tradePair)
	}

	groupedTradePairs := groupByTradePair(actualTradePairs)
	for symbol, group := range groupedTradePairs {
		// if symbol != "BTCUSDT" {
		// 	continue
		// }
		isVolumeSpike, msg, err := isLastKlineVolumeHigh(client, symbol, "1m")
		if err != nil {
			log4Rec(fmt.Sprintf("[FuturesSpikeTracker] Error occurred during fetching trade pairs: %+v", err))
			return common.Response{
				Code:    500,
				Message: err.Error(),
				Data:    nil,
			}, nil
		}

		// log4Rec(msg)
		if isVolumeSpike {
			log4Rec(msg)
			for _, groupPair := range group {
				discMsg := fmt.Sprintf("Pausing %s", common.RenameCR4Display(groupPair.ExchangeTradeTypeCapRiskTradePair))
				common.Log4Trace(err, common.BotUndergroundDisc, discMsg)
				// log4Rec(fmt.Sprintf("Pausing %s", groupPair.ExchangeTradeTypeCapRiskTradePair))
			}
		}
	}

	return common.Response{
		Code:    200,
		Message: "Request successfully",
		Data:    nil,
	}, nil
}

func main() {
	lambda.Start(Handler)
	// if _, exists := os.LookupEnv("_LAMBDA_SERVER_PORT"); exists {
	// 	lambda.Start(Handler)
	// } else {
	// 	// Running locally
	// 	var req Request
	// 	result, err := Handler(context.Background(), req)
	// 	if err != nil {
	// 		log.Fatalf("Error: %v", err)
	// 	} else {
	// 		fmt.Println("Result:", result)
	// 	}
	// }
}
