package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"strconv"
	"trading-ops/algorithm"
	"trading-ops/common"

	"github.com/aws/aws-lambda-go/lambda"

	"github.com/adshao/go-binance/v2/futures"
)

type HaThreeSptArg struct {
	Multiplier21       string `json:"multiplier21"`
	Multiplier14       string `json:"multiplier14"`
	Multiplier10       string `json:"multiplier10"`
	Leverage           string `json:"leverage"`
	InvestVolPercent   string `json:"investVolPercent"`
	TakeProfitPercent  string `json:"takeProfitPercent"`
	ActualLossMultiple string `json:"actualLossMultiple"`
}

var prevDaysFromNow = 31

type ConditionFunc func(float64) bool

func checkLastBuySell(slices []float64, condition ConditionFunc) bool {
	if len(slices) == 0 {
		return false
	}
	lastElement := slices[len(slices)-1]
	return condition(lastElement)
}

func getActualLeverage(client *futures.Client, symbol, leverage string) (string, error) {
	if leverage == "-1" {
		maxLeverage, err := common.GetMaxLeverage(client, symbol)
		if err != nil {
			return "", err
		}
		return strconv.Itoa(maxLeverage), nil
	}
	return leverage, nil
}

func processByHaThreeSptrend(request common.TradePair, client *futures.Client, stoplossNoLine int, version int) (common.BinanceFuturesOrder, error) {
	var bnbFutOrder = common.BinanceFuturesOrder{
		UserID:                            "",
		ExchangeTradeTypeCapRiskTradePair: "",
		Side:                              "",
		Interval:                          "",
		Symbol:                            "",
		Quantity:                          "",
		InvestVolPercent:                  "",
		InvestCapitalVol:                  "",
		Leverage:                          "",
		EntryPrice:                        "",
		StopLossPrice:                     "",
		TakeProfitPrice:                   "",
		QuantityPrecision:                 "",
		PricePrecision:                    "",
		ActualLossLimit:                   common.DEF_ACT_LOSS_MUL,
	}
	bnbFutOrder.Symbol = request.TradePair
	bnbFutOrder.Interval = request.Interval
	var functionArgs HaThreeSptArg
	err := json.Unmarshal([]byte(request.FunctionArguments), &functionArgs)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error parsing FunctionArguments for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	if functionArgs.ActualLossMultiple != "" && common.IsFloat(functionArgs.ActualLossMultiple) {
		bnbFutOrder.ActualLossLimit = functionArgs.ActualLossMultiple
	}

	actualLeverage, err := getActualLeverage(client, request.TradePair, functionArgs.Leverage)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error during getActualLeverage for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	bnbFutOrder.Leverage = actualLeverage
	bnbFutOrder.InvestVolPercent = functionArgs.InvestVolPercent
	klines, err := common.FetchKlinesWithRetry(client, request.TradePair, request.Interval, prevDaysFromNow)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error fetching data for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}

	if len(klines) > 0 {
		klines = klines[:len(klines)-1]
	} else {
		return bnbFutOrder, fmt.Errorf("no data available in klines to be removed[-1] for %s on interval %s", request.TradePair, request.Interval)
	}
	multiplier21, err := strconv.ParseFloat(functionArgs.Multiplier21, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting Multiplier21 to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	multiplier14, err := strconv.ParseFloat(functionArgs.Multiplier14, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting Multiplier14 to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	multiplier10, err := strconv.ParseFloat(functionArgs.Multiplier10, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting Multiplier10 to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}

	var resultData algorithm.ResultData
	if version == 2 {
		resultData = algorithm.HaThreeSupertrendsV2(klines, multiplier21, multiplier14, multiplier10, 21, 14, 10, stoplossNoLine)
	} else if version == 6 {
		resultData = algorithm.HaThreeSupertrendsV6(klines, multiplier21, multiplier14, multiplier10, 21, 14, 10, stoplossNoLine)
	} else if version == 100 {
		resultData = algorithm.TrendsICT(klines, 18, 14, 35, 2, 4, 15, 15)
	} else if version == 10001 {
		resultData = algorithm.HaThreeSupertrendsV3(klines, multiplier21, multiplier14, multiplier10, 21, 14, 10, stoplossNoLine)
	} else {
		resultData = algorithm.HaThreeSupertrends(klines, multiplier21, multiplier14, multiplier10, 21, 14, 10, stoplossNoLine)
	}

	condition := func(value float64) bool {
		return value > 0 && !math.IsNaN(value)
	}

	stopLossPrice := resultData.StopLoss[len(resultData.StopLoss)-1]
	// stopLossPrice = common.GetAdjustedPrice(client, stopLossPrice, request.TradePair)
	leverage, err := strconv.Atoi(bnbFutOrder.Leverage)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting Leverage to int for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	takeProfitPercent, err := strconv.ParseFloat(functionArgs.TakeProfitPercent, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting TakeProfitPercent to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	reqCapVol, err := strconv.ParseFloat(request.ReqCapVol, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting ReqCapVol to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	investVolPercent, err := strconv.ParseFloat(functionArgs.InvestVolPercent, 64)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error converting InvestVolPercent to float64 for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	pricePrecision, quantityPrecision, err := common.GetPriceQuantityPrecision(client, request.TradePair)
	if err != nil {
		return bnbFutOrder, fmt.Errorf("error to get precision for %s on interval %s: %v", request.TradePair, request.Interval, err)
	}
	bnbFutOrder.StopLossPrice = strconv.FormatFloat(stopLossPrice, 'f', pricePrecision, 64)
	bnbFutOrder.PricePrecision = strconv.Itoa(pricePrecision)
	bnbFutOrder.QuantityPrecision = strconv.Itoa(quantityPrecision)
	bnbFutOrder.ExchangeTradeTypeCapRiskTradePair = request.ExchangeTradeTypeCapRiskTradePair

	// No trade during paused period
	if request.IsPaused == common.True {
		return bnbFutOrder, nil
	}

	if checkLastBuySell(resultData.BUY, condition) {
		entryPrice := resultData.BUY[len(resultData.BUY)-1]
		entryPrice, err = common.GetAdjustedPrice(client, entryPrice, request.TradePair)
		if err != nil {
			return bnbFutOrder, fmt.Errorf("failed to get adjusted price for %s on interval %s: %v", request.TradePair, request.Interval, err)
		}

		cost := investVolPercent * reqCapVol
		takeProfitPrice := algorithm.CalLastPriceFrmROE(entryPrice, cost, leverage, true, takeProfitPercent)

		bnbFutOrder.Side = common.BUY
		bnbFutOrder.EntryPrice = strconv.FormatFloat(entryPrice, 'f', pricePrecision, 64)
		bnbFutOrder.TakeProfitPrice = strconv.FormatFloat(takeProfitPrice, 'f', pricePrecision, 64)
	}

	if checkLastBuySell(resultData.SELL, condition) {
		entryPrice := resultData.SELL[len(resultData.SELL)-1]
		entryPrice, err = common.GetAdjustedPrice(client, entryPrice, request.TradePair)
		if err != nil {
			return bnbFutOrder, fmt.Errorf("failed to get adjusted price for %s on interval %s: %v", request.TradePair, request.Interval, err)
		}

		cost := investVolPercent * reqCapVol
		takeProfitPrice := algorithm.CalLastPriceFrmROE(entryPrice, cost, leverage, false, takeProfitPercent)

		bnbFutOrder.Side = common.SELL
		bnbFutOrder.EntryPrice = strconv.FormatFloat(entryPrice, 'f', pricePrecision, 64)
		bnbFutOrder.TakeProfitPrice = strconv.FormatFloat(takeProfitPrice, 'f', pricePrecision, 64)
	}

	return bnbFutOrder, nil
}

func Handler(ctx context.Context, request common.TradePair) (common.Response, error) {
	var order common.BinanceFuturesOrder
	err := common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		discMsg := fmt.Sprintf("[FuturesSignalProcessor-%s] Webhook config error occurred: %s", request.ExchangeTradeTypeCapRiskTradePair, common.DISC_URGENT_MSG)
		common.DiscordSendMsg(common.DISC_UR_ID, common.DISC_UR_TOKEN, discMsg)
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}
	secret, err := common.GetHostApiSecret()
	if err != nil {
		discMsg := fmt.Sprintf("[FuturesSignalProcessor-%s] Host api secret error occurred: %v", request.ExchangeTradeTypeCapRiskTradePair, err.Error())
		common.Log4Trace(err, common.ErrorAlertDisc, discMsg)
		return common.Response{
			Code:    400,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}
	// client := binance.NewFuturesClient(secret.APIKey, secret.SecretKey)
	client := futures.NewClient(secret.APIKey, secret.SecretKey)

	if common.ContainsStr(common.PbCapRisks, request.CapitalRiskCode) {
		statMsg := "Running"
		if request.IsPaused == common.True {
			statMsg = "Paused"
		}
		common.SendToDiscord(common.BotStatusDisc, fmt.Sprintf("[FuturesSignalProcessor-%s]\nAlgo - %s\nStatus - %s", common.RenameCR4Display(request.ExchangeTradeTypeCapRiskTradePair), request.AlgorithmFunction, statMsg))
	}

	if request.AlgorithmFunction == common.ALGO_ST0 {
		order, err = processByHaThreeSptrend(request, client, 2, 1)
	} else if request.AlgorithmFunction == common.ALGO_ST1 {
		order, err = processByHaThreeSptrend(request, client, 3, 1)
	} else if request.AlgorithmFunction == common.ALGO_ST1_PLUS {
		order, err = processByHaThreeSptrend(request, client, 3, 10001)
	} else if request.AlgorithmFunction == common.ALGO_ST2 {
		order, err = processByHaThreeSptrend(request, client, 3, 2)
	} else if request.AlgorithmFunction == common.ALGO_ST6 {
		order, err = processByHaThreeSptrend(request, client, 3, 6)
	} else if request.AlgorithmFunction == common.ALGO_ICT0 {
		order, err = processByHaThreeSptrend(request, client, 3, 100)
	} else {
		err = fmt.Errorf("found no algo")
	}

	if err != nil {
		discMsg := fmt.Sprintf("[FuturesSignalProcessor-%s] Process algo error occurred: %v", request.ExchangeTradeTypeCapRiskTradePair, err.Error())
		common.Log4Trace(err, common.ErrorAlertDisc, discMsg)
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}

	// if order.EntryPrice != "" {
	// 	common.SendToDiscord(common.BotStatusDisc, fmt.Sprintf("[FuturesSignalProcessor-%s] %s is doing %s with ENTRY %s, TAKE PROFIT %s, and STOP LOSS %s.", request.ExchangeTradeTypeCapRiskTradePair, order.Symbol, order.Side, order.EntryPrice, order.TakeProfitPrice, order.StopLossPrice))
	// } else {
	// 	common.SendToDiscord(common.BotStatusDisc, fmt.Sprintf("[FuturesSignalProcessor-%s] %s has no action yet.", request.ExchangeTradeTypeCapRiskTradePair, order.Symbol))
	// }

	return common.Response{
		Code:    200,
		Message: "Algo process is been handled successfully",
		Data:    order,
	}, nil
}

func main() {
	lambda.Start(Handler)
}
