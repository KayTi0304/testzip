package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strconv"

	"trading-ops/common"

	futures "github.com/adshao/go-binance/v2/futures"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/kms"
)

type DynamoDBStreamHandler struct{}

const timeLimitMinutes = 4

var dynamodbClient *dynamodb.DynamoDB
var kmsClient *kms.KMS

func init() {
	sess := session.Must(session.NewSession())
	dynamodbClient = dynamodb.New(sess)
	kmsClient = kms.New(sess)
}

func createFuturesOrderPosition(client *futures.Client, order common.BinanceFuturesOrder) error {
	side := futures.SideTypeBuy
	stopMartSide := futures.SideTypeSell
	if order.Side == common.SELL {
		side = futures.SideTypeSell
		stopMartSide = futures.SideTypeBuy
	}

	err := common.SetFuturesLeverage4Symbol(client, order)
	if err != nil {
		return err
	}
	discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s] Leverage set for %s: %sx", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, order.Leverage)
	common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

	_, err = common.CreateMartStopLoss(client, order, stopMartSide)
	if err != nil {
		return err
	}
	discMsg = fmt.Sprintf("[FuturesUserTrade-%s-%s] Market stop loss order placed for %s with side %s\nStop Loss: %s", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, string(stopMartSide), order.StopLossPrice)
	common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

	_, err = common.CreateMartTakeProfit(client, order, stopMartSide)
	if err != nil {
		err2 := common.ClearFuturesOrders(client, order.Symbol)
		if err2 != nil {
			return fmt.Errorf("[DUAL ERROR] failed to create TP order and clear %s created order due to\n Error 1: %v\nError 2: %v", order.Symbol, err, err2)
		}
		return err
	}
	discMsg = fmt.Sprintf("[FuturesUserTrade-%s-%s] Market take profit order placed for %s with side %s\nTake Profit: %s", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, string(stopMartSide), order.TakeProfitPrice)
	common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

	_, err = common.CreatePosLimitOrder(client, order, side)
	if err != nil {
		err2 := common.ClearFuturesOrders(client, order.Symbol)
		if err2 != nil {
			return fmt.Errorf("[DUAL ERROR] failed to create trade limit order and clear %s created order due to\n Error 1: %v\nError 2: %v", order.Symbol, err, err2)
		}
		return err
	}
	discMsg = fmt.Sprintf("[FuturesUserTrade-%s-%s] Limit order placed for %s with side %s\nEntry: %s\nQuantity: %s", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, order.Side, order.EntryPrice, order.Quantity)
	common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

	return nil
}

func processFuturesTrend(client *futures.Client, order common.BinanceFuturesOrder) error {
	open, positionRisk, err := common.IsPositionOpen(client, order.Symbol)
	if err != nil {
		return fmt.Errorf("[processFuturesOrderPosition] Failed to check position: %v", err)
	}

	if open {
		currentPosSide, _, err := common.GetPositionInfo(positionRisk)
		if err != nil {
			return fmt.Errorf("[processFuturesOrderPosition] Failed to get position side: %v", err)
		}
		log.Printf("Position for %s is open in %s side.\n", positionRisk.Symbol, currentPosSide)

		if order.Side != currentPosSide {
			err = common.CloseFutPosition(client, positionRisk, currentPosSide)
			if err != nil {
				return fmt.Errorf("[processFuturesOrderPosition] Failed to close futures position: %v", err)
			}
			discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s] Position closed successfully for: %v", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol)
			common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

			err = common.ClearFuturesOrders(client, order.Symbol)
			if err != nil {
				return fmt.Errorf("[processFuturesTrend] Failed to clear futures orders: %v", err)
			}
			return createFuturesOrderPosition(client, order)
		} else {
			// err = common.UpdateStopMarketOrder(client, positionRisk.Symbol, stopLossPrice)
			// if err != nil {
			// 	return fmt.Errorf("[processFuturesOrderPosition] Failed to update stop market order: %v", err)
			// }
			// discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][processFuturesOrderPosition] Stop market order updated successfully for %v\nStop Loss: %s", order.ExchangeTradeTypeCapRiskTradePair, order.UserID, order.Symbol, order.StopLossPrice)
			// common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)
			err = common.UpdateMartStopOrder4Pos(client, positionRisk, order)
			if err != nil {
				return fmt.Errorf("[processFuturesSlNCancel] Failed to update stop order: %v", err)
			}
			discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][processFuturesSlNCancel] Stop order updated successfully for %s\nStop Loss: %s", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, order.StopLossPrice)
			common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)
		}
	} else {
		log.Printf("No open position for %s.\n", order.Symbol)
		err = common.ClearFuturesOrders(client, order.Symbol)
		if err != nil {
			return fmt.Errorf("[processFuturesTrend] Failed to clear futures orders: %v", err)
		}
		return createFuturesOrderPosition(client, order)
	}
	return nil
}

func cancelOlderThresholdOrders(client *futures.Client, bnbFutOrder common.BinanceFuturesOrder) error {
	openOrders, err := common.GetOpenOrders(client, bnbFutOrder.Symbol)
	if err != nil {
		return fmt.Errorf("[cancelOlderThresholdOrders] Failed to get opening orders: %v", err)
	}

	thresholdTime := common.GetThresholdMinutes(timeLimitMinutes)
	activeLimitOrderExists := false

	for _, order := range openOrders {
		orderTime := order.Time

		if order.Type == futures.OrderTypeLimit {
			discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][cancelOlderThresholdOrders] Catch a limit order for %s that is created at %d.", common.RenameCR4Display(bnbFutOrder.ExchangeTradeTypeCapRiskTradePair), bnbFutOrder.UserID, order.Symbol, orderTime)
			common.Log4Trace(nil, common.GetUserChannel(bnbFutOrder.UserID), discMsg)
		}
		if order.Type == futures.OrderTypeLimit && orderTime <= thresholdTime {
			if err := common.CancelOrder(client, order.Symbol, order.OrderID); err != nil {
				return fmt.Errorf("[cancelOlderThresholdOrders] Failed to cancel limit order of %s: %v", order.Symbol, err)
			}
			discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][cancelOlderThresholdOrders] Limit order for %s created at %d canceled.", common.RenameCR4Display(bnbFutOrder.ExchangeTradeTypeCapRiskTradePair), bnbFutOrder.UserID, order.Symbol, orderTime)
			common.Log4Trace(nil, common.GetUserChannel(bnbFutOrder.UserID), discMsg)

			break
		} else if order.Type == futures.OrderTypeLimit {
			activeLimitOrderExists = true
		}
	}

	if !activeLimitOrderExists && len(openOrders) > 0 {
		err = common.ClearFuturesOrders(client, bnbFutOrder.Symbol)
		if err != nil {
			return fmt.Errorf("[cancelOlderThresholdOrders] Failed to clear futures orders: %v", err)
		}
	}
	return nil
}

func quitIfHitActLoss(client *futures.Client, posRisk *futures.PositionRisk, order common.BinanceFuturesOrder) (bool, error) {
	log.Printf("Symbol: %s", posRisk.Symbol)
	log.Printf("UnRealizedProfit: %s", posRisk.UnRealizedProfit)

	currentPosSide, _, err := common.GetPositionInfo(posRisk)
	if err != nil {
		return false, fmt.Errorf("[quitIfHitActLoss] Failed to get position side: %v", err)
	}
	log.Printf("Position for %s is open in %s side.\n", posRisk.Symbol, currentPosSide)
	unRealizedProfit, err := strconv.ParseFloat(posRisk.UnRealizedProfit, 64)
	if err != nil {
		return false, fmt.Errorf("[quitIfHitActLoss] Invalid UnRealizedProfit: %s", posRisk.UnRealizedProfit)
	}

	orderLossLimit, err := strconv.ParseFloat(order.ActualLossLimit, 64)
	if err != nil {
		return false, fmt.Errorf("[quitIfHitActLoss] Error converting order.ActualLossLimit to float64: %v", err)
	}
	actLossLimit := orderLossLimit * -1
	// Default - common.DEF_ACT_LOSS_LIMIT
	if unRealizedProfit < actLossLimit {
		err = common.CloseFutPosition(client, posRisk, currentPosSide)
		if err != nil {
			return false, fmt.Errorf("[quitIfHitActLoss] Failed to close futures position: %v", err)
		}
		discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][quitIfHitActLoss] Position closed successfully for %v due to UnRealizedProfit %s < -20", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, posRisk.UnRealizedProfit)
		common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)

		err = common.ClearFuturesOrders(client, posRisk.Symbol)
		if err != nil {
			return true, fmt.Errorf("[quitIfHitActLoss] Failed to clear futures orders: %v", err)
		}

		return true, nil
	}

	return false, nil
}

func processFuturesSlNCancel(client *futures.Client, order common.BinanceFuturesOrder) error {
	open, positionRisk, err := common.IsPositionOpen(client, order.Symbol)
	if err != nil {
		return fmt.Errorf("[processFuturesSlNCancel] Failed to check position: %v", err)
	}

	if open {
		log.Printf("Position for %s is open in %s side.", positionRisk.Symbol, positionRisk.PositionSide)
		// Handle actual loss
		if common.CheckAnySubstringExistence(order.ExchangeTradeTypeCapRiskTradePair, common.PvCapRisks) {
			isClosed, err := quitIfHitActLoss(client, positionRisk, order)
			if err != nil {
				return fmt.Errorf("[processFuturesSlNCancel] Failed to quit the position: %v", err)
			}
			if isClosed {
				return nil
			}
		}
		if common.IsValidInterval(order.Interval) {
			err = common.UpdateMartStopOrder4Pos(client, positionRisk, order)
			if err != nil {
				return fmt.Errorf("[processFuturesSlNCancel] Failed to update stop order: %v", err)
			}
			discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][processFuturesSlNCancel] Stop order updated successfully for %s\nStop Loss: %s", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, order.Symbol, order.StopLossPrice)
			common.Log4Trace(nil, common.GetUserChannel(order.UserID), discMsg)
		}
	} else {
		return cancelOlderThresholdOrders(client, order)
	}
	return nil
}

func (h *DynamoDBStreamHandler) HandleRequest(ctx context.Context, e events.DynamoDBEvent) (common.Response, error) {
	err := common.LoadExchTradeTypeWebhookConfig()
	if err != nil {
		return common.Response{
			Code:    500,
			Message: err.Error(),
			Data:    nil,
		}, nil
	}
	for _, record := range e.Records {
		fmt.Printf("Processing request data for record ID %s \n", record.EventID)
		if record.EventName == "INSERT" {
			newImage := record.Change.NewImage

			orderSignal, ok := newImage["OrderSignal"]
			if !ok {
				log.Println("OrderSignal not found in the record")
				continue
			}
			var order common.BinanceFuturesOrder
			if err := json.Unmarshal([]byte(orderSignal.String()), &order); err != nil {
				return common.Response{
					Code:    500,
					Message: "Failed to unmarshal OrderSignal: " + err.Error(),
				}, nil
			}
			log.Printf("OrderSignal Data: %+v\n", order)

			isTrend, ok := newImage["IsTrend"]
			if !ok {
				log.Printf("[FuturesUserTrader4User-%s] IsTrend not found in the record", order.UserID)
				continue
			}
			isTrendStr := isTrend.String()
			log.Printf("IsTrend: %s", isTrendStr)

			apiKey, secretKey, err := common.GetAndDecryptAPIKeys(dynamodbClient, kmsClient, order.UserID)
			if err != nil {
				log.Printf("[FuturesUserTrader4User-%s] Failed to get api key or secret key: %+v", order.UserID, err.Error())
			}
			client := futures.NewClient(apiKey, secretKey)

			intervals := common.GetDivisibleIntervals()
			if isTrendStr == common.True && common.ContainsStr(intervals, order.Interval) {
				err := processFuturesTrend(client, order)
				if err != nil {
					// log.Printf("[FuturesUserTrader4User-%s] Failed to processFuturesTrend: %+v", order.UserID, err.Error())
					discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][processFuturesTrend] Error: %v", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, err.Error())
					common.Log4Trace(err, common.GetAlertChannel(order.UserID), discMsg)
				}
			} else {
				err := processFuturesSlNCancel(client, order)
				if err != nil {
					// log.Printf("[FuturesUserTrader4User-%s] Failed to processFuturesSlNCancel: %+v", order.UserID, err.Error())
					discMsg := fmt.Sprintf("[FuturesUserTrade-%s-%s][processFuturesSlNCancel] Error: %v", common.RenameCR4Display(order.ExchangeTradeTypeCapRiskTradePair), order.UserID, err.Error())
					common.Log4Trace(err, common.GetAlertChannel(order.UserID), discMsg)
				}
			}
		}
	}

	return common.Response{
		Code:    200,
		Message: "Stream processed successfully",
		Data:    nil,
	}, nil
}

func main() {
	lambda.Start(new(DynamoDBStreamHandler).HandleRequest)
}
