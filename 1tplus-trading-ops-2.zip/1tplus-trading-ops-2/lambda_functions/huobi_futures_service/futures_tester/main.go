package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"io/ioutil"
	"log"
	"net/url"
	"os"
	"sort"
	"time"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/gorilla/websocket"
)

// HTXAPI holds the API credentials and base URL
type HTXAPI struct {
	AccessKey string
	SecretKey string
	BaseURL   string
}

// NewHTXAPI initializes a new HTXAPI instance
func NewHTXAPI(accessKey, secretKey string) *HTXAPI {
	return &HTXAPI{
		AccessKey: accessKey,
		SecretKey: secretKey,
		BaseURL:   "https://api.hbdm.com",
	}
}

// createSignature generates a signed string for authentication
func (api *HTXAPI) createSignature(method, endpoint string, params map[string]string) string {
	params["AccessKeyId"] = api.AccessKey
	params["SignatureMethod"] = "HmacSHA256"
	params["SignatureVersion"] = "2"
	params["Timestamp"] = time.Now().UTC().Format("2006-01-02T15:04:05")

	// Sort the keys
	sortedKeys := make([]string, 0, len(params))
	for key := range params {
		sortedKeys = append(sortedKeys, key)
	}
	sort.Strings(sortedKeys)

	// Create the query string
	queryString := ""
	for i, key := range sortedKeys {
		if i > 0 {
			queryString += "&"
		}
		queryString += fmt.Sprintf("%s=%s", url.QueryEscape(key), url.QueryEscape(params[key]))
	}

	// Create the string to sign
	preSignedText := fmt.Sprintf("%s\n%s\n%s\n%s", method, "api.hbdm.com", endpoint, queryString)

	// Sign the string
	hmacSHA256 := hmac.New(sha256.New, []byte(api.SecretKey))
	hmacSHA256.Write([]byte(preSignedText))
	signature := base64.StdEncoding.EncodeToString(hmacSHA256.Sum(nil))

	return signature
}

// sendAuth sends the authentication message via WebSocket
func (api *HTXAPI) sendAuth(conn *websocket.Conn, host string, path string) bool {
	timestamp := time.Now().UTC().Format("2006-01-02T15:04:05")

	params := map[string]string{
		"AccessKeyId":      api.AccessKey,
		"SignatureMethod":  "HmacSHA256",
		"SignatureVersion": "2",
		"Timestamp":        timestamp,
	}

	signature := api.createSignature("GET", path, params)
	auth := fmt.Sprintf(
		`{"op":"auth", "type":"api", "AccessKeyId":"%s", "SignatureMethod":"HmacSHA256", "SignatureVersion":"2", "Timestamp":"%s", "Signature":"%s"}`,
		api.AccessKey, timestamp, signature,
	)

	fmt.Println("send auth:", auth)
	jdata := []byte(auth)
	conn.WriteMessage(websocket.TextMessage, jdata)
	return true
}

// gzipDecompress decompresses gzip data
func gzipDecompress(input []byte) (string, error) {
	buf := bytes.NewBuffer(input)
	reader, gzipErr := gzip.NewReader(buf)
	if gzipErr != nil {
		return "", gzipErr
	}
	defer reader.Close()

	result, readErr := ioutil.ReadAll(reader)
	if readErr != nil {
		return "", readErr
	}

	return string(result), nil
}

// readLoop reads messages from the WebSocket connection
func readLoop(conn *websocket.Conn) {
	for conn != nil {
		msgType, buf, err := conn.ReadMessage()
		if err != nil {
			fmt.Printf("Read error: %s", err)
			continue
		}
		var message string
		if msgType == websocket.BinaryMessage {
			message, err = gzipDecompress(buf)
			if err != nil {
				fmt.Printf("UnGZip data error: %s", err)
				continue
			}
		} else if msgType == websocket.TextMessage {
			message = string(buf)
		}
		fmt.Println(message)
	}
}

// handler handles the AWS Lambda function
func handler(ctx context.Context, request events.APIGatewayWebsocketProxyRequest) (events.APIGatewayProxyResponse, error) {
	host := "api.hbdm.com"
	path := "/swap-notification"

	accessKey := os.Getenv("HTX_API_KEY")
	secretKey := os.Getenv("HTX_SECRET_KEY")

	api := NewHTXAPI(accessKey, secretKey)

	url := fmt.Sprintf("wss://%s%s", host, path)
	conn, _, err := websocket.DefaultDialer.Dial(url, nil)
	if err != nil {
		log.Printf("WebSocket connected error: %s", err)
		return events.APIGatewayProxyResponse{StatusCode: 500}, err
	}

	api.sendAuth(conn, host, path)
	go readLoop(conn)

	return events.APIGatewayProxyResponse{StatusCode: 200}, nil
}

func main() {
	lambda.Start(handler)
}
